import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppProvider } from "@/lib/store";
import { Toaster } from "@/components/ui";
import { SWRegister } from "@/components/shell/SWRegister";

export const metadata: Metadata = {
  title: { default: "ONETN – One Platform. Every Service.", template: "%s · ONETN" },
  description: "ONETN brings transport, essentials, home services, government services, temple services, education, healthcare, jobs and food together for the people of Tamil Nadu.",
  applicationName: "ONETN",
  manifest: "manifest.webmanifest",
  icons: { icon: "icon.svg", apple: "icon.svg" },
  appleWebApp: { capable: true, title: "ONETN", statusBarStyle: "default" },
};
export const viewport: Viewport = { themeColor: "#8B0000", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh">
        <AppProvider>
          {children}
          <Toaster />
          <SWRegister />
        </AppProvider>
      </body>
    </html>
  );
}
