import { PortalPage } from "@/portals/PortalPage";
import { PORTAL_SECTIONS } from "@/portals/sections";
export function generateStaticParams() { return PORTAL_SECTIONS["education"].map((section) => ({ section })); }
export default async function Page({ params }: { params: Promise<{ section: string }> }) { const { section } = await params; return <PortalPage portal="education" section={section} />; }
