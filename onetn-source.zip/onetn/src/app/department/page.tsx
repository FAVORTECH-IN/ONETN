import { PortalPage } from "@/portals/PortalPage";
export default function Page() { return <PortalPage portal="department" />; }
