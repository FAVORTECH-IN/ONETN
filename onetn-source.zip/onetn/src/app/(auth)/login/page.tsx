"use client";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";
import { Smartphone, ShieldCheck } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Button, Field, Input, Notice } from "@/components/ui";
import { useApp } from "@/lib/store";

const schema = z.object({ mobile: z.string().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number") });

export default function LoginPage() {
  const { t, s } = useApp();
  const r = useRouter();
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  const onSubmit = (v: z.infer<typeof schema>) => {
    setLoading(true);
    setTimeout(() => r.push(`/verify-otp?m=${v.mobile}`), 600);
  };
  return (
    <AuthFrame>
      <div className="mt-4 lg:mt-16">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary"><Smartphone /></span>
        <h1 className="mt-5 text-3xl font-extrabold">{t("login")}</h1>
        <p className="mt-1 text-muted">{t("enterMobile")}</p>
        <form onSubmit={handleSubmit(onSubmit)} className="mt-7 space-y-4" noValidate>
          <Field label={t("mobileNumber")} required error={errors.mobile?.message}>
            <div className="flex gap-2">
              <span className="grid h-12 place-items-center rounded-2xl border border-line bg-white px-4 font-semibold">+91</span>
              <Input inputMode="numeric" maxLength={10} autoComplete="tel-national" placeholder="98765 43210" invalid={!!errors.mobile} {...register("mobile")} />
            </div>
          </Field>
          <Button full size="lg" loading={loading} type="submit">{t("sendOtp")}</Button>
        </form>
        <Notice tone="gold" className="mt-5" title="Demo authentication">
          OTPs are simulated until a real authentication provider is connected. Try <b>9876543210</b> for an existing demo account, or any other number to register.
        </Notice>
        <div className="mt-6 flex flex-wrap justify-between gap-2 text-sm">
          <Link href="/recover" className="font-semibold text-primary">Can&apos;t access your number?</Link>
          <Link href="/onboarding" className="font-semibold text-primary">Take the app tour</Link>
        </div>
        <div className="mt-8 rounded-2xl border border-line bg-white p-4">
          <p className="text-sm font-semibold">Partner or officer?</p>
          <p className="mt-0.5 text-sm text-muted">Drivers, stores, restaurants, temples, teachers, doctors, employers and departments sign in with the same mobile login, then pick their role.</p>
          <Link href="/select-role" className="mt-2 inline-block text-sm font-semibold text-primary">Choose a role →</Link>
        </div>
        <p className="mt-6 flex items-center gap-2 text-xs text-muted"><ShieldCheck size={14} />By continuing you agree to the <Link className="underline" href="/support/terms">Terms</Link> and <Link className="underline" href="/support/privacy">Privacy Policy</Link>. {s.lang === "ta" ? "" : ""}</p>
      </div>
    </AuthFrame>
  );
}
