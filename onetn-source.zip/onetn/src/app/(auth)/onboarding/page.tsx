"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Car, Truck, Landmark, Flame, GraduationCap, Wallet, Check } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Button } from "@/components/ui";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

const slides = [
  { i: Car, en: ["Fair fares, every ride", "Autos, cabs and buses at approved, published fares – shown before you book."], ta: ["ஒவ்வொரு பயணத்திற்கும் நியாயமான கட்டணம்", "முன்பதிவுக்கு முன்பே கட்டணம் காட்டப்படும்."] },
  { i: Truck, en: ["Essentials at your door", "Ration, cooperative milk, medicines and Uzhavar Sandhai produce delivered home."], ta: ["அத்தியாவசியப் பொருட்கள் வீடு தேடி", "ரேஷன், பால், மருந்து, உழவர் சந்தை காய்கறிகள்."] },
  { i: Landmark, en: ["Government services, one place", "Find, apply and track certificates, pensions and schemes – free of platform fees."], ta: ["அரசு சேவைகள் ஒரே இடத்தில்", "சான்றிதழ்கள், ஓய்வூதியம், திட்டங்கள் – இலவசமாக."] },
  { i: Flame, en: ["Temples, learning and jobs", "Book sevas, receive prasadam, study with an AI guide and find work."], ta: ["கோயில், கல்வி, வேலை", "சேவை முன்பதிவு, பிரசாதம், AI வழிகாட்டி, வேலைகள்."] },
  { i: Wallet, en: ["One secure Wallet", "Payments, refunds, cashback and government benefits in one place."], ta: ["ஒரே பாதுகாப்பான வாலட்", "கட்டணம், திருப்பம், அரசு உதவித்தொகை."] },
];

export default function Onboarding() {
  const { s, set, t } = useApp();
  const r = useRouter();
  const [i, setI] = useState(-1); // -1 = language selection
  const finish = () => { set((p) => ({ ...p, onboarded: true })); r.push("/login"); };
  if (i === -1)
    return (
      <AuthFrame>
        <div className="mt-6 lg:mt-16">
          <h1 className="text-3xl font-extrabold">{t("chooseLanguage")}</h1>
          <p className="text-muted">Choose your language · உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்</p>
          <div className="mt-8 space-y-3">
            {([["ta", "தமிழ்", "Tamil"], ["en", "English", "ஆங்கிலம்"]] as const).map(([l, a, b]) => (
              <button key={l} onClick={() => set((p) => ({ ...p, lang: l }))}
                className={cn("card flex w-full items-center gap-4 p-5 text-left", s.lang === l && "border-primary ring-4 ring-primary/10")}>
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gold-soft text-xl font-bold text-[#7A5C00]">{l === "ta" ? "அ" : "A"}</span>
                <span className="flex-1"><span className="block text-lg font-bold">{a}</span><span className="text-sm text-muted">{b}</span></span>
                {s.lang === l && <Check className="text-primary" />}
              </button>
            ))}
          </div>
          <Button full size="lg" className="mt-8" onClick={() => setI(0)}>{t("continue")}</Button>
        </div>
      </AuthFrame>
    );
  const sl = slides[i];
  const [title, body] = s.lang === "ta" ? sl.ta : sl.en;
  return (
    <AuthFrame>
      <div className="flex flex-1 flex-col">
        <div className="flex justify-end"><button onClick={finish} className="text-sm font-semibold text-muted">{t("skip")}</button></div>
        <div key={i} className="fade-in flex flex-1 flex-col items-center justify-center text-center">
          <div className="relative grid h-56 w-56 place-items-center rounded-full bg-gold-soft">
            <div className="absolute inset-6 rounded-full bg-white shadow-[var(--shadow-soft)]" />
            <sl.i size={84} className="relative text-primary" />
          </div>
          <h1 className="mt-8 text-2xl font-extrabold">{title}</h1>
          <p className="mt-2 max-w-sm text-muted">{body}</p>
        </div>
        <div className="mb-6 flex justify-center gap-2">{slides.map((_, k) => <span key={k} className={cn("h-2 rounded-full transition-all", k === i ? "w-6 bg-primary" : "w-2 bg-line")} />)}</div>
        <Button full size="lg" onClick={() => (i < slides.length - 1 ? setI(i + 1) : finish())}>{i < slides.length - 1 ? t("next") : "Get started"}</Button>
        <GraduationCap className="hidden" />
      </div>
    </AuthFrame>
  );
}
