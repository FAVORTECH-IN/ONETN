"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Camera, CheckCircle2, MapPin, Bell, UserRound, Home as HomeIcon, ShieldCheck, PartyPopper } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Button, Field, Input, Select, Stepper, Toggle, Notice, Avatar } from "@/components/ui";
import { useApp } from "@/lib/store";
import { DISTRICTS, taluksOf } from "@/data/catalog";

const schema = z.object({
  name: z.string().trim().min(3, "Enter your full name"),
  email: z.string().trim().email("Enter a valid email").or(z.literal("")),
  dob: z.string().refine((v) => !v || new Date(v) < new Date(), "Date of birth must be in the past"),
  address: z.string().trim().min(6, "Enter house/street address"),
  district: z.string().min(1, "Select your district"),
  taluk: z.string().min(1, "Select your taluk"),
  city: z.string().trim().min(2, "Enter city or village"),
  pincode: z.string().regex(/^6\d{5}$/, "Tamil Nadu pincodes start with 6 and have 6 digits"),
  terms: z.literal(true, { message: "Please accept the terms to continue" }),
  privacy: z.literal(true, { message: "Please give privacy consent to continue" }),
});
type F = z.infer<typeof schema>;
const STEPS = ["Personal", "Address", "Photo", "Consent", "Permissions", "Done"];
const stepFields: (keyof F)[][] = [["name", "email", "dob"], ["address", "district", "taluk", "city", "pincode"], [], ["terms", "privacy"], []];

function RegisterInner() {
  const { login, set, s, t, toast } = useApp();
  const r = useRouter();
  const m = useSearchParams().get("m") ?? "";
  const [step, setStep] = useState(0);
  const [photo, setPhoto] = useState<string | undefined>();
  const [perm, setPerm] = useState({ location: true, notifications: true });
  const { register, handleSubmit, trigger, watch, setValue, formState: { errors } } = useForm<F>({ resolver: zodResolver(schema), defaultValues: { district: "", taluk: "", email: "", dob: "" } as Partial<F> as F });
  const district = watch("district");

  const next = async () => {
    const ok = await trigger(stepFields[step] as (keyof F)[]);
    if (ok) setStep(step + 1);
  };
  const requestPerms = async () => {
    if (perm.notifications && "Notification" in window) { try { await Notification.requestPermission(); } catch {} }
    if (perm.location && "geolocation" in navigator) navigator.geolocation.getCurrentPosition(() => {}, () => {});
    set((p) => ({ ...p, consents: { ...p.consents, location: perm.location, notifications: perm.notifications } }));
  };
  const finish = handleSubmit(async (v) => {
    await requestPerms();
    login({ name: v.name, mobile: m || "9000000000", email: v.email, dob: v.dob, address: v.address, district: v.district, taluk: v.taluk, city: v.city, pincode: v.pincode, photo, role: "citizen" });
    set((p) => ({ ...p, onboarded: true, location: `${v.city}, ${v.district}`, addresses: [{ id: "A0", label: "Home", line: `${v.address}, ${v.city}`, pincode: v.pincode }, ...p.addresses] }));
    setStep(5);
  });

  return (
    <AuthFrame wide>
      <h1 className="text-2xl font-extrabold">Create your ONETN account</h1>
      <p className="mb-5 text-sm text-muted">Mobile +91 {m} verified ✓</p>
      <Stepper steps={STEPS} current={step} />
      <div className="mt-6 flex-1">
        {step === 0 && (
          <div className="fade-in space-y-4">
            <h2 className="flex items-center gap-2 font-bold"><UserRound size={18} />Personal details</h2>
            <Field label={t("fullName")} required error={errors.name?.message}><Input placeholder="As on your ID" {...register("name")} invalid={!!errors.name} /></Field>
            <Field label={t("email")} error={errors.email?.message} hint="Optional – for receipts"><Input type="email" placeholder="name@example.com" {...register("email")} /></Field>
            <Field label={t("dob")} error={errors.dob?.message} hint="Required for pensions, scholarships and age-based schemes"><Input type="date" {...register("dob")} /></Field>
          </div>
        )}
        {step === 1 && (
          <div className="fade-in space-y-4">
            <h2 className="flex items-center gap-2 font-bold"><HomeIcon size={18} />Address</h2>
            <Field label={t("address")} required error={errors.address?.message}><Input placeholder="Door no., street, area" {...register("address")} invalid={!!errors.address} /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("district")} required error={errors.district?.message}>
                <Select options={DISTRICTS} placeholder="Select district" {...register("district", { onChange: () => setValue("taluk", "") })} invalid={!!errors.district} />
              </Field>
              <Field label={t("taluk")} required error={errors.taluk?.message}>
                <Select options={district ? taluksOf(district) : []} placeholder={district ? "Select taluk" : "Select district first"} disabled={!district} {...register("taluk")} invalid={!!errors.taluk} />
              </Field>
              <Field label={t("cityVillage")} required error={errors.city?.message}><Input {...register("city")} invalid={!!errors.city} /></Field>
              <Field label={t("pincode")} required error={errors.pincode?.message}><Input inputMode="numeric" maxLength={6} {...register("pincode")} invalid={!!errors.pincode} /></Field>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="fade-in flex flex-col items-center py-4 text-center">
            <h2 className="font-bold">Profile photo</h2>
            <p className="text-sm text-muted">Optional. Helps drivers and professionals recognise you.</p>
            <label className="mt-6 cursor-pointer">
              {photo ? <img src={photo} alt="Profile preview" className="h-32 w-32 rounded-full object-cover ring-4 ring-gold" /> : <span className="grid h-32 w-32 place-items-center rounded-full border-2 border-dashed border-primary/40 bg-white text-primary"><Camera size={36} /></span>}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; if (f.size > 3e6) return toast("Please choose an image under 3 MB", "error"); const rd = new FileReader(); rd.onload = () => setPhoto(String(rd.result)); rd.readAsDataURL(f); }} />
              <span className="mt-3 block text-sm font-semibold text-primary">{photo ? "Change photo" : "Upload photo"}</span>
            </label>
          </div>
        )}
        {step === 3 && (
          <div className="fade-in space-y-4">
            <h2 className="flex items-center gap-2 font-bold"><ShieldCheck size={18} />Terms & privacy</h2>
            <div className="card max-h-48 overflow-y-auto p-4 text-sm text-muted">
              <p className="font-semibold text-ink">Summary of terms</p>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li>Every fare and fee is shown before you confirm.</li>
                <li>Government applications, certificates, basic textbooks and government jobs carry no platform fee.</li>
                <li>Temple seva fees, offerings and prasadam price go to the temple; platform fees are separate.</li>
                <li>Job seekers are never charged to apply.</li>
                <li>The Wallet is provided with a licensed bank / payment partner under RBI rules.</li>
              </ul>
              <p className="mt-3 font-semibold text-ink">Privacy (DPDP Act, 2023)</p>
              <p className="mt-1">Your data is used only with your consent and for a stated purpose. It is never sold. You can view, correct, withdraw consent or request deletion at any time from Profile → Data consent.</p>
            </div>
            <label className="flex items-start gap-3 text-sm"><input type="checkbox" className="mt-1 h-5 w-5 accent-[#8B0000]" {...register("terms")} />I accept the ONETN Terms and Conditions.</label>
            {errors.terms && <p className="text-xs text-error">{errors.terms.message}</p>}
            <label className="flex items-start gap-3 text-sm"><input type="checkbox" className="mt-1 h-5 w-5 accent-[#8B0000]" {...register("privacy")} />I consent to ONETN processing my personal data to provide the services I choose.</label>
            {errors.privacy && <p className="text-xs text-error">{errors.privacy.message}</p>}
          </div>
        )}
        {step === 4 && (
          <div className="fade-in space-y-3">
            <h2 className="font-bold">Permissions</h2>
            {[
              { k: "location" as const, i: MapPin, t: "Location", d: "Find nearby rides, stores, temples and services." },
              { k: "notifications" as const, i: Bell, t: "Notifications", d: "Booking updates, delivery OTPs and application status." },
            ].map(({ k, i: I, t: tt, d }) => (
              <div key={k} className="card flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary-soft text-primary"><I size={20} /></span>
                <div className="flex-1"><p className="font-semibold">{tt}</p><p className="text-sm text-muted">{d}</p></div>
                <Toggle checked={perm[k]} onChange={(v) => setPerm({ ...perm, [k]: v })} label={tt} />
              </div>
            ))}
            <Notice tone="info">You can change these any time in Profile → Permissions. Your browser may also ask you to confirm.</Notice>
          </div>
        )}
        {step === 5 && (
          <div className="fade-in flex flex-col items-center py-8 text-center">
            <span className="grid h-20 w-20 place-items-center rounded-full bg-success-soft text-success"><PartyPopper size={38} /></span>
            <h2 className="mt-4 text-2xl font-extrabold">Registration successful</h2>
            <p className="mt-1 text-muted">Welcome to ONETN, {s.user?.name.split(" ")[0]}!</p>
            <div className="mt-5 flex items-center gap-3 rounded-2xl border border-line bg-white p-3 text-left">
              {photo ? <img src={photo} alt="" className="h-11 w-11 rounded-full object-cover" /> : <Avatar name={s.user?.name ?? "U"} />}
              <div><p className="font-semibold">{s.user?.name}</p><p className="text-sm text-muted">{s.user?.city}, {s.user?.district}</p></div>
              <CheckCircle2 className="ml-2 text-success" />
            </div>
            <Button full size="lg" className="mt-8" onClick={() => { toast("Account created"); r.replace("/home"); }}>Go to Home</Button>
            <Button full variant="ghost" className="mt-2" onClick={() => r.push("/select-role")}>I am a partner / officer</Button>
          </div>
        )}
      </div>
      {step < 5 && (
        <div className="mt-6 flex gap-3">
          {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>{t("back")}</Button>}
          {step === 2 && <Button variant="ghost" onClick={() => setStep(3)}>{t("skip")}</Button>}
          <Button full onClick={step === 4 ? finish : next}>{step === 4 ? "Create account" : t("continue")}</Button>
        </div>
      )}
    </AuthFrame>
  );
}
export default function Register() { return <Suspense><RegisterInner /></Suspense>; }
