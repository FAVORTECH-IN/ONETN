"use client";
import { useState } from "react";
import Link from "next/link";
import { LifeBuoy, CheckCircle2 } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Button, Field, Input, Select, Notice } from "@/components/ui";
import { uid } from "@/lib/utils";

export default function Recover() {
  const [f, setF] = useState({ old: "", next: "", name: "", reason: "" });
  const [err, setErr] = useState<Record<string, string>>({});
  const [ticket, setTicket] = useState("");
  const submit = () => {
    const e: Record<string, string> = {};
    if (!/^[6-9]\d{9}$/.test(f.old)) e.old = "Enter the registered 10-digit number";
    if (!/^[6-9]\d{9}$/.test(f.next)) e.next = "Enter a valid new number";
    if (f.name.trim().length < 3) e.name = "Enter your full name as registered";
    if (!f.reason) e.reason = "Choose a reason";
    setErr(e);
    if (!Object.keys(e).length) setTicket(uid("REC"));
  };
  return (
    <AuthFrame>
      <div className="mt-4 lg:mt-12">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary"><LifeBuoy /></span>
        <h1 className="mt-5 text-3xl font-extrabold">Account recovery</h1>
        <p className="mt-1 text-muted">Lost access to your registered mobile number? Request a secure number change.</p>
        {ticket ? (
          <div className="card mt-6 text-center">
            <CheckCircle2 className="mx-auto text-success" size={40} />
            <p className="mt-2 font-bold">Request submitted</p>
            <p className="text-sm text-muted">Reference <b>{ticket}</b>. Our Tamil/English help desk will verify your identity and call the new number within 2 working days.</p>
            <Button href="/login" full className="mt-4">Back to login</Button>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            <Field label="Registered mobile number" required error={err.old}><Input inputMode="numeric" maxLength={10} value={f.old} onChange={(e) => setF({ ...f, old: e.target.value })} /></Field>
            <Field label="New mobile number" required error={err.next}><Input inputMode="numeric" maxLength={10} value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} /></Field>
            <Field label="Full name" required error={err.name}><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="Reason" required error={err.reason}><Select placeholder="Select" options={["Lost phone / SIM", "Number deactivated", "Changed number", "Other"]} value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
            <Notice tone="info">For your security, identity is verified by the help desk before any change. Wallet transactions stay frozen until recovery completes.</Notice>
            <Button full size="lg" onClick={submit}>Submit request</Button>
            <Link href="/login" className="block text-center text-sm font-semibold text-primary">Back to login</Link>
          </div>
        )}
      </div>
    </AuthFrame>
  );
}
