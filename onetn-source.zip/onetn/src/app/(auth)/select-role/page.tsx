"use client";
import { useRouter } from "next/navigation";
import { UserRound, Bike, Wrench, Store, UtensilsCrossed, Flame, GraduationCap, Stethoscope, Briefcase, Landmark, ShieldCheck, ChevronRight } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Notice } from "@/components/ui";
import { useApp, type Role } from "@/lib/store";
import { ROLES } from "@/data/catalog";

const icons: Record<Role, React.ComponentType<{ size?: number }>> = {
  citizen: UserRound, driver: Bike, professional: Wrench, merchant: Store, restaurant: UtensilsCrossed, temple: Flame,
  education: GraduationCap, healthcare: Stethoscope, employer: Briefcase, department: Landmark, admin: ShieldCheck,
};

export default function SelectRole() {
  const { s, set, login, toast } = useApp();
  const r = useRouter();
  const pick = (role: Role, href: string) => {
    if (role === "citizen") {
      if (!s.user) { r.push("/login"); return; }
      set((p) => ({ ...p, portalRole: undefined })); r.push(href); return;
    }
    if (!s.user) login({ ...(s.accounts["9876543210"]), role: "citizen" });
    set((p) => ({ ...p, portalRole: role }));
    toast(`Signed in to ${ROLES.find((x) => x.id === role)?.name} (demo)`);
    r.push(href);
  };
  return (
    <AuthFrame wide>
      <h1 className="mt-2 text-2xl font-extrabold">Select your role</h1>
      <p className="text-sm text-muted">One ONETN account works across every portal. Access is limited to what each role is authorised to see.</p>
      <Notice tone="gold" className="mt-4">Demo: partner and officer portals open with sample data. In production, each role is granted only after verification and approval.</Notice>
      <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
        {ROLES.map((x) => {
          const I = icons[x.id];
          return (
            <button key={x.id} onClick={() => pick(x.id, x.href)} className="card flex items-center gap-3 p-3.5 text-left hover:border-primary/40">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary"><I size={20} /></span>
              <span className="min-w-0 flex-1"><span className="block font-semibold">{s.lang === "ta" ? x.ta : x.name}</span><span className="block truncate text-xs text-muted">{x.desc}</span></span>
              <ChevronRight size={18} className="text-muted" />
            </button>
          );
        })}
      </div>
    </AuthFrame>
  );
}
