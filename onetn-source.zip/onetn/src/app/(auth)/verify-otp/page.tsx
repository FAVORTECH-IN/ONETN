"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MessageSquareLock } from "lucide-react";
import { AuthFrame } from "@/components/shell/AuthFrame";
import { Button, Notice } from "@/components/ui";
import { useApp } from "@/lib/store";
import { maskMobile } from "@/lib/utils";

const DEMO = "123456";

function OtpInner() {
  const { t, s, login, toast } = useApp();
  const r = useRouter();
  const m = useSearchParams().get("m") ?? "";
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [err, setErr] = useState("");
  const [left, setLeft] = useState(30);
  const [loading, setLoading] = useState(false);
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  useEffect(() => { if (!/^[6-9]\d{9}$/.test(m)) r.replace("/login"); }, [m, r]);
  useEffect(() => { if (left <= 0) return; const id = setTimeout(() => setLeft(left - 1), 1000); return () => clearTimeout(id); }, [left]);

  const setAt = (i: number, v: string) => {
    const d = v.replace(/\D/g, "");
    if (d.length > 1) { const arr = d.slice(0, 6).split(""); setCode([...arr, ...Array(6 - arr.length).fill("")]); refs.current[Math.min(5, arr.length)]?.focus(); return; }
    const n = [...code]; n[i] = d; setCode(n); setErr("");
    if (d && i < 5) refs.current[i + 1]?.focus();
  };
  const verify = () => {
    const c = code.join("");
    if (c.length < 6) return setErr("Enter all 6 digits");
    if (c !== DEMO) return setErr("Incorrect OTP. In demo mode the code is 123456.");
    setLoading(true);
    setTimeout(() => {
      const acct = s.accounts[m];
      if (acct) { login(acct); toast(`Welcome back, ${acct.name.split(" ")[0]}`); r.replace("/home"); }
      else r.replace(`/register?m=${m}`);
    }, 500);
  };
  return (
    <AuthFrame>
      <div className="mt-4 lg:mt-16">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary"><MessageSquareLock /></span>
        <h1 className="mt-5 text-3xl font-extrabold">{t("verifyOtp")}</h1>
        <p className="mt-1 text-muted">{t("enterOtp")} +91 {maskMobile(m)}</p>
        <div className="mt-7 flex justify-between gap-2" onPaste={(e) => { e.preventDefault(); setAt(0, e.clipboardData.getData("text")); }}>
          {code.map((c, i) => (
            <input key={i} ref={(el) => { refs.current[i] = el; }} value={c} inputMode="numeric" maxLength={6} aria-label={`Digit ${i + 1}`}
              onChange={(e) => setAt(i, e.target.value)} onKeyDown={(e) => { if (e.key === "Backspace" && !c && i) refs.current[i - 1]?.focus(); if (e.key === "Enter") verify(); }}
              className={`h-14 w-full rounded-2xl border bg-white text-center text-2xl font-bold outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 ${err ? "border-error" : "border-line"}`} />
          ))}
        </div>
        {err && <p className="mt-2 text-sm text-error">{err}</p>}
        <Button full size="lg" className="mt-6" onClick={verify} loading={loading}>{t("verifyOtp")}</Button>
        <div className="mt-5 text-center text-sm">
          {left > 0 ? <span className="text-muted">{t("resendOtp")} in 0:{String(left).padStart(2, "0")}</span>
            : <button className="font-semibold text-primary" onClick={() => { setLeft(30); setCode(["", "", "", "", "", ""]); toast("OTP resent (demo code 123456)", "info"); }}>{t("resendOtp")}</button>}
        </div>
        <Notice tone="gold" className="mt-6" title="Demo OTP: 123456">No SMS is sent in this demo. A real OTP provider must be configured before launch.</Notice>
        <button onClick={() => r.push("/login")} className="mt-4 text-sm font-semibold text-primary">Change mobile number</button>
      </div>
    </AuthFrame>
  );
}
export default function VerifyOtp() { return <Suspense><OtpInner /></Suspense>; }
