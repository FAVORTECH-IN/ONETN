"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useApp } from "@/lib/store";
import { LogoMark } from "@/components/shell/Logo";

export default function Splash() {
  const { s, ready } = useApp();
  const r = useRouter();
  useEffect(() => {
    if (!ready) return;
    const t = setTimeout(() => r.replace(s.user ? "/home" : "/login"), 1300);
    return () => clearTimeout(t);
  }, [ready, s.user, r]);
  return (
    <div className="relative grid min-h-dvh place-items-center overflow-hidden bg-primary text-white">
      <svg className="absolute h-[140vmax] w-[140vmax] opacity-10" viewBox="0 0 200 200" aria-hidden>
        {[90, 70, 50, 30].map((r) => <circle key={r} cx="100" cy="100" r={r} fill="none" stroke="#D4AF37" strokeWidth="1.5" />)}
      </svg>
      <div className="fade-in relative flex flex-col items-center text-center">
        <LogoMark size={96} />
        <h1 className="mt-5 text-5xl font-extrabold tracking-tight">ONE<span className="text-gold">TN</span></h1>
        <p className="mt-2 text-lg text-white/85">One Platform. Every Service.</p>
        <p className="mt-1 text-white/70">ஒரே தளம். அனைத்து சேவைகளும்.</p>
        <span className="mt-10 h-1.5 w-28 overflow-hidden rounded-full bg-white/20"><span className="block h-full w-1/2 animate-[pulse_1s_ease-in-out_infinite] rounded-full bg-gold" /></span>
      </div>
    </div>
  );
}
