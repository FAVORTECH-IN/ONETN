import { Policy } from "@/components/flows/Policy";
export default function Terms() { return <Policy title="Terms & conditions" sections={[
  ["Fees and fares", ["Every fare and fee is shown before you confirm.", "Fee levels are approved by the Government and published.", "Government applications, certificates, basic textbooks and government jobs carry no platform fee.", "Job seekers are never charged to apply or to be hired."]],
  ["Partners", ["Drivers, stores, restaurants, professionals, temples, teachers and doctors are verified before they start.", "Restaurants and stores are independent businesses responsible for their goods, prices and taxes.", "Temples set their own sevas, customs and prices; temple income goes to the temple."]],
  ["Cancellations & refunds", ["Fair cancellation rules apply equally to customers and partners.", "Refunds for cancelled or corrected orders are credited to the Wallet."]],
  ["Wallet", ["Provided with a licensed bank or payment partner under RBI rules.", "Protected with PIN, OTP where required, alerts, limits and freeze."]],
  ["Complaints", ["Every complaint gets a reference and visible status, with escalation and appeal."]],
]} />; }
