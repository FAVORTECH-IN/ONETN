import { Policy } from "@/components/flows/Policy";
export default function Privacy() { return <Policy title="Privacy policy" sections={[
  ["Consent", ["Data is collected and used only with your agreement and for a stated purpose.", "You can view, correct, withdraw consent and request deletion where the law allows."]],
  ["Minimum data", ["Only what is needed for a service is collected.", "Personal data is never sold."]],
  ["Sensitive data", ["Health and financial data are handled with higher protection and shared only with consent.", "Extra care for children's data; the AI guide is designed for safe use by students."]],
  ["Departments", ["Each department owns and controls its data; ONETN is a doorway.", "Anonymised information may be shared with the Government for planning."]],
  ["Security", ["Access is limited to those who need it, monitored for misuse and independently audited.", "Incidents are handled with a clear response plan, including informing those affected."]],
  ["Law", ["Digital Personal Data Protection Act, 2023 and other applicable laws."]],
]} />; }
