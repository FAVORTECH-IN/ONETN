"use client";
import Link from "next/link";
import { MessageCircle, Phone, FileText, HelpCircle, ShieldCheck, ScrollText, Mail } from "lucide-react";
import { FAQ } from "@/data/faq";
import { Card, ListRow, Notice, PageHeader, SectionHeader } from "@/components/ui";

export default function Support() {
  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <PageHeader title="Help centre" sub="Support in Tamil and English" />
      <div className="grid grid-cols-3 gap-3">
        <Link href="/support/chat" className="card flex flex-col items-center gap-2 p-4 text-center"><MessageCircle className="text-primary" /><span className="text-sm font-semibold">Chat support</span></Link>
        <a href="tel:1800000000" className="card flex flex-col items-center gap-2 p-4 text-center"><Phone className="text-primary" /><span className="text-sm font-semibold">Call support</span></a>
        <Link href="/grievance/new" className="card flex flex-col items-center gap-2 p-4 text-center"><FileText className="text-primary" /><span className="text-sm font-semibold">Raise complaint</span></Link>
      </div>
      <Notice tone="gold">Helpline number and hours will be published at launch. Calls shown here are placeholders.</Notice>
      <section><SectionHeader title="Frequently asked" href="/support/faq" />
        <Card className="divide-y divide-line p-0">{FAQ.slice(0, 5).map((f) => <details key={f.q} className="group px-4 py-3"><summary className="cursor-pointer list-none text-sm font-semibold">{f.q}</summary><p className="mt-2 text-sm text-muted">{f.a}</p></details>)}</Card></section>
      <Card className="divide-y divide-line p-0">
        <ListRow href="/support/faq" icon={<HelpCircle size={19} className="text-primary" />} title="All FAQs" />
        <ListRow href="/support/privacy" icon={<ShieldCheck size={19} className="text-primary" />} title="Privacy policy" />
        <ListRow href="/support/terms" icon={<ScrollText size={19} className="text-primary" />} title="Terms & conditions" />
        <ListRow href="/profile/consent" icon={<FileText size={19} className="text-primary" />} title="Data consent & deletion" />
        <ListRow icon={<Mail size={19} className="text-primary" />} title="Email" sub="support@onetn.example (placeholder)" />
      </Card>
    </div>
  );
}
