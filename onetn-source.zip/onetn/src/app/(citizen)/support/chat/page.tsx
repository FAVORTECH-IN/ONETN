"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Send, Headphones } from "lucide-react";
import { useApp } from "@/lib/store";
import { Button, Card, Chip, PageHeader, SimTag } from "@/components/ui";
import { cn } from "@/lib/utils";

const bot = (q: string) => {
  const x = q.toLowerCase();
  if (/refund/.test(x)) return "Refunds for cancelled or corrected orders go to your Wallet instantly. If you haven't received one, open the booking and tap “Report an issue / refund”.";
  if (/ration/.test(x)) return "You can book doorstep ration delivery or a shop collection slot from Services → Ration Delivery. Shop collection continues as before.";
  if (/otp|login/.test(x)) return "In this demo the OTP is 123456. If you lost access to your number, use Account recovery on the login screen.";
  if (/agent|human|person|talk/.test(x)) return "Connecting you to a support agent… (simulated). Average wait in Tamil/English queue: 2 minutes.";
  return "Thanks – I can help with bookings, refunds, Wallet, ration, applications and more. You can also raise a tracked complaint.";
};
export default function Chat() {
  const { s } = useApp();
  const [msgs, setMsgs] = useState([{ me: false, t: `Vanakkam ${s.user?.name.split(" ")[0]}! How can we help today? / இன்று எப்படி உதவலாம்?` }]);
  const [q, setQ] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs]);
  const send = (t = q) => { if (!t.trim()) return; setMsgs((m) => [...m, { me: true, t }]); setQ(""); setTimeout(() => setMsgs((m) => [...m, { me: false, t: bot(t) }]), 600); };
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Chat support" right={<SimTag />} />
      <Card className="flex h-[65vh] flex-col p-0">
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {msgs.map((m, i) => <div key={i} className={cn("flex gap-2", m.me && "justify-end")}>{!m.me && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary-soft text-primary"><Headphones size={15} /></span>}<p className={cn("max-w-[80%] rounded-2xl px-4 py-2.5 text-sm", m.me ? "bg-primary text-white" : "bg-cream")}>{m.t}</p></div>)}
          <div ref={end} />
        </div>
        <div className="border-t border-line p-3">
          <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">{["Where is my refund?", "Ration delivery", "OTP not received", "Talk to an agent"].map((x) => <Chip key={x} className="h-8 text-xs" onClick={() => send(x)}>{x}</Chip>)}</div>
          <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type a message" className="h-12 flex-1 rounded-2xl border border-line px-4 outline-none focus:border-primary" /><Button type="submit" aria-label="Send"><Send size={18} /></Button></form>
        </div>
      </Card>
      <p className="mt-3 text-center text-sm">Prefer a tracked case? <Link href="/grievance/new" className="font-semibold text-primary">Raise a complaint</Link></p>
    </div>
  );
}
