"use client";
import { useState } from "react";
import { FAQ } from "@/data/faq";
import { Card, Chip, PageHeader } from "@/components/ui";
export default function Faq() {
  const [g, setG] = useState("All");
  const groups = Array.from(new Set(FAQ.map((f) => f.g)));
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="FAQ" />
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto">{["All", ...groups].map((x) => <Chip key={x} active={g === x} onClick={() => setG(x)}>{x}</Chip>)}</div>
      <Card className="divide-y divide-line p-0">{FAQ.filter((f) => g === "All" || f.g === g).map((f) => <details key={f.q} className="px-4 py-3"><summary className="cursor-pointer text-sm font-semibold">{f.q}</summary><p className="mt-2 text-sm text-muted">{f.a}</p></details>)}</Card>
    </div>
  );
}
