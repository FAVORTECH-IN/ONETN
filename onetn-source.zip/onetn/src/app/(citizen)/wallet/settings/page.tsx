"use client";
import { useState } from "react";
import { Snowflake, KeyRound, Gauge, Smartphone, Building2, BellRing, ShieldAlert } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Field, Input, Notice, PageHeader, Sheet, Toggle } from "@/components/ui";
import { inr } from "@/lib/utils";

export default function Settings() {
  const { s, set, toast } = useApp();
  const w = s.wallet;
  const [pinOpen, setPinOpen] = useState(false);
  const [pins, setPins] = useState({ old: "", a: "", b: "" });
  const [limit, setLimit] = useState(w.dailyLimit);
  const upd = (patch: Partial<typeof w>) => set((p) => ({ ...p, wallet: { ...p.wallet, ...patch } }));
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <PageHeader title="Wallet security" />
      <Card className="flex items-center gap-3"><Snowflake className="text-[#1D4E89]" /><div className="flex-1"><p className="font-semibold">Freeze Wallet</p><p className="text-sm text-muted">Lost your phone? Instantly block all Wallet payments.</p></div><Toggle checked={w.frozen} onChange={(v) => { upd({ frozen: v }); toast(v ? "Wallet frozen" : "Wallet unfrozen", v ? "error" : "success"); }} label="Freeze" /></Card>
      <Card className="flex items-center gap-3"><KeyRound className="text-primary" /><div className="flex-1"><p className="font-semibold">Transaction PIN</p><p className="text-sm text-muted">Required for every payment</p></div><Button size="sm" variant="outline" onClick={() => setPinOpen(true)}>Change</Button></Card>
      <Card className="space-y-3"><p className="flex items-center gap-2 font-semibold"><Gauge size={18} className="text-primary" />Daily transaction limit: {inr(w.dailyLimit)}</p><input type="range" min={1000} max={20000} step={500} value={limit} onChange={(e) => setLimit(Number(e.target.value))} className="w-full accent-[#8B0000]" /><div className="flex justify-between text-sm"><span>{inr(limit)}</span><Button size="sm" onClick={() => { upd({ dailyLimit: limit }); toast("Limit updated"); }}>Save</Button></div></Card>
      <Card className="flex items-center gap-3"><Smartphone className="text-primary" /><div className="flex-1"><p className="font-semibold">UPI</p><p className="text-sm text-muted">{w.upiLinked ? "priya@okbank" : "Link a UPI ID to add money instantly"}</p></div><Button size="sm" variant="outline" onClick={() => { upd({ upiLinked: !w.upiLinked }); toast(w.upiLinked ? "UPI unlinked" : "UPI linked (simulated)"); }}>{w.upiLinked ? "Unlink" : "Link"}</Button></Card>
      <Card className="flex items-center gap-3"><Building2 className="text-primary" /><div className="flex-1"><p className="font-semibold">Bank account</p><p className="text-sm text-muted">{w.bankLinked ? "Indian Bank ••4417 · for withdrawals & pensions" : "Link a bank account"}</p></div><Button size="sm" variant="outline" onClick={() => { upd({ bankLinked: !w.bankLinked }); toast(w.bankLinked ? "Bank unlinked" : "Bank linked (penny-drop simulated)"); }}>{w.bankLinked ? "Unlink" : "Link"}</Button></Card>
      <Card className="flex items-center gap-3"><BellRing className="text-primary" /><div className="flex-1"><p className="font-semibold">Transaction alerts</p><p className="text-sm text-muted">SMS + app alert for every transaction</p></div><Badge tone="success">Always on</Badge></Card>
      <Card className="flex items-start gap-3"><ShieldAlert className="shrink-0 text-warning" /><div><p className="font-semibold">Suspicious activity alerts</p><p className="text-sm text-muted">Unusual payments are flagged and held for checks. No alerts in the last 30 days.</p></div></Card>
      <Notice tone="info">Never share your PIN or OTP. ONETN staff will never ask for it, and never ask for payment outside the app.</Notice>
      <Sheet open={pinOpen} onClose={() => setPinOpen(false)} title="Change PIN" footer={<Button full onClick={() => { if (pins.old !== "1234") return toast("Current PIN incorrect (demo 1234)", "error"); if (!/^\d{4}$/.test(pins.a) || pins.a !== pins.b) return toast("New PINs must be 4 digits and match", "error"); setPinOpen(false); toast("PIN changed (demo keeps 1234)"); }}>Update PIN</Button>}>
        <div className="space-y-3">{(["old", "a", "b"] as const).map((k, i) => <Field key={k} label={["Current PIN", "New PIN", "Confirm new PIN"][i]}><Input type="password" inputMode="numeric" maxLength={4} value={pins[k]} onChange={(e) => setPins({ ...pins, [k]: e.target.value })} /></Field>)}</div>
      </Sheet>
    </div>
  );
}
