"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Smartphone, Building2, CreditCard, CheckCircle2, XCircle } from "lucide-react";
import { useApp } from "@/lib/store";
import { Button, Card, Chip, Input, Notice, PageHeader, SimTag } from "@/components/ui";
import { cn, inr } from "@/lib/utils";

export default function Add() {
  const { s, credit, toast, set } = useApp();
  const r = useRouter();
  const [amt, setAmt] = useState(500);
  const [m, setM] = useState("UPI");
  const [stage, setStage] = useState<"form" | "otp" | "busy" | "ok" | "fail">("form");
  const [otp, setOtp] = useState("");
  const [fail, setFail] = useState(false);
  const limit = 10000;
  const go = () => {
    if (amt < 10) return toast("Minimum ₹10", "error");
    if (s.wallet.balance + amt > limit * 2) return toast("Exceeds the wallet balance limit (demo ₹20,000)", "error");
    setStage("otp");
  };
  const confirm = () => {
    if (otp !== "1234") return toast("Incorrect OTP (demo 1234)", "error");
    setStage("busy");
    setTimeout(() => {
      if (fail) { set((p) => ({ ...p, txns: [{ id: "TXN" + Date.now().toString(36).toUpperCase(), at: new Date().toISOString(), title: `Add money via ${m}`, category: "Add money", amount: amt, status: "failed", method: m, ref: "Bank declined (simulated)" }, ...p.txns] })); setStage("fail"); return; }
      credit(amt, `Added money via ${m}`, "Add money", m); setStage("ok");
    }, 1000);
  };
  return (
    <div className="mx-auto max-w-lg space-y-4">
      <PageHeader title="Add money" sub={`Balance ${inr(s.wallet.balance)}`} right={<SimTag />} />
      {stage === "form" && (
        <>
          <Card className="space-y-3">
            <Input type="number" value={amt} onChange={(e) => setAmt(Number(e.target.value))} className="h-16 text-center text-3xl font-bold" aria-label="Amount" />
            <div className="flex flex-wrap justify-center gap-2">{[100, 200, 500, 1000, 2000].map((a) => <Chip key={a} active={amt === a} onClick={() => setAmt(a)}>{inr(a)}</Chip>)}</div>
          </Card>
          <div className="space-y-2">
            {[{ id: "UPI", i: Smartphone, d: "priya@okbank" }, { id: "Bank transfer", i: Building2, d: "Indian Bank ••4417" }, { id: "Card", i: CreditCard, d: "Debit / credit card" }].map((x) => (
              <button key={x.id} onClick={() => setM(x.id)} className={cn("card flex w-full items-center gap-3 p-3 text-left", m === x.id && "border-primary ring-4 ring-primary/10")}><x.i className="text-primary" /><span className="flex-1"><b className="block text-sm">{x.id}</b><span className="text-xs text-muted">{x.d}</span></span></button>
            ))}
          </div>
          <label className="flex items-center gap-2 text-sm text-muted"><input type="checkbox" checked={fail} onChange={(e) => setFail(e.target.checked)} className="accent-[#8B0000]" />Simulate failure</label>
          <Button full size="lg" onClick={go}>Add {inr(amt)}</Button>
          <Notice tone="info">KYC limits and balance caps follow RBI wallet rules via the licensed partner.</Notice>
        </>
      )}
      {stage === "otp" && <Card className="space-y-3 text-center"><p className="font-semibold">Enter OTP / UPI PIN to confirm {inr(amt)}</p><Input type="password" inputMode="numeric" maxLength={4} value={otp} onChange={(e) => setOtp(e.target.value)} className="mx-auto max-w-40 text-center text-2xl tracking-[.5em]" /><p className="text-xs text-muted">Demo: 1234</p><Button full onClick={confirm}>Confirm</Button></Card>}
      {stage === "busy" && <Card className="flex flex-col items-center py-10"><span className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" /><p className="mt-3">Processing…</p></Card>}
      {stage === "ok" && <Card className="flex flex-col items-center py-8 text-center"><CheckCircle2 size={56} className="text-success" /><p className="mt-2 text-xl font-bold">{inr(amt)} added</p><p className="text-muted">New balance {inr(s.wallet.balance)}</p><Button className="mt-4" onClick={() => r.push("/wallet")}>Back to Wallet</Button></Card>}
      {stage === "fail" && <Card className="flex flex-col items-center py-8 text-center"><XCircle size={56} className="text-error" /><p className="mt-2 text-xl font-bold">Payment failed</p><p className="text-muted">No money was deducted.</p><Button className="mt-4" onClick={() => { setStage("form"); setOtp(""); }}>Try again</Button></Card>}
    </div>
  );
}
