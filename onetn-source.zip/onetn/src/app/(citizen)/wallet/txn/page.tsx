"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Download, AlertOctagon } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Empty, Field, KV, PageHeader, Select, Sheet, Textarea, statusTone } from "@/components/ui";
import { downloadText, fmtDate, inr, uid } from "@/lib/utils";

function Inner() {
  const id = useSearchParams().get("id");
  const { s, set, toast } = useApp();
  const t = s.txns.find((x) => x.id === id);
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [desc, setDesc] = useState("");
  if (!t) return <Empty title="Transaction not found" />;
  return (
    <div className="mx-auto max-w-lg space-y-4">
      <PageHeader title="Transaction details" />
      <Card className="text-center"><p className={`text-3xl font-extrabold ${t.amount > 0 ? "text-success" : ""}`}>{inr(t.amount, { sign: true })}</p><p className="mt-1 font-semibold">{t.title}</p><Badge tone={statusTone(t.status)} className="mt-2">{t.status}</Badge></Card>
      <Card><KV rows={[["Transaction ID", t.id], ["Date & time", fmtDate(t.at, true)], ["Category", t.category], ["Method", t.method], ...(t.ref ? [["Note", t.ref] as [string, string]] : []), ["Environment", "Simulated (demo)"]]} /></Card>
      <Button full variant="outline" onClick={() => downloadText(`${t.id}.txt`, `ONETN Wallet receipt\n${t.id}\n${t.title}\n${inr(t.amount)}\n${fmtDate(t.at, true)}\nStatus: ${t.status}\n(Simulated)`)}><Download size={17} />Download receipt</Button>
      <Button full variant="ghost" onClick={() => setOpen(true)}><AlertOctagon size={17} />Dispute this transaction</Button>
      <Sheet open={open} onClose={() => setOpen(false)} title="Dispute transaction" footer={<Button full disabled={!reason} onClick={() => {
        const g = uid("GRV"); const now = new Date().toISOString();
        set((p) => ({ ...p, grievances: [{ id: g, service: "Wallet / payment", category: reason, ref: t.id, description: desc || reason, createdAt: now, status: "Submitted", history: [{ status: "Submitted", note: "Dispute raised with payment partner", at: now }] }, ...p.grievances] }));
        toast(`Dispute ${g} raised`); setOpen(false);
      }}>Raise dispute</Button>}>
        <div className="space-y-3"><Field label="Reason"><Select placeholder="Select" value={reason} onChange={(e) => setReason(e.target.value)} options={["Amount debited but service not received", "Charged twice", "Wrong amount", "I didn't make this transaction", "Refund not received"]} /></Field><Field label="Details"><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field></div>
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
