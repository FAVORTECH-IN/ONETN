"use client";
import Link from "next/link";
import { Plus, History, Send, ShieldCheck, Gift, Landmark, RotateCcw, Snowflake, ChevronRight, Wallet as W, Smartphone, Building2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Card, Notice, PageHeader, SectionHeader, SimTag, statusTone } from "@/components/ui";
import { fmtDate, inr, sum } from "@/lib/utils";

export default function Wallet() {
  const { s } = useApp();
  const w = s.wallet;
  const month = s.txns.filter((t) => new Date(t.at).getMonth() === new Date().getMonth());
  const spent = -sum(month.filter((t) => t.amount < 0 && t.status === "success").map((t) => t.amount));
  const benefits = sum(s.txns.filter((t) => t.category === "Government benefits").map((t) => t.amount));
  const refunds = sum(s.txns.filter((t) => t.category === "Refunds").map((t) => t.amount));
  const cashback = sum(s.txns.filter((t) => t.category === "Cashback").map((t) => t.amount));
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <PageHeader title="Wallet" sub="Offered with a licensed bank / payment partner (RBI rules)" back={false} right={<SimTag label="Demo – no real money" />} />
      <section className="relative overflow-hidden rounded-[22px] bg-primary p-6 text-white">
        <svg className="absolute -right-10 -top-10 h-48 w-48 opacity-20" viewBox="0 0 100 100" aria-hidden><circle cx="50" cy="50" r="44" fill="none" stroke="#D4AF37" strokeWidth="6" /></svg>
        <p className="flex items-center gap-2 text-sm text-white/80"><W size={16} />Available balance</p>
        <p className="mt-1 text-4xl font-extrabold">{inr(w.balance)}</p>
        <div className="mt-2 flex gap-2">{w.frozen ? <Badge tone="error"><Snowflake size={12} />Frozen</Badge> : <Badge tone="gold"><ShieldCheck size={12} />Protected by PIN</Badge>}</div>
        <div className="mt-5 grid grid-cols-4 gap-2 text-center text-xs font-semibold">
          {[{ i: Plus, l: "Add money", h: "/wallet/add" }, { i: Send, l: "Withdraw", h: "/wallet/transfer" }, { i: History, l: "History", h: "/wallet/history" }, { i: ShieldCheck, l: "Security", h: "/wallet/settings" }].map((x) => (
            <Link key={x.l} href={x.h} className="flex flex-col items-center gap-1.5 rounded-2xl bg-white/12 py-3 hover:bg-white/20"><x.i size={20} />{x.l}</Link>
          ))}
        </div>
      </section>
      {w.frozen && <Notice tone="error" title="Wallet frozen">Payments from the Wallet are blocked. Unfreeze in Security settings.</Notice>}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[{ i: Landmark, l: "Govt. benefits", v: benefits, c: "text-[#1D4E89]" }, { i: RotateCcw, l: "Refunds", v: refunds, c: "text-success" }, { i: Gift, l: "Cashback", v: cashback, c: "text-[#8A6A00]" }, { i: History, l: "Spent this month", v: spent, c: "text-primary" }].map((x) => (
          <Card key={x.l} className="p-3"><x.i size={18} className={x.c} /><p className="mt-2 text-lg font-bold">{inr(x.v)}</p><p className="text-xs text-muted">{x.l}</p></Card>
        ))}
      </div>
      <Card className="divide-y divide-line p-0">
        <Link href="/wallet/settings" className="flex items-center gap-3 px-4 py-3"><Smartphone size={18} className="text-primary" /><span className="flex-1 text-sm font-semibold">UPI</span><Badge tone={w.upiLinked ? "success" : "neutral"}>{w.upiLinked ? "priya@okbank linked" : "Not linked"}</Badge><ChevronRight size={16} /></Link>
        <Link href="/wallet/settings" className="flex items-center gap-3 px-4 py-3"><Building2 size={18} className="text-primary" /><span className="flex-1 text-sm font-semibold">Bank account</span><Badge tone={w.bankLinked ? "success" : "neutral"}>{w.bankLinked ? "Indian Bank ••4417" : "Not linked"}</Badge><ChevronRight size={16} /></Link>
      </Card>
      <section>
        <SectionHeader title="Recent transactions" href="/wallet/history" />
        <Card className="divide-y divide-line p-0">
          {s.txns.slice(0, 6).map((t) => (
            <Link key={t.id} href={`/wallet/txn?id=${t.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-cream">
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{t.title}</p><p className="text-xs text-muted">{t.category} · {fmtDate(t.at, true)}</p></div>
              <div className="text-right"><p className={`font-bold ${t.amount > 0 ? "text-success" : ""}`}>{inr(t.amount, { sign: true })}</p>{t.status !== "success" && <Badge tone={statusTone(t.status)}>{t.status}</Badge>}</div>
            </Link>
          ))}
        </Card>
      </section>
      <Notice tone="info">Subsidies, pensions and scholarships can be credited here where departments permit. Cashback is partner-funded, never paid by the Government.</Notice>
    </div>
  );
}
