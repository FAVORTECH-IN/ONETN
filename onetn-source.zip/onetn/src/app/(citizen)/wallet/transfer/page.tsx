"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useApp } from "@/lib/store";
import { Button, Card, Field, Input, Notice, PageHeader, Select, SimTag } from "@/components/ui";
import { inr } from "@/lib/utils";

export default function Transfer() {
  const { s, credit, toast } = useApp();
  const r = useRouter();
  const [amt, setAmt] = useState(0);
  const [pin, setPin] = useState("");
  const [to, setTo] = useState("Indian Bank ••4417");
  return (
    <div className="mx-auto max-w-lg space-y-4">
      <PageHeader title="Withdraw to bank" sub={`Available ${inr(s.wallet.balance)}`} right={<SimTag />} />
      {!s.wallet.bankLinked ? <Notice tone="warning">Link a bank account in Wallet security first.</Notice> : (
        <Card className="space-y-3">
          <Field label="To"><Select value={to} onChange={(e) => setTo(e.target.value)} options={["Indian Bank ••4417", ...(s.wallet.upiLinked ? ["UPI priya@okbank"] : [])]} /></Field>
          <Field label="Amount"><Input type="number" value={amt || ""} onChange={(e) => setAmt(Number(e.target.value))} /></Field>
          <Field label="Transaction PIN"><Input type="password" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value)} /></Field>
          <Button full onClick={() => {
            if (s.wallet.frozen) return toast("Wallet is frozen", "error");
            if (amt <= 0 || amt > s.wallet.balance) return toast("Enter an amount within your balance", "error");
            if (pin !== "1234") return toast("Incorrect PIN (demo 1234)", "error");
            credit(-amt, `Withdrawal to ${to}`, "Withdrawal", "Bank transfer"); toast(`${inr(amt)} sent to ${to}`); r.push("/wallet");
          }}>Withdraw</Button>
          <p className="text-xs text-muted">Transfers are processed by the licensed payment partner, usually instantly via IMPS/UPI.</p>
        </Card>
      )}
    </div>
  );
}
