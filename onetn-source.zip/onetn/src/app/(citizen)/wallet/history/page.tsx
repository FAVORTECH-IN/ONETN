"use client";
import Link from "next/link";
import { useState } from "react";
import { Download } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Chip, Empty, PageHeader, statusTone } from "@/components/ui";
import { downloadText, fmtDate, inr, toCSV } from "@/lib/utils";

const CATS = ["All", "Rides", "Bus tickets", "Parcels", "Groceries", "Essentials", "Home services", "Temple bookings", "Education", "Healthcare", "Restaurant orders", "Refunds", "Cashback", "Government benefits", "Add money", "Withdrawal"];
export default function H() {
  const { s } = useApp();
  const [c, setC] = useState("All");
  const [dir, setDir] = useState("All");
  const list = s.txns.filter((t) => (c === "All" || t.category === c) && (dir === "All" || (dir === "Credits" ? t.amount > 0 : t.amount < 0)));
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Transaction history" right={<Button size="sm" variant="outline" onClick={() => downloadText("onetn-wallet-statement.csv", toCSV(list.map((t) => ({ id: t.id, date: t.at, title: t.title, category: t.category, amount: t.amount, status: t.status, method: t.method }))), "text/csv")}><Download size={15} />Statement</Button>} />
      <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">{["All", "Credits", "Debits"].map((x) => <Chip key={x} active={dir === x} onClick={() => setDir(x)}>{x}</Chip>)}</div>
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto">{CATS.map((x) => <Chip key={x} className="h-8 text-xs" active={c === x} onClick={() => setC(x)}>{x}</Chip>)}</div>
      {list.length === 0 ? <Empty title="No transactions" /> : (
        <div className="card divide-y divide-line p-0">
          {list.map((t) => (
            <Link key={t.id} href={`/wallet/txn?id=${t.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-cream">
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{t.title}</p><p className="text-xs text-muted">{t.category} · {t.method} · {fmtDate(t.at, true)}</p></div>
              <div className="text-right"><p className={`font-bold ${t.amount > 0 ? "text-success" : ""}`}>{inr(t.amount, { sign: true })}</p><Badge tone={statusTone(t.status)}>{t.status}</Badge></div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
