"use client";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Camera } from "lucide-react";
import { useState } from "react";
import { useApp } from "@/lib/store";
import { DISTRICTS, taluksOf } from "@/data/catalog";
import { Avatar, Button, Card, Field, Input, PageHeader, Select } from "@/components/ui";

const schema = z.object({ name: z.string().min(3, "Enter full name"), email: z.string().email("Invalid email").or(z.literal("")), dob: z.string().optional(), address: z.string().min(5, "Enter address"), district: z.string().min(1, "Required"), taluk: z.string().min(1, "Required"), city: z.string().min(2, "Required"), pincode: z.string().regex(/^6\d{5}$/, "6-digit TN pincode") });
type F = z.infer<typeof schema>;
export default function Edit() {
  const { s, login, toast } = useApp();
  const r = useRouter();
  const u = s.user!;
  const [photo, setPhoto] = useState(u.photo);
  const { register, handleSubmit, watch, formState: { errors } } = useForm<F>({ resolver: zodResolver(schema), defaultValues: { name: u.name, email: u.email ?? "", dob: u.dob ?? "", address: u.address ?? "", district: u.district ?? "", taluk: u.taluk ?? "", city: u.city ?? "", pincode: u.pincode ?? "" } });
  const d = watch("district");
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Edit profile" />
      <form onSubmit={handleSubmit((v) => { login({ ...u, ...v, photo }); toast("Profile updated"); r.push("/profile"); })} className="space-y-4">
        <Card className="flex items-center gap-4">
          {photo ? <img src={photo} alt="" className="h-16 w-16 rounded-full object-cover" /> : <Avatar name={u.name} size={64} />}
          <label className="flex cursor-pointer items-center gap-2 text-sm font-semibold text-primary"><Camera size={17} />Change photo<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => setPhoto(String(rd.result)); rd.readAsDataURL(f); }} /></label>
        </Card>
        <Card className="grid gap-3 sm:grid-cols-2">
          <Field label="Full name" required error={errors.name?.message}><Input {...register("name")} /></Field>
          <Field label="Mobile" hint="Change via Account recovery"><Input value={u.mobile} disabled /></Field>
          <Field label="Email" error={errors.email?.message}><Input {...register("email")} /></Field>
          <Field label="Date of birth"><Input type="date" {...register("dob")} /></Field>
          <div className="sm:col-span-2"><Field label="Address" required error={errors.address?.message}><Input {...register("address")} /></Field></div>
          <Field label="District" required error={errors.district?.message}><Select options={DISTRICTS} placeholder="Select" {...register("district")} /></Field>
          <Field label="Taluk" required error={errors.taluk?.message}><Select options={d ? taluksOf(d) : []} placeholder="Select" {...register("taluk")} /></Field>
          <Field label="City / village" required error={errors.city?.message}><Input {...register("city")} /></Field>
          <Field label="Pincode" required error={errors.pincode?.message}><Input maxLength={6} {...register("pincode")} /></Field>
        </Card>
        <Button full size="lg" type="submit">Save changes</Button>
      </form>
    </div>
  );
}
