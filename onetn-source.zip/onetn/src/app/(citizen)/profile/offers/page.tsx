"use client";
import Link from "next/link";
import { BadgePercent, Copy } from "lucide-react";
import { useApp } from "@/lib/store";
import { COUPONS } from "@/data/delivery";
import { Card, Notice, PageHeader } from "@/components/ui";
export default function Offers() {
  const { toast } = useApp();
  const extra = [{ code: "—", desc: "Free delivery on Ration for senior citizens, persons with disabilities and patients (as decided by department)", h: "/services/ration" }, { code: "—", desc: "Free delivery above ₹199 at Sri Annapoorna Tiffin Centre (restaurant-funded)", h: "/services/food/restaurant?id=annapoorna" }];
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      <PageHeader title="Offers" />
      {COUPONS.map((c) => <Card key={c.code} className="flex items-center gap-3"><BadgePercent className="text-success" /><div className="flex-1"><p className="font-bold">{c.code}</p><p className="text-sm text-muted">{c.desc}</p></div><button aria-label="Copy code" onClick={() => { navigator.clipboard?.writeText(c.code); toast("Code copied"); }}><Copy size={17} className="text-primary" /></button></Card>)}
      {extra.map((c) => <Link key={c.desc} href={c.h} className="card flex items-center gap-3 p-4"><BadgePercent className="text-[#8A6A00]" /><p className="text-sm">{c.desc}</p></Link>)}
      <Notice tone="info">Offers are funded by partners, not the Government, and are never shown on temple or government pages.</Notice>
    </div>
  );
}
