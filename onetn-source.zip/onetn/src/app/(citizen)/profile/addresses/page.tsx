"use client";
import { useState } from "react";
import { MapPin, Trash2, Plus, Check } from "lucide-react";
import { useApp } from "@/lib/store";
import { Button, Card, Field, Input, PageHeader, Sheet, Chip } from "@/components/ui";
import { uid } from "@/lib/utils";

export default function Addresses() {
  const { s, set, toast } = useApp();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ label: "Home", line: "", pincode: "" });
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      <PageHeader title="Saved addresses" right={<Button size="sm" onClick={() => setOpen(true)}><Plus size={15} />Add</Button>} />
      {s.addresses.map((a) => (
        <Card key={a.id} className="flex items-start gap-3">
          <MapPin className="mt-0.5 text-primary" size={19} />
          <div className="flex-1"><p className="font-semibold">{a.label}</p><p className="text-sm text-muted">{a.line} – {a.pincode}</p></div>
          <button aria-label="Use as current location" onClick={() => { set((p) => ({ ...p, location: a.line.split(",").slice(-2).join(",").trim() })); toast("Location updated"); }} className="text-xs font-semibold text-primary"><Check size={14} className="inline" /> Use</button>
          <button aria-label="Delete" onClick={() => set((p) => ({ ...p, addresses: p.addresses.filter((x) => x.id !== a.id) }))}><Trash2 size={17} className="text-muted" /></button>
        </Card>
      ))}
      <Sheet open={open} onClose={() => setOpen(false)} title="Add address" footer={<Button full onClick={() => { if (f.line.length < 6 || !/^6\d{5}$/.test(f.pincode)) return toast("Enter address and a valid TN pincode", "error"); set((p) => ({ ...p, addresses: [...p.addresses, { id: uid("A"), ...f }] })); setOpen(false); setF({ label: "Home", line: "", pincode: "" }); toast("Address saved"); }}>Save</Button>}>
        <div className="space-y-3"><div className="flex gap-2">{["Home", "Work", "Parents' home", "Other"].map((l) => <Chip key={l} active={f.label === l} onClick={() => setF({ ...f, label: l })}>{l}</Chip>)}</div>
          <Field label="Full address"><Input value={f.line} onChange={(e) => setF({ ...f, line: e.target.value })} /></Field>
          <Field label="Pincode"><Input maxLength={6} value={f.pincode} onChange={(e) => setF({ ...f, pincode: e.target.value })} /></Field>
          <Button variant="outline" size="sm" onClick={() => navigator.geolocation?.getCurrentPosition(() => toast("Location detected (address lookup needs maps integration)", "info"), () => toast("Location permission denied", "error"))}><MapPin size={15} />Use current location</Button></div>
      </Sheet>
    </div>
  );
}
