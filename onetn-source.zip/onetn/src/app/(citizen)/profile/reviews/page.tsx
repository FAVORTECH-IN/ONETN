"use client";
import Link from "next/link";
import { useApp } from "@/lib/store";
import { Card, Empty, PageHeader, Stars } from "@/components/ui";
import { fmtDate } from "@/lib/utils";
export default function Reviews() {
  const { s } = useApp();
  const rated = s.bookings.filter((b) => b.rating);
  const pending = s.bookings.filter((b) => b.status === "completed" && !b.rating && b.module !== "government");
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="My reviews" />
      {pending.length > 0 && <Card><p className="mb-2 font-bold">Waiting for your rating</p>{pending.map((b) => <Link key={b.id} href={`/bookings/detail?id=${b.id}`} className="block py-1 text-sm text-primary">{b.title} · {b.subtitle}</Link>)}</Card>}
      {rated.length === 0 ? <Empty title="No reviews yet" /> : rated.map((b) => <Card key={b.id}><p className="font-semibold">{b.title}</p><p className="text-xs text-muted">{b.subtitle} · {fmtDate(b.createdAt)}</p><div className="mt-1"><Stars value={b.rating!} size={18} /></div>{b.review && <p className="mt-1 text-sm">“{b.review}”</p>}</Card>)}
    </div>
  );
}
