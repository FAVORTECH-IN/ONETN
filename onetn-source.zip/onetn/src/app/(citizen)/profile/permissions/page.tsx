"use client";
import { MapPin, Bell, Camera, Mic } from "lucide-react";
import { useApp } from "@/lib/store";
import { Card, Notice, PageHeader, Toggle } from "@/components/ui";

export default function Perms() {
  const { s, set, toast } = useApp();
  const rows = [{ k: "location", i: MapPin, t: "Location", d: "Nearby rides, stores and services" }, { k: "notifications", i: Bell, t: "Notifications", d: "Booking, delivery and application updates" }, { k: "camera", i: Camera, t: "Camera", d: "Upload documents, prescriptions and photos" }, { k: "microphone", i: Mic, t: "Microphone", d: "Video consultations and voice search" }];
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      <PageHeader title="Permissions" />
      {rows.map((r) => (
        <Card key={r.k} className="flex items-center gap-3"><r.i className="text-primary" /><div className="flex-1"><p className="font-semibold">{r.t}</p><p className="text-sm text-muted">{r.d}</p></div>
          <Toggle checked={!!s.consents[r.k]} onChange={(v) => { set((p) => ({ ...p, consents: { ...p.consents, [r.k]: v } })); if (v && r.k === "notifications" && "Notification" in window) Notification.requestPermission().catch(() => {}); toast(`${r.t} ${v ? "allowed" : "turned off"}`, "info"); }} label={r.t} /></Card>
      ))}
      <Notice tone="info">Your browser or phone settings may also need to allow these.</Notice>
    </div>
  );
}
