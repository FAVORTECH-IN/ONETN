"use client";
import { Check } from "lucide-react";
import { useApp } from "@/lib/store";
import { Card, PageHeader } from "@/components/ui";
export default function Lang() {
  const { s, set, toast } = useApp();
  return (
    <div className="mx-auto max-w-lg space-y-3">
      <PageHeader title="Language / மொழி" />
      {([["ta", "தமிழ்", "Tamil"], ["en", "English", "ஆங்கிலம்"]] as const).map(([l, a, b]) => (
        <Card key={l} onClick={() => { set((p) => ({ ...p, lang: l })); toast(l === "ta" ? "மொழி தமிழாக மாற்றப்பட்டது" : "Language set to English"); }} className={`flex items-center gap-3 ${s.lang === l ? "border-primary" : ""}`}>
          <span className="flex-1"><b className="block text-lg">{a}</b><span className="text-sm text-muted">{b}</span></span>{s.lang === l && <Check className="text-primary" />}
        </Card>
      ))}
    </div>
  );
}
