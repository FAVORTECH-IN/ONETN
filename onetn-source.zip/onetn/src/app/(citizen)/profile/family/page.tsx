"use client";
import { useState } from "react";
import { Trash2, Plus } from "lucide-react";
import { useApp } from "@/lib/store";
import { Avatar, Button, Card, Field, Input, Notice, PageHeader, Select, Sheet } from "@/components/ui";
import { uid } from "@/lib/utils";

export default function Family() {
  const { s, set, toast } = useApp();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", relation: "", age: "" });
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      <PageHeader title="Family members" right={<Button size="sm" onClick={() => setOpen(true)}><Plus size={15} />Add</Button>} />
      <Notice tone="info">Family members can be chosen when booking sevas, appointments, ration collection and applications. Add details only with their consent.</Notice>
      {s.family.map((m) => (
        <Card key={m.id} className="flex items-center gap-3"><Avatar name={m.name} tone="gold" /><div className="flex-1"><p className="font-semibold">{m.name}</p><p className="text-sm text-muted">{m.relation}{m.age && ` · ${m.age} yrs`}</p></div><button aria-label="Remove" onClick={() => set((p) => ({ ...p, family: p.family.filter((x) => x.id !== m.id) }))}><Trash2 size={17} className="text-muted" /></button></Card>
      ))}
      <Sheet open={open} onClose={() => setOpen(false)} title="Add family member" footer={<Button full onClick={() => { if (!f.name || !f.relation) return toast("Enter name and relation", "error"); set((p) => ({ ...p, family: [...p.family, { id: uid("F"), ...f }] })); setOpen(false); setF({ name: "", relation: "", age: "" }); toast("Added"); }}>Save</Button>}>
        <div className="space-y-3"><Field label="Name"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field><Field label="Relation"><Select placeholder="Select" value={f.relation} onChange={(e) => setF({ ...f, relation: e.target.value })} options={["Mother", "Father", "Spouse", "Son", "Daughter", "Brother", "Sister", "Grandparent", "Other"]} /></Field><Field label="Age"><Input type="number" value={f.age} onChange={(e) => setF({ ...f, age: e.target.value })} /></Field></div>
      </Sheet>
    </div>
  );
}
