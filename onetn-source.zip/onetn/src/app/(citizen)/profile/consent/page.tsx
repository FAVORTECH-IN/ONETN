"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Download, Trash2, ShieldCheck } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Notice, PageHeader, Sheet, Toggle, Input } from "@/components/ui";
import { downloadText } from "@/lib/utils";

const ROWS = [
  { k: "govDataShare", t: "Share profile with government departments", d: "Pre-fill applications at Connected / Integrated departments" },
  { k: "schemeSuggestions", t: "Scheme eligibility suggestions", d: "Use family details to suggest schemes" },
  { k: "healthData", t: "Health information with doctors", d: "Share prescriptions & appointment notes with chosen professionals" },
  { k: "location", t: "Location for services", d: "Find nearby rides, stores and temples" },
  { k: "marketing", t: "Offers from partners", d: "Partner-funded offers (never on temple or government pages)" },
];
export default function Consent() {
  const { s, set, toast, logout } = useApp();
  const r = useRouter();
  const [del, setDel] = useState(false);
  const [confirm, setConfirm] = useState("");
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <PageHeader title="Data & consent" sub="Your data belongs to you · DPDP Act, 2023" />
      <Card className="divide-y divide-line p-0">
        {ROWS.map((x) => (
          <div key={x.k} className="flex items-center gap-3 px-4 py-3.5"><div className="flex-1"><p className="text-sm font-semibold">{x.t}</p><p className="text-xs text-muted">{x.d}</p></div>
            <Toggle checked={!!s.consents[x.k]} onChange={(v) => { set((p) => ({ ...p, consents: { ...p.consents, [x.k]: v } })); toast(v ? "Consent given" : "Consent withdrawn", "info"); }} label={x.t} /></div>
        ))}
      </Card>
      <Card><p className="mb-2 flex items-center gap-2 font-bold"><ShieldCheck size={18} />Shared with</p>
        <ul className="space-y-2 text-sm">{s.bookings.filter((b) => b.module === "government").map((b) => <li key={b.id} className="flex justify-between"><span>{b.subtitle}</span><Badge>{b.title}</Badge></li>)}{!s.bookings.some((b) => b.module === "government") && <li className="text-muted">No departments yet.</li>}</ul></Card>
      <Button full variant="outline" onClick={() => { downloadText("onetn-my-data.json", JSON.stringify({ profile: s.user, addresses: s.addresses, family: s.family, consents: s.consents, bookings: s.bookings, transactions: s.txns, grievances: s.grievances }, null, 2), "application/json"); toast("Your data export downloaded"); }}><Download size={17} />Download my data</Button>
      {s.deletionRequested ? <Notice tone="warning" title="Account deletion requested">Your account will be deleted within 30 days after pending refunds and legal retention checks. Log in again to cancel.</Notice>
        : <Button full variant="ghost" className="text-error" onClick={() => setDel(true)}><Trash2 size={17} />Request account deletion</Button>}
      <Sheet open={del} onClose={() => setDel(false)} title="Delete account?" footer={<Button full variant="danger" disabled={confirm !== "DELETE"} onClick={() => { set((p) => ({ ...p, deletionRequested: true })); toast("Deletion requested"); setDel(false); logout(); r.replace("/login"); }}>Request deletion</Button>}>
        <p className="text-sm">Bookings, Wallet balance and history will be removed after required legal retention. Withdraw your Wallet balance first.</p>
        <p className="mt-3 text-sm">Type <b>DELETE</b> to confirm.</p><Input className="mt-2" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      </Sheet>
    </div>
  );
}
