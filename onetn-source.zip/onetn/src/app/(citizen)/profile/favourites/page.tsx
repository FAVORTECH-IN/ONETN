"use client";
import Link from "next/link";
import { useApp } from "@/lib/store";
import { SERVICES } from "@/data/catalog";
import { JOBS } from "@/data/jobsfood";
import { LIBRARY } from "@/data/learning";
import { Button, Card, Empty, PageHeader, SectionHeader } from "@/components/ui";
export default function Fav() {
  const { s, tx } = useApp();
  const svcs = SERVICES.filter((x) => s.favourites.includes(x.id));
  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <PageHeader title="Saved services & favourites" />
      <section><SectionHeader title="Favourite services" />{svcs.length ? <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">{svcs.map((x) => <Link key={x.id} href={x.href} className="card flex flex-col items-center gap-2 p-4 text-center"><x.icon className="text-primary" /><span className="text-sm font-semibold">{tx(x.name)}</span></Link>)}</div> : <Empty title="No favourites yet" body="Tap the heart on any service in All Services." action={<Button href="/services">All services</Button>} />}</section>
      <section><SectionHeader title="Saved jobs" />{s.savedJobs.length ? s.savedJobs.map((id) => <Link key={id} href={`/services/jobs/job?id=${id}`} className="card mb-2 block p-3 text-sm font-semibold">{JOBS.find((j) => j.id === id)?.title}</Link>) : <Card className="text-sm text-muted">None</Card>}</section>
      <section><SectionHeader title="Saved library" />{s.library.length ? s.library.map((id) => <Link key={id} href={`/services/education/library/item?id=${id}`} className="card mb-2 block p-3 text-sm font-semibold">{LIBRARY.find((l) => l.id === id)?.title}</Link>) : <Card className="text-sm text-muted">None</Card>}</section>
    </div>
  );
}
