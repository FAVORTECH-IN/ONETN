"use client";
import { useRouter } from "next/navigation";
import { UserPen, MapPin, Users, ShieldCheck, Languages, Bell, CalendarCheck, Package, Wallet, Heart, Star, BadgePercent, LifeBuoy, FileLock2, LogOut, ArrowLeftRight, Briefcase, GraduationCap } from "lucide-react";
import { useApp } from "@/lib/store";
import { Avatar, Badge, Card, ListRow, PageHeader } from "@/components/ui";
import { maskMobile } from "@/lib/utils";

export default function Profile() {
  const { s, t, logout } = useApp();
  const r = useRouter();
  const u = s.user!;
  const groups: { title: string; rows: { i: React.ComponentType<{ size?: number; className?: string }>; l: string; h: string; badge?: string }[] }[] = [
    { title: "Account", rows: [{ i: UserPen, l: "Edit profile", h: "/profile/edit" }, { i: MapPin, l: "Saved addresses", h: "/profile/addresses", badge: String(s.addresses.length) }, { i: Users, l: "Family members", h: "/profile/family", badge: String(s.family.length) }, { i: Languages, l: t("language"), h: "/profile/language", badge: s.lang === "ta" ? "தமிழ்" : "English" }] },
    { title: "Activity", rows: [{ i: CalendarCheck, l: "All bookings", h: "/bookings" }, { i: Package, l: "Order history", h: "/orders" }, { i: Wallet, l: "Payment history", h: "/wallet/history" }, { i: Heart, l: "Saved services & favourites", h: "/profile/favourites" }, { i: Star, l: "My reviews", h: "/profile/reviews" }, { i: BadgePercent, l: "Offers", h: "/profile/offers" }, { i: Briefcase, l: "Job profile & resume", h: "/services/jobs/profile" }, { i: GraduationCap, l: "Learning progress", h: "/services/education" }] },
    { title: "Privacy & settings", rows: [{ i: Bell, l: t("notifications"), h: "/notifications" }, { i: ShieldCheck, l: "Permissions", h: "/profile/permissions" }, { i: FileLock2, l: "Data consent, download & deletion", h: "/profile/consent" }] },
    { title: "Help", rows: [{ i: LifeBuoy, l: "Help centre", h: "/support" }, { i: ArrowLeftRight, l: "Switch role / partner portals", h: "/select-role" }] },
  ];
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <PageHeader title={t("profile")} back={false} />
      <Card className="flex items-center gap-4">
        {u.photo ? <img src={u.photo} alt="" className="h-16 w-16 rounded-full object-cover" /> : <Avatar name={u.name} size={64} />}
        <div className="flex-1"><p className="text-lg font-bold">{u.name}</p><p className="text-sm text-muted">+91 {maskMobile(u.mobile)}{u.email && ` · ${u.email}`}</p><p className="text-sm text-muted">{[u.city, u.district].filter(Boolean).join(", ")}</p></div>
        <Badge tone="success">Verified</Badge>
      </Card>
      {!u.email || !u.dob ? <Card className="flex items-center gap-3 bg-gold-soft" onClick={() => r.push("/profile/edit")}><UserPen className="text-[#8A6A00]" /><span className="flex-1 text-sm"><b>Complete your profile</b> – add email and date of birth for faster applications.</span></Card> : null}
      {groups.map((g) => (
        <section key={g.title}><p className="mb-2 text-sm font-bold text-muted">{g.title}</p>
          <Card className="divide-y divide-line p-0">{g.rows.map((x) => <ListRow key={x.l} href={x.h} icon={<x.i size={19} className="text-primary" />} title={x.l} right={x.badge ? <Badge>{x.badge}</Badge> : undefined} />)}</Card>
        </section>
      ))}
      <Card className="p-0"><ListRow onClick={() => { logout(); r.replace("/login"); }} icon={<LogOut size={19} className="text-error" />} title={<span className="text-error">{t("logout")}</span>} /></Card>
      <p className="text-center text-xs text-muted">ONETN · One Platform. Every Service. · v0.1 demo</p>
    </div>
  );
}
