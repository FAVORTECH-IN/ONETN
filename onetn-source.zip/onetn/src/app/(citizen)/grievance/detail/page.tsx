"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ArrowUpCircle, Send } from "lucide-react";
import { useApp, type GStatus } from "@/lib/store";
import { Badge, Button, Card, Empty, KV, Notice, PageHeader, SimTag, Stars, Textarea, statusTone } from "@/components/ui";
import { fmtDate } from "@/lib/utils";

const FLOW: GStatus[] = ["Submitted", "Under Review", "Assigned", "In Progress", "Resolved", "Closed"];

function Inner() {
  const id = useSearchParams().get("id");
  const { s, set, toast, notify } = useApp();
  const g = s.grievances.find((x) => x.id === id);
  const [info, setInfo] = useState("");
  const [fb, setFb] = useState(0);
  if (!g) return <Empty title="Complaint not found" action={<Button href="/grievance">All complaints</Button>} />;
  const push = (status: GStatus, note: string) => {
    set((p) => ({ ...p, grievances: p.grievances.map((x) => (x.id === g.id ? { ...x, status, history: [...x.history, { status, note, at: new Date().toISOString() }] } : x)) }));
    notify(`Complaint ${g.id}: ${status}`, note, `/grievance/detail?id=${g.id}`);
  };
  const advance = () => {
    const i = FLOW.indexOf(g.status);
    if (g.status === "Awaiting Information") return;
    const nx = FLOW[Math.min(FLOW.length - 1, i + 1)];
    const notes: Record<string, string> = { "Under Review": "Support team reviewing your complaint", Assigned: `Assigned to ${g.service} resolution team`, "In Progress": "Team has contacted the partner", Resolved: "Issue resolved. Any refund has been credited to your Wallet.", Closed: "Complaint closed" };
    if (nx === "In Progress" && !g.history.some((h) => h.status === "Awaiting Information")) { push("Awaiting Information", "Please share the time of delivery and a photo if available"); return; }
    push(nx, notes[nx] ?? "");
  };
  const done = g.status === "Resolved" || g.status === "Closed";
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={`Complaint ${g.id}`} sub={`${g.service} · ${g.category}`} right={<Badge tone={statusTone(g.status)}>{g.status}</Badge>} />
      <Card><KV rows={[["Raised on", fmtDate(g.createdAt, true)], ["Reference", g.ref || "—"], ["Assigned team", g.history.some((h) => h.status === "Assigned") ? `${g.service} resolution team` : "Pending"], ["Attachments", g.attachments?.length ? g.attachments.join(", ") : "—"]]} /><p className="mt-3 rounded-2xl bg-cream p-3 text-sm">{g.description}</p></Card>
      <Card>
        <div className="mb-3 flex items-center justify-between"><p className="font-bold">Updates</p><SimTag /></div>
        <ol className="space-y-3 border-l-2 border-line pl-4">
          {g.history.map((h, i) => <li key={i}><Badge tone={statusTone(h.status)}>{h.status}</Badge><p className="mt-1 text-sm">{h.note}</p><p className="text-xs text-muted">{fmtDate(h.at, true)}</p></li>)}
        </ol>
        {!done && <Button size="sm" variant="soft" className="mt-4" onClick={advance} disabled={g.status === "Awaiting Information"}>Simulate team update</Button>}
      </Card>
      {g.status === "Awaiting Information" && (
        <Card className="space-y-3 border-warning">
          <p className="font-bold">Additional information requested</p>
          <Textarea value={info} onChange={(e) => setInfo(e.target.value)} placeholder="Add details" />
          <Button disabled={info.trim().length < 3} onClick={() => { push("In Progress", `You added: ${info.trim()}`); setInfo(""); toast("Information sent"); }}><Send size={16} />Send</Button>
        </Card>
      )}
      {!done && (
        <Card className="flex items-center gap-3">
          <ArrowUpCircle className="text-warning" />
          <div className="flex-1"><p className="font-semibold">Not happy with progress?</p><p className="text-sm text-muted">Escalate to the next level. Unresolved cases go to the Government grievance review.</p></div>
          <Button size="sm" variant="outline" onClick={() => { push(g.status, "Escalated to Level 2 – senior grievance officer"); toast("Escalated"); }}>Escalate</Button>
        </Card>
      )}
      {done && (
        <Card>
          {g.feedback ? <><p className="font-bold">Your feedback</p><Stars value={g.feedback} /></> : (
            <><p className="font-bold">How was the resolution?</p><div className="my-2"><Stars value={fb} onChange={setFb} size={28} /></div>
              <div className="flex gap-2"><Button disabled={!fb} onClick={() => { set((p) => ({ ...p, grievances: p.grievances.map((x) => (x.id === g.id ? { ...x, feedback: fb, status: "Closed", history: [...x.history, { status: "Closed", note: `Closed with feedback ${fb}/5`, at: new Date().toISOString() }] } : x)) })); toast("Thank you for the feedback"); }}>Submit & close</Button>
                <Button variant="outline" onClick={() => push("Under Review", "Reopened by citizen – not satisfied")}>Reopen</Button></div></>
          )}
        </Card>
      )}
      <Notice tone="info">Need to talk? Call the help desk (Tamil/English) or use chat in Help & Support.</Notice>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
