"use client";
import Link from "next/link";
import { useState } from "react";
import { FileText, Plus } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Empty, PageHeader, Tabs, statusTone, Notice } from "@/components/ui";
import { fmtDate } from "@/lib/utils";

export default function Grievances() {
  const { s, t } = useApp();
  const [tab, setTab] = useState<"open" | "closed">("open");
  const list = s.grievances.filter((g) => (tab === "open" ? !["Resolved", "Closed"].includes(g.status) : ["Resolved", "Closed"].includes(g.status)));
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={t("grievance")} sub="Raise and track complaints for any ONETN service" right={<Button size="sm" href="/grievance/new"><Plus size={16} />New</Button>} />
      <Tabs className="mb-4" value={tab} onChange={setTab} tabs={[{ value: "open", label: "Open" }, { value: "closed", label: "Resolved / closed" }]} />
      {list.length === 0 ? <Empty title="No complaints here" body="Something went wrong with a booking, order or application? We'll track it until it's resolved." action={<Button href="/grievance/new">Raise a complaint</Button>} /> : (
        <div className="space-y-3">
          {list.map((g) => (
            <Link key={g.id} href={`/grievance/detail?id=${g.id}`} className="card flex items-center gap-3 p-4">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary-soft text-primary"><FileText size={20} /></span>
              <div className="min-w-0 flex-1"><p className="font-semibold">{g.service} – {g.category}</p><p className="truncate text-sm text-muted">{g.description}</p><p className="text-xs text-muted">{g.id} · {fmtDate(g.createdAt)}</p></div>
              <Badge tone={statusTone(g.status)}>{g.status}</Badge>
            </Link>
          ))}
        </div>
      )}
      <Notice tone="info" className="mt-5">Unresolved complaints move up automatically to a higher level, then to the Government&apos;s grievance review. Help available in Tamil and English.</Notice>
    </div>
  );
}
