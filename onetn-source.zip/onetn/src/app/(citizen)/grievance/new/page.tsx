"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Paperclip, X } from "lucide-react";
import { useApp, type Grievance } from "@/lib/store";
import { Button, Card, Field, Notice, PageHeader, Select, Textarea } from "@/components/ui";
import { uid } from "@/lib/utils";

const SERVICES = ["Auto / Cab ride", "Bus ticket", "Parcel", "Quick Delivery", "Ration delivery", "Milk subscription", "Medicine delivery", "Uzhavar Sandhai", "Co-op supermarket", "Home services", "Government application", "Temple services", "Education", "Healthcare appointment", "Jobs", "Food & restaurants", "Wallet / payment", "App / account", "Other"];
const CATS: Record<string, string[]> = { default: ["Delay", "Wrong / missing item", "Damaged / poor quality", "Overcharging / refund", "Behaviour of partner", "Safety concern", "Payment issue", "Other"], "Government application": ["Delay beyond normal time", "Incorrect rejection", "Document issue", "Other"], "Jobs": ["Fake / misleading job", "Employer asked for money", "Other"] };

function Inner() {
  const sp = useSearchParams();
  const { s, set, notify, toast } = useApp();
  const r = useRouter();
  const [svc, setSvc] = useState(sp.get("service") ? "Other" : "");
  const [cat, setCat] = useState("");
  const [ref, setRef] = useState(sp.get("ref") ?? "");
  const [desc, setDesc] = useState(sp.get("service") ? `Regarding: ${sp.get("service")}\n` : "");
  const [files, setFiles] = useState<string[]>([]);
  const [err, setErr] = useState("");
  const submit = () => {
    if (!svc) return setErr("Select the service");
    if (!cat) return setErr("Select a complaint category");
    if (desc.trim().length < 15) return setErr("Describe the problem in at least 15 characters");
    const now = new Date().toISOString();
    const g: Grievance = { id: uid("GRV"), service: svc, category: cat, ref, description: desc.trim(), createdAt: now, status: "Submitted", attachments: files, history: [{ status: "Submitted", note: "Complaint registered", at: now }] };
    set((p) => ({ ...p, grievances: [g, ...p.grievances] }));
    notify("Complaint registered", `${g.id} · we'll update you in Tamil and English`, `/grievance/detail?id=${g.id}`);
    toast(`Complaint ${g.id} submitted`);
    r.push(`/grievance/detail?id=${g.id}`);
  };
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Raise a complaint" sub="We track every complaint to resolution" />
      <Card className="space-y-4">
        <Field label="Service" required><Select placeholder="Select service" value={svc} onChange={(e) => { setSvc(e.target.value); setCat(""); }} options={SERVICES} /></Field>
        <Field label="Complaint category" required><Select placeholder="Select category" value={cat} onChange={(e) => setCat(e.target.value)} options={CATS[svc] ?? CATS.default} /></Field>
        <Field label="Booking / order / application reference" hint="Optional but speeds things up">
          <Select value={ref} onChange={(e) => setRef(e.target.value)} placeholder="None" options={s.bookings.map((b) => ({ value: b.id, label: `${b.id} – ${b.title}` }))} />
        </Field>
        <Field label="Describe the problem" required><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="What happened? When?" className="min-h-32" /></Field>
        <div>
          <p className="mb-2 text-sm font-semibold">Photos / documents</p>
          <div className="flex flex-wrap gap-2">
            {files.map((f, i) => <span key={i} className="flex items-center gap-1 rounded-full bg-cream px-3 py-1 text-xs">{f}<button aria-label="Remove" onClick={() => setFiles(files.filter((_, k) => k !== i))}><X size={12} /></button></span>)}
            <label className="flex cursor-pointer items-center gap-1 rounded-full border border-dashed border-primary/50 px-3 py-1 text-xs font-semibold text-primary"><Paperclip size={13} />Attach<input type="file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setFiles([...files, f.name]); }} /></label>
          </div>
        </div>
        {err && <Notice tone="error">{err}</Notice>}
        <Button full size="lg" onClick={submit}>Submit complaint</Button>
      </Card>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
