"use client";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Phone, Share2, Siren, Download, RotateCcw, XCircle, MessageSquareWarning, ShieldCheck, Video, Pause, Play, PencilLine, FileUp, FileCheck2, KeyRound, Camera, CalendarPlus } from "lucide-react";
import { Avatar, Badge, Button, Card, Empty, KV, Notice, PageHeader, Rating, Sheet, SimTag, Stars, Textarea, Timeline, statusTone, Input } from "@/components/ui";
import { FeeTable } from "@/components/flows/Payment";
import { MapView } from "@/components/flows/MapView";
import { QR } from "@/components/flows/QR";
import { useApp, type Booking } from "@/lib/store";
import { downloadText, fmtDate, inr } from "@/lib/utils";

const LIVE = ["auto", "cab", "parcel", "grocery", "ration", "medicine", "uzhavar", "coop", "prasadam", "food", "home"];
const RIDE = ["auto", "cab"];
const DELIVERY = ["parcel", "grocery", "ration", "medicine", "uzhavar", "coop", "prasadam", "food"];

function receiptText(b: Booking) {
  return [`ONETN – RECEIPT`, `Reference: ${b.id}`, `Service: ${b.title}`, b.subtitle ?? "", `Date: ${fmtDate(b.createdAt, true)}`, ``,
    ...(b.items ?? []).map((i) => `${i.name} x${i.qty}  ${inr(i.price * i.qty)}`), ``,
    ...b.fees.map((f) => `${f.label}${f.payee ? ` (to ${f.payee})` : ""}: ${inr(f.amount)}`), `TOTAL: ${inr(b.amount)}`, `Paid via: ${b.payment}`, ``,
    `This is a demo receipt from a simulated transaction.`].join("\n");
}

function Detail() {
  const id = useSearchParams().get("id");
  const { s, updateBooking, credit, notify, toast, setQty } = useApp();
  const r = useRouter();
  const b = s.bookings.find((x) => x.id === id);
  const [rate, setRate] = useState(0);
  const [review, setReview] = useState("");
  const [cancelOpen, setCancelOpen] = useState(false);
  const [videoOpen, setVideoOpen] = useState(false);
  const [sosOpen, setSosOpen] = useState(false);
  const [modify, setModify] = useState(false);
  const [qtyEdit, setQtyEdit] = useState(1);

  const live = b && LIVE.includes(b.module) && b.status === "active";
  const blocked = b?.extraApproval?.state === "pending" || (b?.module === "government" && b.details["Action needed"] === "Yes");
  useEffect(() => {
    if (!b || !live || blocked) return;
    if (b.stageIdx >= b.stages.length - 1) return;
    const t = setTimeout(() => advance(), 7000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [b?.stageIdx, live, blocked]);

  if (!b) return <><PageHeader title="Booking" /><Empty title="Booking not found" body="It may have been created on another device." action={<Button href="/bookings">All bookings</Button>} /></>;

  function advance() {
    if (!b) return;
    const next = b.stageIdx + 1;
    const last = next >= b.stages.length - 1;
    const patch: Partial<Booking> = { stageIdx: Math.min(next, b.stages.length - 1), status: last ? "completed" : b.status };
    // home services: raise an additional-work estimate at assessment stage
    if (b.module === "home" && b.stages[next] === "Job assessment" && !b.extraApproval) patch.extraApproval = { desc: "Replace worn-out washer and add 1 m PVC pipe (materials + labour)", amount: 180, state: "pending" };
    if (b.module === "government" && b.stages[next] === "Additional documents requested") patch.details = { ...b.details, "Action needed": "Yes", "Department note": "Please upload a clearer copy of the school transfer certificate." };
    updateBooking(b.id, patch);
    notify(`${b.title}: ${b.stages[patch.stageIdx!]}`, b.id, `/bookings/detail?id=${b.id}`);
  }
  const cancel = () => {
    const refund = b.payment === "Cash" ? 0 : b.amount;
    updateBooking(b.id, { status: "cancelled" });
    if (refund > 0) credit(refund, `Refund – ${b.title} (${b.id})`, "Refunds", "Wallet");
    notify("Booking cancelled", refund ? `${inr(refund)} refunded to your Wallet` : b.id);
    toast(refund ? `Cancelled · ${inr(refund)} refunded to Wallet` : "Cancelled");
    setCancelOpen(false);
  };
  const repeat = () => {
    const key = b.details["_cart"];
    if (key && b.items) b.items.forEach((i, k) => setQty(key, { id: `${b.id}-${k}-${i.name}`, name: i.name, price: i.price }, i.qty));
    toast("Items added to cart");
    r.push(b.details["_repeat"] ?? "/services");
  };
  const canCancel = b.status === "active" && b.stageIdx <= 1 && b.module !== "government";
  const vehicle = b.module === "auto" || b.module === "cab" ? (b.details["Vehicle"]?.includes("Bike") ? "bike" : "car") : b.module === "parcel" ? "box" : "bike";
  const showMap = (RIDE.includes(b.module) || DELIVERY.includes(b.module)) && b.status !== "cancelled";
  const progress = b.status === "completed" ? 1 : b.stageIdx / Math.max(1, b.stages.length - 1);
  const isTicket = ["bus", "metro", "table", "takeaway", "temple"].includes(b.module);

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={b.title} sub={`${b.id} · ${fmtDate(b.createdAt, true)}`} backHref="/bookings" right={<Badge tone={statusTone(b.status)}>{b.status === "active" ? b.stages[b.stageIdx] : b.status}</Badge>} />
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {showMap && <MapView from={b.details["Pickup"] ?? b.details["From"]} to={b.details["Drop"] ?? b.details["To"]} progress={b.stageIdx >= 2 ? progress : 0} vehicle={vehicle as "car"} className="h-56 sm:h-72" label={b.stages[b.stageIdx]} />}

          {b.provider && b.status !== "cancelled" && (
            <Card>
              <div className="flex items-center gap-3">
                <Avatar name={b.provider.name} size={52} />
                <div className="min-w-0 flex-1">
                  <p className="font-bold">{b.provider.name} <ShieldCheck size={15} className="inline text-success" /></p>
                  <p className="text-sm text-muted">{b.provider.vehicle ?? b.provider.extra}</p>
                  {b.provider.rating && <Rating value={b.provider.rating} />}
                </div>
                <a href="tel:1800000000" aria-label="Call" className="grid h-11 w-11 place-items-center rounded-full bg-success-soft text-success"><Phone size={19} /></a>
              </div>
              {b.otp && b.status === "active" && (RIDE.includes(b.module) || DELIVERY.includes(b.module) || b.module === "home") && (
                <div className="mt-3 flex items-center justify-between rounded-2xl bg-gold-soft px-4 py-3">
                  <span className="flex items-center gap-2 text-sm font-semibold text-[#5E4700]"><KeyRound size={16} />{RIDE.includes(b.module) ? "Share OTP to start trip" : b.module === "home" ? "Share OTP when work is complete" : "Delivery OTP – share only at your door"}</span>
                  <span className="text-xl font-extrabold tracking-[.3em]">{b.otp}</span>
                </div>
              )}
              {RIDE.includes(b.module) && b.status === "active" && (
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Button variant="outline" onClick={() => { navigator.clipboard?.writeText(`I'm on an ONETN ride ${b.id}: ${b.subtitle}. Driver ${b.provider?.name}, ${b.provider?.vehicle}.`); toast("Trip details copied – share with family"); }}><Share2 size={17} />Share trip</Button>
                  <Button variant="danger" onClick={() => setSosOpen(true)}><Siren size={17} />SOS</Button>
                </div>
              )}
            </Card>
          )}

          {b.extraApproval && (
            <Card className={b.extraApproval.state === "pending" ? "border-warning" : ""}>
              <p className="font-bold">Additional work estimate</p>
              <p className="mt-1 text-sm text-muted">{b.extraApproval.desc}</p>
              <p className="mt-2 text-lg font-bold">{inr(b.extraApproval.amount)}</p>
              {b.extraApproval.state === "pending" ? (
                <>
                  <Notice tone="warning" className="mt-2">Nothing extra is charged without your approval. Work is paused until you decide.</Notice>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <Button variant="outline" onClick={() => { updateBooking(b.id, { extraApproval: { ...b.extraApproval!, state: "declined" } }); toast("Extra work declined – only the booked job will be done", "info"); }}>Decline</Button>
                    <Button onClick={() => {
                      updateBooking(b.id, { extraApproval: { ...b.extraApproval!, state: "approved" }, fees: [...b.fees, { label: "Approved additional work", amount: b.extraApproval!.amount }], amount: b.amount + b.extraApproval!.amount });
                      if (b.payment === "Wallet") credit(-b.extraApproval!.amount, `Additional work – ${b.id}`, "Home services", "Wallet");
                      toast("Additional work approved");
                    }}>Approve {inr(b.extraApproval.amount)}</Button>
                  </div>
                </>
              ) : <Badge tone={b.extraApproval.state === "approved" ? "success" : "neutral"} className="mt-2">{b.extraApproval.state}</Badge>}
            </Card>
          )}

          {b.module === "government" && b.details["Action needed"] === "Yes" && b.status === "active" && (
            <Card className="border-warning">
              <p className="flex items-center gap-2 font-bold"><FileUp size={18} />Additional document requested</p>
              <p className="mt-1 text-sm text-muted">{b.details["Department note"]}</p>
              <label className="mt-3 block"><input type="file" className="text-sm" onChange={(e) => {
                if (!e.target.files?.[0]) return;
                updateBooking(b.id, { details: { ...b.details, "Action needed": "No", "Resubmitted": e.target.files[0].name } });
                toast("Document resubmitted to department");
              }} /></label>
            </Card>
          )}

          {isTicket && b.status !== "cancelled" && (
            <Card className="flex flex-col items-center text-center">
              <p className="text-sm font-semibold text-muted">{b.module === "takeaway" ? "Show this order code at pickup" : b.module === "table" ? "Show at the restaurant" : "Show this QR at boarding / entry"}</p>
              <div className="my-3"><QR value={b.id} /></div>
              <p className="text-2xl font-extrabold tracking-widest">{b.module === "takeaway" ? b.otp : b.id}</p>
              {b.details["Seats"] && <p className="mt-1 text-sm">Seats: <b>{b.details["Seats"]}</b></p>}
            </Card>
          )}

          <Card>
            <div className="mb-3 flex items-center justify-between"><p className="font-bold">Status</p>{live && <SimTag label="Simulated tracking" />}</div>
            {b.status === "cancelled" ? <Notice tone="error" title="Cancelled">{b.payment !== "Cash" && b.amount > 0 ? `${inr(b.amount)} refunded to your Wallet.` : "No charge was made."}</Notice>
              : b.status === "paused" ? <Notice tone="warning" title="Subscription paused">Deliveries are on hold until you resume.</Notice>
              : <Timeline stages={b.stages} current={b.status === "completed" ? b.stages.length : b.stageIdx} />}
            {b.status === "active" && b.stageIdx < b.stages.length - 1 && (
              <Button variant="soft" size="sm" className="mt-4" disabled={blocked} onClick={advance}>{blocked ? "Waiting for your action" : "Simulate next update"}</Button>
            )}
            {b.module === "government" && b.status === "completed" && (
              b.details["Outcome"] === "Rejected"
                ? <Notice tone="error" title="Application rejected" className="mt-4">{b.details["Reason"]}</Notice>
                : <Button variant="success" className="mt-4" onClick={() => downloadText(`${b.id}-certificate.txt`, `DEMO CERTIFICATE\n${b.title}\nApplicant: ${s.user?.name}\nReference: ${b.id}\nThis demo document is not a valid government certificate.`)}><FileCheck2 size={17} />Download certificate (demo)</Button>
            )}
            {DELIVERY.includes(b.module) && b.status === "completed" && (
              <div className="mt-4 flex items-center gap-3 rounded-2xl bg-success-soft p-3 text-sm text-success"><Camera size={18} />Proof of delivery: OTP verified at door · photo captured by rider (simulated)</div>
            )}
          </Card>

          {b.kind === "subscription" && b.status !== "cancelled" && (
            <Card>
              <p className="mb-2 font-bold">Manage subscription</p>
              <div className="flex flex-wrap gap-2">
                {b.status === "paused"
                  ? <Button size="sm" onClick={() => { updateBooking(b.id, { status: "active" }); toast("Subscription resumed"); }}><Play size={15} />Resume</Button>
                  : <Button size="sm" variant="outline" onClick={() => { updateBooking(b.id, { status: "paused" }); toast("Subscription paused", "info"); }}><Pause size={15} />Pause</Button>}
                <Button size="sm" variant="outline" onClick={() => { setQtyEdit(Number(b.details["Quantity / day"]?.split(" ")[0] ?? 1)); setModify(true); }}><PencilLine size={15} />Modify</Button>
                <Button size="sm" variant="ghost" onClick={() => setCancelOpen(true)}>Cancel subscription</Button>
              </div>
              <p className="mt-4 text-sm font-semibold">Delivery history</p>
              <ul className="mt-2 divide-y divide-line text-sm">
                {Array.from({ length: 5 }).map((_, i) => { const d = new Date(Date.now() - (i + 1) * 864e5); return <li key={i} className="flex justify-between py-2"><span>{fmtDate(d)} · 6:10 AM</span><Badge tone="success">Delivered</Badge></li>; })}
              </ul>
            </Card>
          )}

          {b.kind === "appointment" && b.status === "active" && b.details["Mode"]?.includes("Video") && (
            <Card className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary-soft text-primary"><Video /></span>
              <div className="flex-1"><p className="font-semibold">Video consultation</p><p className="text-sm text-muted">Room opens 10 minutes before {b.when}</p></div>
              <Button size="sm" onClick={() => setVideoOpen(true)}>Join</Button>
            </Card>
          )}

          {b.status === "completed" && b.module !== "government" && (
            <Card>
              {b.rating ? (<><p className="font-bold">Your rating</p><Stars value={b.rating} />{b.review && <p className="mt-2 text-sm text-muted">“{b.review}”</p>}</>) : (
                <>
                  <p className="font-bold">Rate your experience</p>
                  <div className="my-2"><Stars value={rate} onChange={setRate} size={30} /></div>
                  <Textarea placeholder="Tell us more (optional)" value={review} onChange={(e) => setReview(e.target.value)} />
                  <Button className="mt-3" disabled={!rate} onClick={() => { updateBooking(b.id, { rating: rate, review }); toast("Thanks for your feedback"); }}>Submit rating</Button>
                </>
              )}
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card>
            <p className="mb-2 font-bold">Details</p>
            <KV rows={Object.entries(b.details).filter(([k]) => !k.startsWith("_")).map(([k, v]) => [k, v])} />
            {b.when && <KV rows={[["Scheduled", b.when]]} />}
          </Card>
          {b.items && b.items.length > 0 && (
            <Card>
              <p className="mb-2 font-bold">Items</p>
              <KV rows={b.items.map((i) => [`${i.name} × ${i.qty}`, inr(i.price * i.qty)])} />
            </Card>
          )}
          <Card>
            <p className="mb-2 font-bold">Payment</p>
            <FeeTable fees={b.fees} total={b.amount} />
            <p className="mt-2 text-xs text-muted">Paid via {b.payment} · simulated</p>
          </Card>
          <div className="grid gap-2">
            <Button variant="outline" onClick={() => downloadText(`ONETN-${b.id}-receipt.txt`, receiptText(b))}><Download size={17} />Download receipt</Button>
            {b.details["_cart"] && b.status === "completed" && <Button variant="outline" onClick={repeat}><RotateCcw size={17} />Repeat order</Button>}
            {b.kind === "appointment" && b.status === "active" && <Button variant="outline" onClick={() => downloadText(`${b.id}.ics`, `BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nSUMMARY:${b.title}\nDESCRIPTION:${b.id}\nEND:VEVENT\nEND:VCALENDAR`, "text/calendar")}><CalendarPlus size={17} />Add to calendar</Button>}
            {canCancel && <Button variant="outline" onClick={() => setCancelOpen(true)}><XCircle size={17} />Cancel</Button>}
            <Button variant="ghost" href={`/grievance/new?ref=${b.id}&service=${encodeURIComponent(b.title)}`}><MessageSquareWarning size={17} />Report an issue / refund</Button>
          </div>
          {b.module === "home" && <Notice tone="success" title="Service guarantee">If the work isn&apos;t right, it will be corrected at no extra cost. Raise it within 7 days.</Notice>}
        </div>
      </div>

      <Sheet open={cancelOpen} onClose={() => setCancelOpen(false)} title="Cancel?" footer={<div className="flex gap-2"><Button variant="outline" full onClick={() => setCancelOpen(false)}>Keep it</Button><Button variant="danger" full onClick={cancel}>Yes, cancel</Button></div>}>
        <p>Cancellation is free at this stage{b.payment !== "Cash" && b.amount > 0 ? ` and ${inr(b.amount)} will be refunded instantly to your Wallet` : ""}.</p>
        <p className="mt-2 text-sm text-muted">Fair cancellation rules apply equally to customers and partners.</p>
      </Sheet>
      <Sheet open={sosOpen} onClose={() => setSosOpen(false)} title="Emergency SOS">
        <div className="space-y-3">
          <Notice tone="error" title="Simulated emergency alert">In production this alerts the platform safety desk and your trusted contacts with live location.</Notice>
          <Button variant="danger" full href="tel:112"><Siren size={18} />Call 112 (emergency)</Button>
          <Button variant="outline" full href="tel:181">Women helpline 181</Button>
          <Button variant="outline" full onClick={() => { toast("Safety desk alerted (simulated)"); setSosOpen(false); }}>Alert ONETN safety desk</Button>
        </div>
      </Sheet>
      <Sheet open={videoOpen} onClose={() => setVideoOpen(false)} title="Video consultation">
        <div className="grid aspect-video place-items-center rounded-2xl bg-ink text-white"><div className="text-center"><Video size={40} className="mx-auto opacity-70" /><p className="mt-2 text-sm opacity-80">Connecting to {b.provider?.name}…</p><p className="text-xs opacity-60">Video provider not yet integrated – simulated room</p></div></div>
        <Notice tone="info" className="mt-3">Health information is private and shared only with your consent.</Notice>
      </Sheet>
      <Sheet open={modify} onClose={() => setModify(false)} title="Modify subscription" footer={<Button full onClick={() => { updateBooking(b.id, { details: { ...b.details, "Quantity / day": `${qtyEdit} packet(s)` } }); setModify(false); toast("Subscription updated"); }}>Save</Button>}>
        <label className="block text-sm font-semibold">Packets per delivery</label>
        <Input type="number" min={1} max={10} value={qtyEdit} onChange={(e) => setQtyEdit(Math.max(1, Number(e.target.value)))} className="mt-2" />
        <Link href="/services/milk" className="mt-3 block text-sm font-semibold text-primary">Change product or schedule →</Link>
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Detail /></Suspense>; }
