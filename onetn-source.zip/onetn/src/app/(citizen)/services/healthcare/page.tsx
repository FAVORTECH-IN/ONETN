"use client";
import Link from "next/link";
import { useState } from "react";
import { Search, Video, MapPin, Pill, Syringe } from "lucide-react";
import { DOCTORS, SPECIALITIES } from "@/data/learning";
import { useApp } from "@/lib/store";
import { Avatar, Badge, Card, Chip, Empty, Notice, PageHeader, Rating, SectionHeader } from "@/components/ui";
import { BookingRow } from "@/components/flows/BookingList";
import { inr } from "@/lib/utils";

export default function Health() {
  const { s } = useApp();
  const [sp, setSp] = useState("All");
  const [q, setQ] = useState("");
  const [video, setVideo] = useState(false);
  const list = DOCTORS.filter((d) => (sp === "All" || d.spec === sp) && (!video || d.mode.includes("Video")) && (!q || (d.name + d.spec + d.hospital).toLowerCase().includes(q.toLowerCase())));
  const hist = s.bookings.filter((b) => b.module === "healthcare");
  return (
    <div className="space-y-5">
      <PageHeader title="Healthcare Appointments" sub="Verified doctors · in person or video" />
      <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search doctor, speciality or clinic" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", ...SPECIALITIES].map((x) => <Chip key={x} active={sp === x} onClick={() => setSp(x)}>{x}</Chip>)}<Chip active={video} onClick={() => setVideo(!video)}><Video size={14} className="mr-1 inline" />Video available</Chip></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Link href="/services/medicines" className="card flex items-center gap-3 p-3"><Pill className="text-primary" /><span className="text-sm font-semibold">Order medicines</span></Link>
        <Link href="/services/home-services/nurse" className="card flex items-center gap-3 p-3"><Syringe className="text-primary" /><span className="text-sm font-semibold">Book a home nurse</span></Link>
      </div>
      {list.length === 0 ? <Empty title="No doctors match" /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((d) => (
            <Link key={d.id} href={`/services/healthcare/doctor?id=${d.id}`} className="card flex gap-3 p-4 hover:shadow-[var(--shadow-lift)]">
              <Avatar name={d.name.replace("Dr. ", "")} size={60} tone="gold" />
              <div className="min-w-0 flex-1">
                <p className="font-bold">{d.name}</p><p className="text-sm text-muted">{d.spec} · {d.qual}</p>
                <p className="flex items-center gap-1 text-xs text-muted"><MapPin size={12} />{d.hospital}</p>
                <div className="mt-2 flex flex-wrap items-center gap-2"><Rating value={d.rating} /><Badge tone="success">Reg. verified</Badge>{d.mode.includes("Video") && <Badge tone="info">Video</Badge>}<span className="ml-auto font-bold">{inr(d.fee)}</span></div>
              </div>
            </Link>
          ))}
        </div>
      )}
      {hist.length > 0 && <section><SectionHeader title="Appointment history" /><div className="space-y-2">{hist.map((b) => <BookingRow key={b.id} b={b} />)}</div></section>}
      <Notice tone="info">Health information is private, handled with higher protection and shared only with your consent.</Notice>
    </div>
  );
}
