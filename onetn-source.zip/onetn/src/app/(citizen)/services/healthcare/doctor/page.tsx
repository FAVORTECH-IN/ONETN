"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ShieldCheck, MapPin, Languages, CalendarDays } from "lucide-react";
import { DOCTORS, APPT_SLOTS } from "@/data/learning";
import { Avatar, Badge, Button, Card, Empty, KV, PageHeader, Rating } from "@/components/ui";
import { AppointmentSheet } from "@/components/flows/Appointment";
import { dayLabel, inr, nextDays } from "@/lib/utils";

function Inner() {
  const d = DOCTORS.find((x) => x.id === useSearchParams().get("id"));
  const [open, setOpen] = useState(false);
  if (!d) return <Empty title="Doctor not found" />;
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={d.name} sub={d.spec} />
      <Card className="flex items-center gap-4"><Avatar name={d.name.replace("Dr. ", "")} size={76} tone="gold" /><div><p className="text-lg font-bold">{d.name} <ShieldCheck size={16} className="inline text-success" /></p><p className="text-muted">{d.qual}</p><Rating value={d.rating} count={420} /></div></Card>
      <Card><KV rows={[["Registration", d.reg], ["Experience", `${d.exp} years`], [<span key="h" className="flex items-center gap-1"><MapPin size={14} />Clinic</span>, d.hospital], [<span key="l" className="flex items-center gap-1"><Languages size={14} />Languages</span>, d.lang], ["Consultation fee", inr(d.fee)], ["Modes", d.mode.join(", ")]]} /></Card>
      <Card>
        <p className="mb-3 flex items-center gap-2 font-bold"><CalendarDays size={18} />Availability this week</p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{nextDays(5).slice(1).map((dt, i) => <div key={i} className="rounded-2xl bg-cream p-3 text-center"><p className="text-sm font-semibold">{dayLabel(dt)}</p><p className="text-xs text-success">{APPT_SLOTS.length - ((i * 3) % 5)} slots</p></div>)}</div>
      </Card>
      <div className="flex flex-wrap gap-2">{d.mode.map((m) => <Badge key={m} tone="info">{m === "Video" ? "Video consultation (in-app)" : "In-person appointment"}</Badge>)}</div>
      <Button full size="lg" onClick={() => setOpen(true)}>Book appointment</Button>
      <AppointmentSheet open={open} onClose={() => setOpen(false)} who={d.name} role={d.spec} fee={d.fee} modes={d.mode} module="healthcare" place={d.hospital} privateNote />
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
