"use client";
import Link from "next/link";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Search, Heart } from "lucide-react";
import { useApp } from "@/lib/store";
import { SERVICES } from "@/data/catalog";
import { Chip, Empty, PageHeader } from "@/components/ui";
import { cn } from "@/lib/utils";

const tones = ["bg-primary-soft text-primary", "bg-gold-soft text-[#8A6A00]", "bg-success-soft text-success", "bg-[#E6EEF8] text-[#1D4E89]", "bg-warning-soft text-[#B5700D]", "bg-[#EFE6F6] text-[#5B3A86]", "bg-[#E4F1F1] text-[#1F6F6F]"];

function Dir() {
  const { tx, t, s, set } = useApp();
  const [q, setQ] = useState(useSearchParams().get("q") ?? "");
  const groups = Array.from(new Set(SERVICES.map((x) => x.group)));
  const [g, setG] = useState("All");
  const list = SERVICES.filter((x) => (g === "All" || x.group === g) && (!q || (x.name.en + x.name.ta + x.desc.en + x.group).toLowerCase().includes(q.toLowerCase())));
  const fav = (id: string) => set((p) => ({ ...p, favourites: p.favourites.includes(id) ? p.favourites.filter((f) => f !== id) : [...p.favourites, id] }));
  return (
    <div>
      <PageHeader title={t("allServices")} sub={`${SERVICES.length} services across ONETN`} back={false} />
      <div className="relative mb-3">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
        <input autoFocus={!!q} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("searchPlaceholder")} className="h-12 w-full rounded-2xl border border-line bg-white pl-11 pr-4 outline-none focus:border-primary" />
      </div>
      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto">{["All", ...groups].map((x) => <Chip key={x} active={g === x} onClick={() => setG(x)}>{x}</Chip>)}</div>
      {list.length === 0 ? <Empty title="No services match" body="Try another word, e.g. 'ration', 'bus' or 'certificate'." /> : (
        (g === "All" && !q ? groups : [g === "All" ? "Results" : g]).map((grp) => {
          const items = grp === "Results" ? list : list.filter((x) => x.group === grp);
          if (!items.length) return null;
          return (
            <section key={grp} className="mb-6">
              <h2 className="mb-3 text-[15px] font-bold text-muted">{grp}</h2>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
                {items.map((x) => (
                  <div key={x.id} className="card relative flex flex-col items-center gap-2 px-2 py-4 text-center">
                    <button onClick={() => fav(x.id)} aria-label="Favourite" className="absolute right-2 top-2"><Heart size={15} className={s.favourites.includes(x.id) ? "fill-primary text-primary" : "text-line"} /></button>
                    <Link href={x.href} className="flex flex-col items-center gap-2">
                      <span className={cn("grid h-13 w-13 place-items-center rounded-[18px] p-3", tones[(x.tone ?? 0) % 7])}><x.icon size={26} /></span>
                      <span className="text-[12.5px] font-semibold leading-tight">{tx(x.name)}</span>
                      <span className="hidden text-[11px] text-muted sm:block">{tx(x.desc)}</span>
                    </Link>
                  </div>
                ))}
              </div>
            </section>
          );
        })
      )}
    </div>
  );
}
export default function Page() { return <Suspense><Dir /></Suspense>; }
