"use client";
import Link from "next/link";
import { useState } from "react";
import { Search, Landmark, FileText, Bell, Sparkles, ChevronRight, ShieldCheck } from "lucide-react";
import { useApp } from "@/lib/store";
import { DEPARTMENTS, GOV_SERVICES, type Level } from "@/data/services";
import { Badge, Card, Chip, Empty, Notice, PageHeader, SectionHeader, Toggle } from "@/components/ui";
import { BookingRow } from "@/components/flows/BookingList";

const levelTone = (l: Level) => (l === "Fully integrated" ? "success" : l === "Connected" ? "info" : "neutral") as "success" | "info" | "neutral";

export default function Gov() {
  const { s, set } = useApp();
  const [q, setQ] = useState("");
  const [area, setArea] = useState("All");
  const [dept, setDept] = useState("All");
  const areas = Array.from(new Set(GOV_SERVICES.map((g) => g.area)));
  const list = GOV_SERVICES.filter((g) => (area === "All" || g.area === area) && (dept === "All" || g.dept === dept) && (!q || (g.name + g.ta + g.area + g.dept).toLowerCase().includes(q.toLowerCase())));
  const apps = s.bookings.filter((b) => b.module === "government");
  const suggest = s.consents.schemeSuggestions;
  return (
    <div className="space-y-6">
      <PageHeader title="Government Services" sub="Find, apply and track – no platform fee, ever" />
      <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder='Search by need, e.g. "change caste certificate"' className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <div className="grid gap-2 sm:grid-cols-3">
        {([["Guided access", "We explain the service, list documents and open the official portal."], ["Connected", "Sign in once; details pre-filled with consent; status shown here."], ["Fully integrated", "Apply, upload, pay any department fee and receive the result in-app."]] as [Level, string][]).map(([l, d]) => (
          <Card key={l} className="p-3"><Badge tone={levelTone(l)}>{l}</Badge><p className="mt-1 text-xs text-muted">{d}</p></Card>
        ))}
      </div>
      {apps.length > 0 && <section><SectionHeader title="My applications" href="/bookings" /><div className="grid gap-2 lg:grid-cols-2">{apps.slice(0, 4).map((b) => <BookingRow key={b.id} b={b} />)}</div></section>}
      <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", ...areas].map((a) => <Chip key={a} active={area === a} onClick={() => setArea(a)}>{a}</Chip>)}</div>
      <div className="no-scrollbar -mt-3 flex gap-2 overflow-x-auto">{["All", ...DEPARTMENTS].map((d) => <Chip key={d} className="h-8 text-xs" active={dept === d} onClick={() => setDept(d)}>{d === "All" ? "All departments" : d}</Chip>)}</div>
      {list.length === 0 ? <Empty title="No matching service" body="Try another search or department." /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((g) => (
            <Link key={g.id} href={`/services/government/service?id=${g.id}`} className="card flex items-start gap-3 p-4 hover:shadow-[var(--shadow-lift)]">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#E6EEF8] text-[#1D4E89]"><FileText /></span>
              <span className="min-w-0 flex-1"><span className="block font-semibold">{s.lang === "ta" ? g.ta : g.name}</span><span className="block text-xs text-muted">{g.dept}</span>
                <span className="mt-2 flex flex-wrap gap-1.5"><Badge tone={levelTone(g.level)}>{g.level}</Badge><Badge>{g.area}</Badge><Badge tone="success">No platform fee</Badge></span></span>
              <ChevronRight size={18} className="text-muted" />
            </Link>
          ))}
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <div className="flex items-center justify-between"><p className="flex items-center gap-2 font-bold"><Sparkles size={18} className="text-gold" />Schemes you may be eligible for</p><Toggle checked={suggest} onChange={(v) => set((p) => ({ ...p, consents: { ...p.consents, schemeSuggestions: v } }))} label="Allow suggestions" /></div>
          {suggest ? (
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link className="font-semibold text-primary" href="/services/government/service?id=oap">Old-Age Pension</Link> – for your mother Lakshmi (68), based on family details you shared</li>
              <li><Link className="font-semibold text-primary" href="/services/government/service?id=scholarship-pm">Post-Matric Scholarship</Link> – for Kavya (17) when she starts college</li>
              <li><Link className="font-semibold text-primary" href="/services/government/service?id=first-grad">First Graduate Certificate</Link> – if no graduate in the family</li>
            </ul>
          ) : <p className="mt-2 text-sm text-muted">Suggestions are off. Turn on to let ONETN match schemes using details you consent to share.</p>}
          <p className="mt-3 flex items-center gap-1 text-xs text-muted"><ShieldCheck size={13} />Uses only data you consent to · DPDP Act, 2023</p>
        </Card>
        <Card>
          <p className="flex items-center gap-2 font-bold"><Bell size={18} className="text-primary" />Renewals & deadlines</p>
          <ul className="mt-3 divide-y divide-line text-sm">
            <li className="flex justify-between py-2"><span>Annual pension life certificate (Lakshmi)</span><Badge tone="warning">Due 30 Nov</Badge></li>
            <li className="flex justify-between py-2"><span>Scholarship renewal window</span><Badge tone="info">Opens Jan</Badge></li>
          </ul>
          <p className="mt-3 font-bold">Benefits your family receives</p>
          <ul className="mt-2 text-sm text-muted"><li>• PDS ration entitlement (PHH card)</li><li>• Scholarship credit – {"₹1,500"} (demo, Oct)</li></ul>
        </Card>
      </div>
      <Notice tone="gold"><Landmark size={14} className="mr-1 inline" />ONETN is a doorway – each department&apos;s own portal remains the system of record. Integrations shown are proposals until departments approve them. Property registration and RTO services are outside the app.</Notice>
    </div>
  );
}
