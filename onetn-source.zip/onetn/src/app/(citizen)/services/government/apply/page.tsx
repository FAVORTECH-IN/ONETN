"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { FileUp, FolderLock, CheckCircle2, Trash2, UserPlus } from "lucide-react";
import { GOV_SERVICES } from "@/data/services";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Empty, Field, Input, KV, Notice, PageHeader, Select, Stepper } from "@/components/ui";
import { DISTRICTS } from "@/data/catalog";

function Inner() {
  const g = GOV_SERVICES.find((x) => x.id === useSearchParams().get("id"));
  const { s, addBooking, notify, toast } = useApp();
  const r = useRouter();
  const [step, setStep] = useState(0);
  const [app, setApp] = useState({ name: s.user?.name ?? "", dob: s.user?.dob ?? "", mobile: s.user?.mobile ?? "", address: s.user?.address ?? "", district: s.user?.district ?? "" });
  const [fam, setFam] = useState(s.family.map((f) => ({ name: f.name, relation: f.relation, age: f.age ?? "" })));
  const [vals, setVals] = useState<Record<string, string>>({});
  const [docs, setDocs] = useState<Record<string, string>>({});
  const [consent, setConsent] = useState(false);
  const [err, setErr] = useState("");
  if (!g) return <Empty title="Service not found" />;
  const steps = ["Applicant", ...(g.family ? ["Family"] : []), "Details", "Documents", "Consent", "Review"];
  const cur = steps[step];
  const validate = () => {
    if (cur === "Applicant" && (!app.name || !app.dob || !app.district)) return "Fill name, date of birth and district";
    if (cur === "Details") { const miss = g.fields.find((f) => !vals[f.k]); if (miss) return `Fill “${miss.label}”`; }
    if (cur === "Documents") { const miss = g.docs.find((d) => !docs[d]); if (miss) return `Attach “${miss}”`; }
    if (cur === "Consent" && !consent) return "Consent is required to share details with the department";
    return "";
  };
  const next = () => { const e = validate(); setErr(e); if (!e) setStep(step + 1); };
  const submit = () => {
    const b = addBooking({
      module: "government", kind: "application", title: g.name, subtitle: g.dept, status: "active", stageIdx: 0, amount: 0, payment: "No fee",
      stages: ["Application submitted", "Under scrutiny", "Additional documents requested", "Field verification", "Approved & issued"],
      fees: [{ label: "Platform fee", amount: 0, note: "Government services are free on ONETN" }, { label: "Department fee", amount: 0, note: g.fee }],
      details: { Department: g.dept, Level: g.level, Applicant: app.name, District: app.district, ...Object.fromEntries(g.fields.map((f) => [f.label, vals[f.k]])), Documents: `${Object.keys(docs).length} attached`, "Action needed": "No" },
    });
    notify("Application submitted", `${g.name} · Application no. ${b.id}`, `/bookings/detail?id=${b.id}`);
    toast(`Submitted · Application no. ${b.id}`);
    r.push(`/bookings/detail?id=${b.id}`);
  };
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={`Apply: ${g.name}`} sub={`${g.dept} · ${g.level}`} />
      <Stepper steps={steps} current={step} />
      <div className="mt-5 space-y-4">
        {cur === "Applicant" && (
          <Card className="grid gap-3 sm:grid-cols-2">
            <Notice tone="info" className="sm:col-span-2">Pre-filled from your ONETN profile. Edit if needed.</Notice>
            <Field label="Full name" required><Input value={app.name} onChange={(e) => setApp({ ...app, name: e.target.value })} /></Field>
            <Field label="Date of birth" required><Input type="date" value={app.dob} onChange={(e) => setApp({ ...app, dob: e.target.value })} /></Field>
            <Field label="Mobile"><Input value={app.mobile} disabled /></Field>
            <Field label="District" required><Select value={app.district} onChange={(e) => setApp({ ...app, district: e.target.value })} options={DISTRICTS} placeholder="Select" /></Field>
            <div className="sm:col-span-2"><Field label="Address"><Input value={app.address} onChange={(e) => setApp({ ...app, address: e.target.value })} /></Field></div>
          </Card>
        )}
        {cur === "Family" && (
          <Card className="space-y-3">
            <p className="font-bold">Family members</p>
            {fam.map((f, i) => (
              <div key={i} className="grid grid-cols-[1fr_1fr_80px_auto] gap-2">
                <Input aria-label="Name" value={f.name} onChange={(e) => setFam(fam.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} placeholder="Name" />
                <Input aria-label="Relation" value={f.relation} onChange={(e) => setFam(fam.map((x, k) => (k === i ? { ...x, relation: e.target.value } : x)))} placeholder="Relation" />
                <Input aria-label="Age" value={f.age} onChange={(e) => setFam(fam.map((x, k) => (k === i ? { ...x, age: e.target.value } : x)))} placeholder="Age" />
                <button aria-label="Remove" onClick={() => setFam(fam.filter((_, k) => k !== i))} className="grid w-10 place-items-center text-muted"><Trash2 size={17} /></button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={() => setFam([...fam, { name: "", relation: "", age: "" }])}><UserPlus size={15} />Add member</Button>
          </Card>
        )}
        {cur === "Details" && (
          <Card className="grid gap-3 sm:grid-cols-2">
            {g.fields.map((f) => (
              <Field key={f.k} label={f.label} required>
                {f.type === "select" ? <Select placeholder="Select" value={vals[f.k] ?? ""} options={f.options ?? []} onChange={(e) => setVals({ ...vals, [f.k]: e.target.value })} />
                  : <Input type={f.type ?? "text"} value={vals[f.k] ?? ""} onChange={(e) => setVals({ ...vals, [f.k]: e.target.value })} />}
              </Field>
            ))}
          </Card>
        )}
        {cur === "Documents" && (
          <Card className="space-y-3">
            <div className="flex items-center justify-between gap-3 rounded-2xl bg-[#E6EEF8] p-3 text-[#1D4E89]">
              <span className="flex items-center gap-2 text-sm font-semibold"><FolderLock size={18} />DigiLocker</span>
              <Button size="sm" variant="outline" onClick={() => { setDocs(Object.fromEntries(g.docs.map((d) => [d, `DigiLocker: ${d}`]))); toast("Fetched from DigiLocker (simulated)"); }}>Fetch documents</Button>
            </div>
            <p className="text-xs text-muted">DigiLocker integration entry point – simulated until the integration is approved.</p>
            {g.docs.map((d) => (
              <div key={d} className="flex items-center gap-3 rounded-2xl border border-line bg-white p-3">
                {docs[d] ? <CheckCircle2 className="text-success" size={20} /> : <FileUp className="text-muted" size={20} />}
                <span className="flex-1 text-sm"><span className="font-semibold">{d}</span>{docs[d] && <span className="block text-xs text-muted">{docs[d]}</span>}</span>
                <label className="cursor-pointer text-sm font-semibold text-primary">{docs[d] ? "Replace" : "Upload"}<input type="file" accept="image/*,application/pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setDocs({ ...docs, [d]: f.name }); }} /></label>
              </div>
            ))}
          </Card>
        )}
        {cur === "Consent" && (
          <Card className="space-y-3">
            <p className="font-bold">Consent to share</p>
            <p className="text-sm text-muted">The following will be shared with <b>{g.dept}</b> only for processing this application: applicant details{g.family ? ", family details" : ""}, application details and attached documents. You can view and withdraw consent in Profile → Data consent.</p>
            <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1 accent-[#8B0000]" />I consent to share these details with the department and declare the information is true.</label>
          </Card>
        )}
        {cur === "Review" && (
          <Card className="space-y-3">
            <p className="font-bold">Review your application</p>
            <KV rows={[["Service", g.name], ["Applicant", app.name], ["District", app.district], ...g.fields.map((f) => [f.label, vals[f.k]] as [string, string]), ["Documents", `${Object.keys(docs).length} of ${g.docs.length}`], ["Platform fee", <Badge key="f" tone="success">Free</Badge>], ["Department fee", g.fee]]} />
          </Card>
        )}
        {err && <Notice tone="error">{err}</Notice>}
        <div className="flex gap-2">
          {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>Back</Button>}
          {cur === "Review" ? <Button full size="lg" onClick={submit}>Submit application</Button> : <Button full onClick={next}>Continue</Button>}
        </div>
      </div>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
