"use client";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { CheckCircle2, FileText, Clock, IndianRupee, Building2, ExternalLink, ListChecks } from "lucide-react";
import { GOV_SERVICES } from "@/data/services";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Empty, KV, Notice, PageHeader } from "@/components/ui";

function Inner() {
  const g = GOV_SERVICES.find((x) => x.id === useSearchParams().get("id"));
  const { s, toast } = useApp();
  if (!g) return <Empty title="Service not found" action={<Button href="/services/government">All services</Button>} />;
  const tone = g.level === "Fully integrated" ? "success" : g.level === "Connected" ? "info" : "neutral";
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={s.lang === "ta" ? g.ta : g.name} sub={g.dept} />
      <div className="flex flex-wrap gap-2"><Badge tone={tone}>{g.level}</Badge><Badge>{g.area}</Badge><Badge tone="success">No platform fee</Badge></div>
      <Card><KV rows={[[<span key="a" className="flex items-center gap-2"><Building2 size={15} />Department</span>, g.dept], [<span key="b" className="flex items-center gap-2"><Clock size={15} />Normal processing time</span>, g.time], [<span key="c" className="flex items-center gap-2"><IndianRupee size={15} />Department fee</span>, g.fee]]} /></Card>
      <Card><p className="mb-2 flex items-center gap-2 font-bold"><ListChecks size={18} />Who is eligible</p><ul className="space-y-1.5 text-sm">{g.eligibility.map((e) => <li key={e} className="flex gap-2"><CheckCircle2 size={16} className="mt-0.5 shrink-0 text-success" />{e}</li>)}</ul></Card>
      <Card><p className="mb-2 flex items-center gap-2 font-bold"><FileText size={18} />Documents required</p><ul className="space-y-1.5 text-sm">{g.docs.map((e) => <li key={e} className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />{e}</li>)}</ul><p className="mt-2 text-xs text-muted">You can pick documents from DigiLocker (once connected) or upload them.</p></Card>
      <Card><p className="mb-2 font-bold">How it works</p><ol className="list-decimal space-y-1 pl-5 text-sm text-muted"><li>Prepare documents</li><li>Apply {g.level === "Guided access" ? "on the official portal" : "here in ONETN"}</li><li>Track status with updates in Tamil</li><li>Respond if the department needs more information</li><li>Receive the result {g.level === "Fully integrated" ? "in the app and in your document locker" : "as per the department"}</li></ol></Card>
      {g.level === "Guided access" ? (
        <>
          <Notice tone="info">This service is at Guided access level: ONETN explains the steps and opens the department&apos;s official portal. Status tracking will be added when the department connects.</Notice>
          <Button full size="lg" onClick={() => toast("Would open the department's official portal (not linked in demo)", "info")}><ExternalLink size={18} />Open official portal</Button>
        </>
      ) : <Button full size="lg" href={`/services/government/apply?id=${g.id}`}>Apply in ONETN</Button>}
      <p className="text-center text-xs text-muted">Do not invent or pay unofficial fees. Government applications never carry a platform convenience fee.</p>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
