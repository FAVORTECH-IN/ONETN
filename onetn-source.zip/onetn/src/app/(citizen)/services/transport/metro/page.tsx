"use client";
import { useState } from "react";
import { TrainFront } from "lucide-react";
import { METRO_LINES, metroFare } from "@/data/transport";
import { Card, Chip, Field, Notice, PageHeader, Select, Qty, SimTag } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { inr } from "@/lib/utils";

export default function Metro() {
  const [line, setLine] = useState(METRO_LINES[0]);
  const [from, setFrom] = useState(line.stations[3]);
  const [to, setTo] = useState(line.stations[12]);
  const [n, setN] = useState(1);
  const [type, setType] = useState("Single journey");
  const hops = Math.abs(line.stations.indexOf(from) - line.stations.indexOf(to));
  const fare = metroFare(hops) * (type === "Return journey" ? 2 : 1);
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <PageHeader title="Metro tickets" sub="Chennai Metro · QR tickets" right={<SimTag />} />
      <div className="flex gap-2">{METRO_LINES.map((l) => <Chip key={l.id} active={line.id === l.id} onClick={() => { setLine(l); setFrom(l.stations[0]); setTo(l.stations[5]); }}><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full" style={{ background: l.color }} />{l.name}</Chip>)}</div>
      <Card className="space-y-3">
        <Field label="From station"><Select value={from} onChange={(e) => setFrom(e.target.value)} options={line.stations} /></Field>
        <Field label="To station"><Select value={to} onChange={(e) => setTo(e.target.value)} options={line.stations.filter((x) => x !== from)} /></Field>
        <div className="flex flex-wrap gap-2">{["Single journey", "Return journey"].map((x) => <Chip key={x} active={type === x} onClick={() => setType(x)}>{x}</Chip>)}</div>
        <div className="flex items-center justify-between"><span className="font-semibold">Passengers</span><Qty value={n} min={1} max={6} onChange={setN} /></div>
        <div className="flex items-center justify-between rounded-2xl bg-cream p-3"><span className="flex items-center gap-2 text-sm"><TrainFront size={16} />{hops} stations</span><span className="text-xl font-bold">{inr(fare * n)}</span></div>
      </Card>
      <Notice tone="info">Metro fares are set by the operator. Demo fare slabs shown until the operator integration is approved.</Notice>
      <CheckoutButton label={`Buy ticket · ${inr(fare * n)}`} category="Rides" validate={() => (from === to ? "Choose different stations" : null)}
        build={() => ({ module: "metro", kind: "booking", title: "Metro QR ticket", subtitle: `${from} → ${to}`, status: "active", stageIdx: 0, stages: ["Ticket issued", "Entry validated", "Journey completed"],
          fees: [{ label: `${type} × ${n}`, amount: fare * n, payee: "Metro operator" }], details: { Line: line.name, From: from, To: to, Passengers: String(n), Type: type, Validity: "Today, 1 entry" } })} />
    </div>
  );
}
