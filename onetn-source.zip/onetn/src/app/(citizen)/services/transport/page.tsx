"use client";
import Link from "next/link";
import { Car, Bike, Bus, TrainFront, Package, Route, BadgePercent, ExternalLink, Ticket } from "lucide-react";
import { Card, Notice, PageHeader, SectionHeader, Badge } from "@/components/ui";
import { CONCESSIONS } from "@/data/transport";

const items = [
  { i: Car, t: "Auto", d: "Standard approved fare", h: "/services/auto-booking" },
  { i: Car, t: "Cab", d: "Mini, Sedan, SUV, EV", h: "/services/cab-booking" },
  { i: Bike, t: "Bike Taxi", d: "Quick solo rides", h: "/services/cab-booking?type=bike" },
  { i: Bus, t: "Bus (SETC / TNSTC)", d: "Long-distance & government buses", h: "/services/bus-booking" },
  { i: TrainFront, t: "Metro tickets", d: "Chennai Metro QR tickets", h: "/services/transport/metro" },
  { i: Package, t: "Parcels", d: "Small to large, tracked", h: "/services/parcels" },
  { i: Route, t: "Journey planner", d: "Combine bus/Metro with auto", h: "/services/transport/journey" },
];
export default function Transport() {
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <PageHeader title="Mobility & Transport" sub="One place to move around Tamil Nadu" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {items.map((x) => (
          <Link key={x.t} href={x.h} className="card p-4 hover:shadow-[var(--shadow-lift)]"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary-soft text-primary"><x.i /></span><p className="mt-3 font-semibold">{x.t}</p><p className="text-xs text-muted">{x.d}</p></Link>
        ))}
      </div>
      <section>
        <SectionHeader title="Chennai One & public transport" />
        <Card className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[#E6EEF8] text-[#1D4E89]"><Ticket /></span>
          <div className="flex-1"><p className="font-bold">Chennai One <Badge tone="warning">Integration pending</Badge></p><p className="text-sm text-muted">MTC bus, Metro and suburban rail tickets from the existing Chennai One platform will open inside ONETN once CUMTA approves integration. Until then this is an entry point only.</p></div>
          <a className="flex items-center gap-1 text-sm font-semibold text-primary" href="https://www.google.com/search?q=Chennai+One+app" target="_blank" rel="noreferrer">Learn more <ExternalLink size={14} /></a>
        </Card>
      </section>
      <section>
        <SectionHeader title="Concessions & free-travel schemes" />
        <Card className="divide-y divide-line p-0">
          {CONCESSIONS.filter((c) => c.id !== "none").map((c) => (
            <div key={c.id} className="flex items-center gap-3 px-4 py-3"><BadgePercent size={18} className="text-success" /><span className="flex-1 text-sm">{c.label}</span><Badge tone="success">{c.pct === 100 ? "Free" : `${c.pct}% off`}</Badge></div>
          ))}
        </Card>
        <Notice tone="gold" className="mt-3">Concessions are shown and applied in line with Transport Department rules. Figures here are demo placeholders.</Notice>
      </section>
    </div>
  );
}
