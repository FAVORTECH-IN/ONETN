"use client";
import { useState } from "react";
import Link from "next/link";
import { Footprints, TrainFront, Car, Bus, ArrowRight } from "lucide-react";
import { PLACES, distanceKm, fareFor, VEHICLES, metroFare } from "@/data/transport";
import { Badge, Button, Card, Field, PageHeader, Select, SimTag } from "@/components/ui";
import { inr } from "@/lib/utils";

export default function Journey() {
  const [a, setA] = useState("Porur");
  const [b, setB] = useState("Chennai Airport");
  const [show, setShow] = useState(false);
  const km = distanceKm(a, b);
  const auto = fareFor(VEHICLES[1], km).total;
  const opts = [
    { t: "Fastest", legs: [{ i: Car, l: `Cab Mini · ${km} km` }], mins: Math.round(km * 3.2 + 6), cost: fareFor(VEHICLES[2], km).total, cta: "/services/cab-booking" },
    { t: "Cheapest", legs: [{ i: Footprints, l: "Walk 6 min" }, { i: Bus, l: "MTC bus" }, { i: TrainFront, l: "Metro 7 stops" }], mins: Math.round(km * 5 + 15), cost: 15 + metroFare(7), cta: "/services/transport/metro" },
    { t: "Balanced", legs: [{ i: Car, l: "Auto 2.1 km" }, { i: TrainFront, l: "Metro 9 stops" }], mins: Math.round(km * 4 + 10), cost: fareFor(VEHICLES[1], 2.1).total + metroFare(9), cta: "/services/auto-booking" },
    { t: "Auto only", legs: [{ i: Car, l: `Auto · ${km} km` }], mins: Math.round(km * 3.5 + 6), cost: auto, cta: "/services/auto-booking" },
  ];
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <PageHeader title="Journey planner" sub="Combine public transport with an auto or cab" right={<SimTag />} />
      <Card className="space-y-3">
        <Field label="From"><Select value={a} onChange={(e) => { setA(e.target.value); setShow(false); }} options={PLACES.map((p) => p.name)} /></Field>
        <Field label="To"><Select value={b} onChange={(e) => { setB(e.target.value); setShow(false); }} options={PLACES.filter((p) => p.name !== a).map((p) => p.name)} /></Field>
        <Button full onClick={() => setShow(true)}>Plan journey</Button>
      </Card>
      {show && opts.map((o) => (
        <Card key={o.t}>
          <div className="flex items-center justify-between"><Badge tone="primary">{o.t}</Badge><span className="text-sm text-muted">~{o.mins} min · <b className="text-ink">{inr(o.cost)}</b></span></div>
          <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">{o.legs.map((l, i) => <span key={i} className="flex items-center gap-1">{i > 0 && <ArrowRight size={14} className="text-muted" />}<l.i size={16} className="text-primary" />{l.l}</span>)}</div>
          <Link href={o.cta} className="mt-3 inline-block text-sm font-semibold text-primary">Book first leg →</Link>
        </Card>
      ))}
    </div>
  );
}
