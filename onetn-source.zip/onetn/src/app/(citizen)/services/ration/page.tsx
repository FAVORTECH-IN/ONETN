"use client";
import { useState } from "react";
import { Wheat, Store, CreditCard, UserCheck, Link2, Accessibility } from "lucide-react";
import { useApp } from "@/lib/store";
import { RATION_CARD, RATION_ITEMS, SLOTS } from "@/data/delivery";
import { Badge, Button, Card, Chip, Field, Input, KV, Notice, PageHeader, Select, SimTag, Toggle } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { dayLabel, inr, nextDays } from "@/lib/utils";

export default function Ration() {
  const { s, set, toast } = useApp();
  const [card, setCard] = useState("");
  const [qty, setQty] = useState<Record<string, number>>(Object.fromEntries(RATION_ITEMS.map((i) => [i.id, i.ent])));
  const [mode, setMode] = useState<"Doorstep delivery" | "Collect at shop">("Doorstep delivery");
  const [day, setDay] = useState(1);
  const [slot, setSlot] = useState("");
  const [who, setWho] = useState(s.user?.name ?? "");
  const [priority, setPriority] = useState(false);
  if (!s.rationLinked)
    return (
      <div className="mx-auto max-w-lg">
        <PageHeader title="Ration Delivery" sub="Civil Supplies Department · Public Distribution System" />
        <Card className="space-y-4">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00]"><Link2 /></span>
          <p className="text-lg font-bold">Link your ration card</p>
          <p className="text-sm text-muted">We fetch your monthly entitlement from the Civil Supplies system with your consent. The department stays in charge of entitlements and stock.</p>
          <Field label="Smart ration card number" hint="Demo: enter any 12 digits"><Input inputMode="numeric" maxLength={12} value={card} onChange={(e) => setCard(e.target.value.replace(/\D/g, ""))} /></Field>
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" id="c" className="mt-1 accent-[#8B0000]" />I consent to sharing my ration card details with the Civil Supplies Department for this service.</label>
          <Button full onClick={() => { if (card.length !== 12) return toast("Enter a 12-digit card number", "error"); if (!(document.getElementById("c") as HTMLInputElement).checked) return toast("Please give consent to continue", "error"); set((p) => ({ ...p, rationLinked: true })); toast("Ration card linked (simulated)"); }}>Verify & link (OTP to card mobile)</Button>
          <Notice tone="gold">Simulated: real linking needs Civil Supplies integration approval.</Notice>
        </Card>
      </div>
    );
  const items = RATION_ITEMS.filter((i) => qty[i.id] > 0);
  const fees = [...items.map((i) => ({ label: `${i.name} ${qty[i.id]} ${i.unit}`, amount: i.price * qty[i.id], note: i.note })), { label: "Doorstep delivery", amount: mode === "Collect at shop" || priority ? 0 : 15, note: priority ? "Free for priority groups" : "Demo fee – as decided by department" }];
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Ration Delivery" sub="November entitlement" right={<SimTag label="Demo data" />} />
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          <Card>
            <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00]"><CreditCard /></span><div className="flex-1"><p className="font-bold">{RATION_CARD.number}</p><p className="text-sm text-muted">{RATION_CARD.type} · {RATION_CARD.members} members</p></div><Badge tone="success">Linked</Badge></div>
            <div className="mt-3"><KV rows={[["Card holder", RATION_CARD.head], ["Fair price shop", RATION_CARD.shop]]} /></div>
          </Card>
          <Card>
            <p className="mb-3 font-bold">Monthly entitlement</p>
            <div className="divide-y divide-line">
              {RATION_ITEMS.map((i) => (
                <div key={i.id} className="flex items-center gap-3 py-3">
                  <Wheat size={18} className="text-[#8A6A00]" />
                  <div className="flex-1"><p className="font-semibold">{i.name} <span className="text-sm font-normal text-muted">{i.ta}</span></p><p className="text-xs text-muted">Entitled {i.ent} {i.unit} · {i.price ? `${inr(i.price)}/${i.unit}` : "Free"} ({i.note})</p></div>
                  <Select aria-label={`${i.name} quantity`} className="h-10 w-24" value={String(qty[i.id])} onChange={(e) => setQty({ ...qty, [i.id]: Number(e.target.value) })} options={Array.from({ length: i.ent + 1 }, (_, k) => String(i.ent - k))} />
                </div>
              ))}
            </div>
          </Card>
          <Card className="space-y-3">
            <div className="flex flex-wrap gap-2">{(["Doorstep delivery", "Collect at shop"] as const).map((m) => <Chip key={m} active={mode === m} onClick={() => setMode(m)}>{m === "Collect at shop" ? <><Store size={14} className="mr-1 inline" />{m}</> : m}</Chip>)}</div>
            <p className="text-sm font-semibold">{mode === "Collect at shop" ? "Collection slot (skip the queue)" : "Delivery slot"}</p>
            <div className="no-scrollbar flex gap-2 overflow-x-auto">{nextDays(5).slice(1).map((d, i) => <Chip key={i} active={day === i + 1} onClick={() => setDay(i + 1)}>{dayLabel(d)}</Chip>)}</div>
            <div className="flex flex-wrap gap-2">{SLOTS.map((x) => <Chip key={x} active={slot === x} onClick={() => setSlot(x)}>{x}</Chip>)}</div>
            <Field label="Authorised family member to receive"><Select value={who} onChange={(e) => setWho(e.target.value)} options={[s.user?.name ?? "", ...s.family.map((f) => `${f.name} (${f.relation})`)]} /></Field>
            <div className="flex items-center gap-3 rounded-2xl bg-cream p-3"><Accessibility className="text-primary" /><span className="flex-1 text-sm"><b>Priority slot</b> – senior citizen, person with disability or patient in household</span><Toggle checked={priority} onChange={setPriority} label="Priority" /></div>
          </Card>
        </div>
        <div className="space-y-4">
          <Card><p className="mb-2 font-bold">Summary</p>{fees.map((f) => <div key={f.label} className="flex justify-between py-1 text-sm"><span className="text-muted">{f.label}</span><span>{f.amount ? inr(f.amount) : "Free"}</span></div>)}</Card>
          <Notice tone="info"><UserCheck size={14} className="mr-1 inline" />The right person is confirmed at the door with a one-time code. Undelivered items return to the shop and are recorded.</Notice>
          <CheckoutButton label={mode === "Collect at shop" ? "Book collection slot" : "Book delivery"} category="Essentials"
            validate={() => (!items.length ? "Select at least one item" : !slot ? "Choose a slot" : null)}
            build={() => ({ module: "ration", kind: "order", title: mode === "Collect at shop" ? "Ration – shop collection" : "Ration delivery", subtitle: `${RATION_CARD.shop} · ${dayLabel(nextDays(5)[day])}`, status: "active", stageIdx: 0,
              stages: mode === "Collect at shop" ? ["Slot booked", "Packed at shop", "Ready for collection", "Collected"] : ["Booked", "Shop packing (stock record)", "Rider assigned", "Out for delivery", "Delivered & OTP confirmed"],
              fees, items: items.map((i) => ({ name: `${i.name} (${i.unit})`, qty: qty[i.id], price: i.price })),
              details: { "Ration card": RATION_CARD.number, Shop: RATION_CARD.shop, Slot: `${dayLabel(nextDays(5)[day])}, ${slot}`, Receiver: who, Priority: priority ? "Yes" : "No", Mode: mode },
              provider: mode === "Doorstep delivery" ? { name: "Rider: Sakthi SHG – Kavitha", rating: 4.9, vehicle: "TN 09 EV 7780 · e-scooter" } : undefined })} />
        </div>
      </div>
    </div>
  );
}
