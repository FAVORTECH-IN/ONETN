"use client";
import { useState } from "react";
import { ShoppingCart, BadgePercent } from "lucide-react";
import { COOP_PRODUCTS, COOP_STORES } from "@/data/delivery";
import { Chip, Notice, PageHeader, Thumb, Card } from "@/components/ui";
import { ProductGrid } from "@/components/flows/ProductGrid";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { cn } from "@/lib/utils";

export default function Coop() {
  const [st, setSt] = useState(COOP_STORES[0]);
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState(false);
  const key = `coop-${st.id}`;
  return (
    <div>
      <PageHeader title="Government & Co-op Supermarkets" sub="Cooperative pricing and scheme discounts" />
      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        {COOP_STORES.map((c) => <button key={c.id} onClick={() => setSt(c)} className={cn("card flex items-center gap-3 p-3 text-left", st.id === c.id && "border-primary ring-4 ring-primary/10")}><Thumb hue={c.hue} icon={ShoppingCart} size={48} /><span><span className="block font-semibold">{c.name}</span><span className="text-xs text-muted">{c.area}</span></span></button>)}
      </div>
      <Card className="mb-4 flex items-center gap-3 bg-gold-soft"><BadgePercent className="text-[#8A6A00]" /><p className="text-sm"><b>Offers:</b> Cooperative brand staples up to 15% below MRP. Scheme subsidies credited to Wallet apply at checkout where permitted.</p></Card>
      <div className="no-scrollbar mb-4 flex gap-2">{["All", "Groceries", "Household", "Cleaning", "Stationery"].map((x) => <Chip key={x} active={cat === x} onClick={() => setCat(x)}>{x}</Chip>)}</div>
      <ProductGrid items={COOP_PRODUCTS.filter((p) => cat === "All" || p.cat === cat)} cartKey={key} store={st.name} icon={ShoppingCart} />
      <Notice tone="info" className="mt-4">Prices are the store&apos;s own (demo values).</Notice>
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={{ cartKey: key, module: "coop", title: "Co-op supermarket order", store: st.name, category: "Essentials", deliveryFee: 20, platformFee: 0, freeDeliveryAbove: 399, repeatHref: "/services/essentials/cooperative", substitution: true }} />
    </div>
  );
}
