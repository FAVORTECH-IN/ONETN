"use client";
import Link from "next/link";
import { Wheat, Milk, Pill, Sprout, ShoppingCart, HeartHandshake, PhoneCall } from "lucide-react";
import { Card, Notice, PageHeader } from "@/components/ui";

const mods = [
  { i: Wheat, t: "Ration Delivery", d: "Monthly PDS entitlement from your fair price shop", h: "/services/ration", c: "bg-gold-soft text-[#8A6A00]" },
  { i: Milk, t: "Milk Subscription", d: "Cooperative milk, daily or alternate days", h: "/services/milk", c: "bg-[#E6EEF8] text-[#1D4E89]" },
  { i: Pill, t: "Medicine Delivery", d: "Government medical shops & licensed pharmacies", h: "/services/medicines", c: "bg-primary-soft text-primary" },
  { i: Sprout, t: "Uzhavar Sandhai", d: "Farm-fresh produce at market prices", h: "/services/uzhavar-sandhai", c: "bg-success-soft text-success" },
  { i: ShoppingCart, t: "Government & Co-op Supermarkets", d: "Scheme prices and discounts", h: "/services/essentials/cooperative", c: "bg-[#EFE6F6] text-[#5B3A86]" },
];
export default function Essentials() {
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <PageHeader title="Door-to-Door Essentials" sub="The Government's own essential supplies, delivered home" />
      <div className="grid gap-3 sm:grid-cols-2">
        {mods.map((m) => (
          <Link key={m.t} href={m.h} className="card flex items-center gap-4 p-4 hover:shadow-[var(--shadow-lift)]"><span className={`grid h-14 w-14 shrink-0 place-items-center rounded-2xl ${m.c}`}><m.i size={26} /></span><span><span className="block font-bold">{m.t}</span><span className="text-sm text-muted">{m.d}</span></span></Link>
        ))}
      </div>
      <Card className="flex items-start gap-3"><HeartHandshake className="shrink-0 text-primary" /><div><p className="font-bold">Priority for the vulnerable</p><p className="text-sm text-muted">Priority slots for senior citizens, persons with disabilities and patients. An authorised family member can book on someone&apos;s behalf. Assistance at the door where needed.</p></div></Card>
      <Card className="flex items-start gap-3"><PhoneCall className="shrink-0 text-primary" /><div><p className="font-bold">No smartphone? Book by phone</p><p className="text-sm text-muted">Helpline booking in Tamil (number to be published at launch).</p></div></Card>
      <Notice tone="info">All payments are digital – no cash at the door. Subsidised prices are shown clearly, and every delivery is recorded for audit.</Notice>
    </div>
  );
}
