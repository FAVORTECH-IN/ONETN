"use client";
import Link from "next/link";
import { useState } from "react";
import { Search, Clock, Leaf, UtensilsCrossed, ShoppingBag, CalendarCheck } from "lucide-react";
import { useApp } from "@/lib/store";
import { CUISINES, RESTAURANTS } from "@/data/jobsfood";
import { Badge, Chip, Empty, Notice, PageHeader, Rating, Tabs, Thumb } from "@/components/ui";
import { inr } from "@/lib/utils";

export default function Food() {
  const { s } = useApp();
  const [q, setQ] = useState("");
  const [c, setC] = useState("All");
  const [veg, setVeg] = useState(false);
  const [mode, setMode] = useState<"delivery" | "takeaway" | "table">("delivery");
  const [sort, setSort] = useState("Nearest");
  let list = RESTAURANTS.filter((r) => (c === "All" || r.cuisine.includes(c)) && (!veg || r.veg) && (mode !== "takeaway" || r.takeaway) && (mode !== "table" || r.tables) &&
    (!q || (r.name + r.cuisine.join(" ") + r.menu.map((m) => m.name).join(" ")).toLowerCase().includes(q.toLowerCase())));
  list = [...list].sort((a, b) => (sort === "Rating" ? b.rating - a.rating : sort === "Cost" ? a.cost2 - b.cost2 : a.km - b.km));
  const recent = s.bookings.filter((b) => ["food", "takeaway", "table"].includes(b.module));
  return (
    <div className="space-y-4">
      <PageHeader title="Food & Restaurants" sub="Independent, verified restaurant partners" right={recent.length ? <Link href="/orders" className="text-sm font-semibold text-primary">My orders</Link> : undefined} />
      <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search dosa, biryani, restaurant…" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <Tabs value={mode} onChange={setMode} tabs={[{ value: "delivery", label: "Delivery" }, { value: "takeaway", label: "Takeaway" }, { value: "table", label: "Book a table" }]} />
      <div className="no-scrollbar flex gap-2 overflow-x-auto">
        <Chip active={veg} onClick={() => setVeg(!veg)}><Leaf size={14} className="mr-1 inline text-success" />Pure veg</Chip>
        {["Nearest", "Rating", "Cost"].map((x) => <Chip key={x} active={sort === x} onClick={() => setSort(x)}>{x}</Chip>)}
        {["All", ...CUISINES].map((x) => <Chip key={x} active={c === x} onClick={() => setC(x)}>{x}</Chip>)}
      </div>
      {list.length === 0 ? <Empty title="No restaurants match" /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((r) => (
            <Link key={r.id} href={`/services/food/restaurant?id=${r.id}${mode !== "delivery" ? `&mode=${mode}` : ""}`} className="card overflow-hidden p-0 hover:shadow-[var(--shadow-lift)]">
              <div className="relative"><Thumb hue={r.hue} icon={UtensilsCrossed} className="h-36 w-full rounded-none" size={140} />{r.offer && <span className="absolute bottom-2 left-2 rounded-lg bg-primary px-2 py-1 text-[11px] font-bold text-white">{r.offer}</span>}</div>
              <div className="p-3.5">
                <div className="flex items-center justify-between gap-2"><p className="truncate font-bold">{r.name}</p><Rating value={r.rating} /></div>
                <p className="truncate text-sm text-muted">{r.cuisine.join(" · ")}</p>
                <p className="mt-1 flex items-center gap-2 text-xs text-muted"><Clock size={12} />{r.eta} min · {r.km} km · {inr(r.cost2)} for two</p>
                <div className="mt-2 flex gap-1.5">{r.veg && <Badge tone="success">Veg</Badge>}{r.takeaway && <Badge><ShoppingBag size={11} />Takeaway</Badge>}{r.tables && <Badge><CalendarCheck size={11} />Tables</Badge>}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
      <Notice tone="gold">Restaurants are independent businesses that register voluntarily. The Government provides policy direction and oversight only – it does not own or operate restaurants. Proposed service for feasibility assessment.</Notice>
    </div>
  );
}
