"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Clock, MapPin, Leaf, Star, ShieldCheck, CalendarCheck, UtensilsCrossed, Info } from "lucide-react";
import { useApp } from "@/lib/store";
import { RESTAURANTS } from "@/data/jobsfood";
import { Badge, Button, Card, Chip, Empty, Field, Input, KV, Notice, PageHeader, Qty, Rating, Sheet, Thumb, Select } from "@/components/ui";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { CheckoutButton } from "@/components/flows/Payment";
import { cn, dayLabel, inr, nextDays } from "@/lib/utils";

const TIMES = ["12:30 PM", "1:00 PM", "1:30 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM"];
function Inner() {
  const sp = useSearchParams();
  const r = RESTAURANTS.find((x) => x.id === sp.get("id"));
  const { s, cart, setQty } = useApp();
  const [open, setOpen] = useState(false);
  const [tbl, setTbl] = useState(sp.get("mode") === "table");
  const [veg, setVeg] = useState(false);
  const [t, setT] = useState({ day: 0, time: "", guests: 2, name: s.user?.name ?? "", phone: s.user?.mobile ?? "", note: "" });
  if (!r) return <Empty title="Restaurant not found" />;
  const key = `food-${r.id}`;
  const c = cart(key);
  const cats = Array.from(new Set(r.menu.map((m) => m.cat)));
  const tables = (i: number) => Math.max(0, 6 - ((i * 2 + t.guests + t.day) % 7));
  return (
    <div>
      <PageHeader title={r.name} sub={r.cuisine.join(" · ")} />
      <div className="grid grid-cols-3 gap-2"><Thumb hue={r.hue} icon={UtensilsCrossed} className="col-span-2 h-44 w-full" size={160} /><div className="grid gap-2"><Thumb hue={r.hue + 1} icon={UtensilsCrossed} className="h-21 w-full" size={80} /><Thumb hue={r.hue + 2} icon={UtensilsCrossed} className="h-21 w-full" size={80} /></div></div>
      <Card className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
        <Rating value={r.rating} count={r.ratings} /><span className="flex items-center gap-1"><Clock size={14} />{r.hours}</span><span className="flex items-center gap-1"><MapPin size={14} />{r.area} · {r.km} km</span><span>{inr(r.cost2)} for two</span>
        <Badge tone="success"><ShieldCheck size={12} />FSSAI {r.fssai}</Badge>
      </Card>
      {r.offer && <Notice tone="success" className="mt-3">{r.offer}</Notice>}
      <div className="mt-3 flex flex-wrap gap-2">
        <Chip active={veg} onClick={() => setVeg(!veg)}><Leaf size={14} className="mr-1 inline text-success" />Veg only</Chip>
        {r.tables && <Button size="sm" variant="outline" onClick={() => setTbl(true)}><CalendarCheck size={15} />Book a table</Button>}
        {r.takeaway && <Badge tone="info">Takeaway available – choose in cart</Badge>}
      </div>
      <div className="mt-5 space-y-6">
        {cats.map((cat) => {
          const items = r.menu.filter((m) => m.cat === cat && (!veg || m.veg));
          if (!items.length) return null;
          return (
            <section key={cat}>
              <h2 className="mb-2 font-bold">{cat}</h2>
              <div className="card divide-y divide-line p-0">
                {items.map((m) => (
                  <div key={m.id} className="flex gap-3 p-4">
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-2 font-semibold"><span className={cn("grid h-4 w-4 place-items-center rounded-sm border-2", m.veg ? "border-success" : "border-error")}><span className={cn("h-1.5 w-1.5 rounded-full", m.veg ? "bg-success" : "bg-error")} /></span>{m.name}{m.best && <Badge tone="gold"><Star size={10} />Bestseller</Badge>}</p>
                      <p className="mt-0.5 font-bold">{inr(m.price)}</p>
                      <p className="mt-1 text-sm text-muted">{m.desc}</p>
                      {m.allergens && <p className="mt-1 flex items-center gap-1 text-xs text-warning"><Info size={12} />Contains: {m.allergens}</p>}
                    </div>
                    <div className="flex flex-col items-center gap-2"><Thumb hue={r.hue} icon={UtensilsCrossed} size={84} /><Qty value={c.find((x) => x.id === m.id)?.qty ?? 0} onChange={(v) => setQty(key, { id: m.id, name: m.name, price: m.price, unit: m.cat }, v)} /></div>
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>
      <p className="mt-4 text-xs text-muted">Menu, prices, taxes and food preparation are the restaurant&apos;s responsibility. Allergen information shown where provided.</p>
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={{ cartKey: key, module: "food", title: "Food order", store: r.name, category: "Restaurant orders", deliveryFee: 30, platformFee: 6, freeDeliveryAbove: r.offer?.includes("Free delivery") ? 199 : undefined,
        repeatHref: `/services/food/restaurant?id=${r.id}`, instructions: true, allowTakeaway: r.takeaway, coupons: false,
        stages: ["Order placed", "Restaurant accepted", "Preparing", "Ready for pickup", "Rider assigned", "Out for delivery", "Delivered"],
        extraFees: [{ label: "GST on food (5%, collected for restaurant)", amount: Math.round(c.reduce((a, b) => a + b.price * b.qty, 0) * 0.05) }] }} />
      <Sheet open={tbl} onClose={() => setTbl(false)} title={`Reserve at ${r.name}`}
        footer={<CheckoutButton label="Confirm reservation (₹0)" category="Restaurant orders" validate={() => (!t.time ? "Choose a time" : !t.name || !/^[6-9]\d{9}$/.test(t.phone) ? "Enter name and valid mobile" : null)}
          build={() => ({ module: "table", kind: "booking", title: `Table at ${r.name}`, subtitle: `${t.guests} guests · ${dayLabel(nextDays(7)[t.day])} ${t.time}`, status: "active", stageIdx: 0, stages: ["Reservation confirmed", "Seated", "Completed"],
            fees: [{ label: "Reservation", amount: 0, note: "No charge to reserve" }], details: { Restaurant: r.name, Date: dayLabel(nextDays(7)[t.day]), Time: t.time, Guests: String(t.guests), Name: t.name, Phone: t.phone, ...(t.note ? { Request: t.note } : {}) } })} />}>
        <div className="space-y-3">
          <div className="no-scrollbar flex gap-2 overflow-x-auto">{nextDays(7).map((d, i) => <Chip key={i} active={t.day === i} onClick={() => setT({ ...t, day: i, time: "" })}>{i === 0 ? "Today" : dayLabel(d)}</Chip>)}</div>
          <Field label="Guests"><Select value={String(t.guests)} onChange={(e) => setT({ ...t, guests: Number(e.target.value), time: "" })} options={["1", "2", "3", "4", "5", "6", "8", "10"]} /></Field>
          <p className="text-sm font-semibold">Available tables</p>
          <div className="flex flex-wrap gap-2">{TIMES.map((x, i) => <Chip key={x} active={t.time === x} onClick={() => tables(i) && setT({ ...t, time: x })} className={!tables(i) ? "pointer-events-none opacity-40 line-through" : ""}>{x} <span className="ml-1 text-xs opacity-70">({tables(i)})</span></Chip>)}</div>
          <div className="grid grid-cols-2 gap-2"><Field label="Name"><Input value={t.name} onChange={(e) => setT({ ...t, name: e.target.value })} /></Field><Field label="Mobile"><Input value={t.phone} maxLength={10} onChange={(e) => setT({ ...t, phone: e.target.value })} /></Field></div>
          <Field label="Special request"><Input value={t.note} placeholder="Birthday, high chair…" onChange={(e) => setT({ ...t, note: e.target.value })} /></Field>
          <KV rows={[["Cancellation", "Free up to 1 hour before"]]} />
        </div>
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
