"use client";
import { useState } from "react";
import { Camera, Check, ShieldCheck, Award, Users, Clock, Languages, Stethoscope } from "lucide-react";
import { useApp } from "@/lib/store";
import { HOME_CATS, RATE_CARDS, professionalsFor } from "@/data/services";
import { Avatar, Badge, Button, Card, Chip, Empty, Field, Notice, PageHeader, Rating, Select, Sheet, Textarea, KV } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { cn, dayLabel, inr, nextDays } from "@/lib/utils";

const SLOTS = ["8 – 10 AM", "10 AM – 12 PM", "12 – 2 PM", "2 – 4 PM", "4 – 6 PM", "6 – 8 PM"];

export default function CatClient({ cat }: { cat: string }) {
  const { s } = useApp();
  const c = HOME_CATS.find((x) => x.id === cat);
  const rc = RATE_CARDS[cat] ?? [];
  const pros = professionalsFor(cat);
  const [sel, setSel] = useState<string[]>([]);
  const [pro, setPro] = useState<string>("auto");
  const [view, setView] = useState<(typeof pros)[number] | null>(null);
  const [day, setDay] = useState(0);
  const [slot, setSlot] = useState("");
  const [addr, setAddr] = useState(s.addresses[0]?.id ?? "");
  const [desc, setDesc] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [duration, setDuration] = useState("Single visit");
  if (!c) return <Empty title="Service not found" />;
  const care = cat === "nurse" || cat === "attendant";
  const chosen = rc.filter((r) => sel.includes(r.item));
  const mult = care && duration !== "Single visit" ? Number(duration.split(" ")[0]) : 1;
  const fees = [
    ...(c.visit ? [{ label: "Visit charge (adjusted against job)", amount: c.visit }] : []),
    ...chosen.map((r) => ({ label: `${r.item}${mult > 1 ? ` × ${mult} days` : ""}`, amount: r.price * mult })),
    { label: "Platform fee", amount: 19 },
  ];
  const assigned = pro === "auto" ? pros[0] : pros.find((p) => p.id === pro)!;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title={c.name} sub={`${c.group} · ${s.lang === "ta" ? c.ta : ""}`} />
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          <Card>
            <p className="font-bold">About this service</p>
            <p className="mt-1 text-sm text-muted">Book a verified {c.name.toLowerCase()} for your home. The professional assesses the job on arrival; any extra work or material is priced in the app and done only after you approve it.{care && " Nurses and attendants are verified for qualifications and registration; doctor's care instructions can be recorded and shared with family."}</p>
          </Card>
          <Card>
            <div className="mb-2 flex items-center justify-between"><p className="font-bold">Rate card</p><Badge tone="gold">Demo rates</Badge></div>
            <div className="divide-y divide-line">
              {rc.map((r) => { const on = sel.includes(r.item); return (
                <button key={r.item} onClick={() => setSel(on ? sel.filter((x) => x !== r.item) : [...sel, r.item])} className="flex w-full items-center gap-3 py-3 text-left">
                  <span className={cn("grid h-6 w-6 place-items-center rounded-lg border-2", on ? "border-primary bg-primary text-white" : "border-line")}>{on && <Check size={14} />}</span>
                  <span className="flex-1"><span className="block text-sm font-semibold">{r.item}</span><span className="text-xs text-muted"><Clock size={11} className="inline" /> {r.time}</span></span>
                  <span className="font-bold">{r.price ? inr(r.price) : "Free"}</span>
                </button>
              ); })}
            </div>
            {c.visit > 0 && <p className="mt-2 text-xs text-muted">Fixed visit charge {inr(c.visit)} – adjusted against the job if you go ahead.</p>}
          </Card>
          {care && <Card><p className="mb-2 font-bold">Duration</p><div className="flex flex-wrap gap-2">{["Single visit", "7 days", "14 days", "30 days"].map((d) => <Chip key={d} active={duration === d} onClick={() => setDuration(d)}>{d}</Chip>)}</div></Card>}
          <Card>
            <p className="mb-3 font-bold">Choose a professional</p>
            <div className="space-y-2">
              <button onClick={() => setPro("auto")} className={cn("flex w-full items-center gap-3 rounded-2xl border p-3 text-left", pro === "auto" ? "border-primary ring-4 ring-primary/10" : "border-line")}>
                <span className="grid h-11 w-11 place-items-center rounded-full bg-gold-soft text-[#8A6A00]"><Users size={20} /></span><span className="flex-1"><b>Best available</b><span className="block text-xs text-muted">Nearest top-rated verified professional</span></span>
              </button>
              {pros.map((p) => (
                <div key={p.id} className={cn("flex items-center gap-3 rounded-2xl border p-3", pro === p.id ? "border-primary ring-4 ring-primary/10" : "border-line")}>
                  <button onClick={() => setPro(p.id)} className="flex flex-1 items-center gap-3 text-left">
                    <Avatar name={p.name} />
                    <span className="min-w-0 flex-1"><span className="block font-semibold">{p.name} <ShieldCheck size={14} className="inline text-success" /></span><span className="block text-xs text-muted">{p.years} yrs · {p.jobs} jobs · next {p.nextSlot}</span>{p.team && <Badge tone="gold">{p.team}</Badge>}</span>
                    <Rating value={p.rating} />
                  </button>
                  <button onClick={() => setView(p)} className="text-xs font-semibold text-primary">Profile</button>
                </div>
              ))}
            </div>
          </Card>
          <Card className="space-y-3">
            <p className="font-bold">When & where</p>
            <div className="no-scrollbar flex gap-2 overflow-x-auto">{nextDays(6).map((d, i) => <Chip key={i} active={day === i} onClick={() => setDay(i)}>{i === 0 ? "Today" : dayLabel(d)}</Chip>)}</div>
            <div className="flex flex-wrap gap-2">{SLOTS.map((x) => <Chip key={x} active={slot === x} onClick={() => setSlot(x)}>{x}</Chip>)}</div>
            <Field label="Address"><Select value={addr} onChange={(e) => setAddr(e.target.value)} options={s.addresses.map((a) => ({ value: a.id, label: `${a.label} – ${a.line}` }))} /></Field>
            <Field label={care ? "Patient details & care needs" : "Describe the problem"} required><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder={care ? "Age, condition, doctor's instructions…" : "e.g. Kitchen tap leaking at the base"} /></Field>
            <div>
              <p className="mb-2 text-sm font-semibold">Photos (optional)</p>
              <div className="flex flex-wrap gap-2">
                {photos.map((p, i) => <img key={i} src={p} alt={`Problem photo ${i + 1}`} className="h-16 w-16 rounded-xl object-cover" />)}
                <label className="grid h-16 w-16 cursor-pointer place-items-center rounded-xl border-2 border-dashed border-line text-muted"><Camera size={20} /><input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = () => setPhotos([...photos, String(r.result)]); r.readAsDataURL(f); }} /></label>
              </div>
            </div>
          </Card>
        </div>
        <div className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <Card>
            <p className="mb-2 font-bold">Booking summary</p>
            {fees.map((f) => <div key={f.label} className="flex justify-between gap-3 py-1 text-sm"><span className="text-muted">{f.label}</span><span>{inr(f.amount)}</span></div>)}
            <div className="mt-2 flex justify-between border-t border-line pt-2 font-bold"><span>Total now</span><span>{inr(fees.reduce((a, b) => a + b.amount, 0))}</span></div>
          </Card>
          <Notice tone="warning">Never pay cash demands outside the app. Extra charges need your approval in the app.</Notice>
          <CheckoutButton label="Confirm booking" category="Home services" allowCash
            validate={() => (!sel.length && !c.visit ? "Select at least one service from the rate card" : !slot ? "Choose a time slot" : desc.trim().length < 5 ? "Describe the job briefly" : null)}
            build={() => ({ module: "home", kind: "booking", title: `${c.name} booking`, subtitle: `${assigned.name} · ${day === 0 ? "Today" : dayLabel(nextDays(6)[day])} ${slot}`, status: "active", stageIdx: 0,
              stages: ["Booking confirmed", "Professional assigned", "On the way", "Job assessment", "Work in progress", "Completed"], fees,
              items: chosen.map((r) => ({ name: r.item, qty: mult, price: r.price })),
              details: { Service: c.name, Address: s.addresses.find((a) => a.id === addr)?.line ?? "", Slot: `${dayLabel(nextDays(6)[day])}, ${slot}`, Problem: desc, ...(photos.length ? { Photos: `${photos.length} attached` } : {}), ...(care ? { Duration: duration } : {}) },
              provider: { name: assigned.name, rating: assigned.rating, extra: `${assigned.years} yrs · ${assigned.certs.join(", ")}` } })} />
        </div>
      </div>
      <Sheet open={!!view} onClose={() => setView(null)} title="Professional profile">
        {view && (
          <div className="space-y-4">
            <div className="flex items-center gap-3"><Avatar name={view.name} size={64} /><div><p className="text-lg font-bold">{view.name}</p><Rating value={view.rating} count={view.jobs} /><Badge tone="success" className="ml-2">Verified</Badge></div></div>
            <KV rows={[["Experience", `${view.years} years`], ["Jobs completed", view.jobs], ["Languages", view.langs], ...(view.regNo ? [["Nursing registration", view.regNo] as [string, string]] : []), ["Next available", view.nextSlot]]} />
            <div><p className="mb-1 flex items-center gap-2 text-sm font-semibold"><Award size={16} />Certifications</p><div className="flex flex-wrap gap-1.5">{view.certs.map((x) => <Badge key={x}>{x}</Badge>)}</div></div>
            <div><p className="mb-1 text-sm font-semibold">Recent reviews</p><p className="text-sm text-muted">“Came on time, explained the problem clearly and fixed it neatly.” – Anitha, Adyar</p><p className="text-sm text-muted">“Polite and professional. Price was exactly as shown.” – Ramesh, Velachery</p></div>
            <Button full onClick={() => { setPro(view.id); setView(null); }}>Choose {view.name.split(" ")[0]}</Button>
            <Languages className="hidden" /><Stethoscope className="hidden" />
          </div>
        )}
      </Sheet>
    </div>
  );
}
