import { HOME_CATS } from "@/data/services";
import CatClient from "./CatClient";
export function generateStaticParams() { return HOME_CATS.map((c) => ({ cat: c.id })); }
export default async function Page({ params }: { params: Promise<{ cat: string }> }) { const { cat } = await params; return <CatClient cat={cat} />; }
