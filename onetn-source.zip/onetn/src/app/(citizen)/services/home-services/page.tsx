"use client";
import Link from "next/link";
import { ShieldCheck, BadgeCheck, Receipt, Undo2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { HOME_CATS } from "@/data/services";
import { Card, PageHeader } from "@/components/ui";

export default function HomeServices() {
  const { s } = useApp();
  const groups = Array.from(new Set(HOME_CATS.map((c) => c.group)));
  return (
    <div className="space-y-6">
      <PageHeader title="Home Services" sub="Verified professionals · rate card before you book" />
      <div className="grid gap-3 sm:grid-cols-4">
        {[{ i: ShieldCheck, t: "Identity & background verified" }, { i: Receipt, t: "Standard rate card" }, { i: BadgeCheck, t: "Extra work only with your approval" }, { i: Undo2, t: "Service guarantee" }].map((x) => (
          <Card key={x.t} className="flex items-center gap-3 p-3"><x.i className="shrink-0 text-success" size={20} /><span className="text-sm font-semibold">{x.t}</span></Card>
        ))}
      </div>
      {groups.map((g) => (
        <section key={g}>
          <h2 className="mb-3 font-bold">{g}</h2>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-7">
            {HOME_CATS.filter((c) => c.group === g).map((c, i) => (
              <Link key={c.id} href={`/services/home-services/${c.id}`} className="card flex flex-col items-center gap-2 px-2 py-4 text-center hover:shadow-[var(--shadow-lift)]">
                <span className={["grid h-13 w-13 place-items-center rounded-[18px] p-3 bg-primary-soft text-primary", "grid h-13 w-13 place-items-center rounded-[18px] p-3 bg-gold-soft text-[#8A6A00]", "grid h-13 w-13 place-items-center rounded-[18px] p-3 bg-success-soft text-success"][i % 3]}><c.icon size={24} /></span>
                <span className="text-[12.5px] font-semibold leading-tight">{s.lang === "ta" ? c.ta : c.name}</span>
              </Link>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
