"use client";
import { useState } from "react";
import { Sprout, Star, Package } from "lucide-react";
import { useApp } from "@/lib/store";
import { BUNDLES, FARMERS, MARKETS, PRODUCE } from "@/data/delivery";
import { Avatar, Badge, Card, Chip, Field, PageHeader, Qty, Select, SectionHeader } from "@/components/ui";
import { ProductGrid } from "@/components/flows/ProductGrid";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { inr } from "@/lib/utils";

export default function Uzhavar() {
  const { cart, setQty } = useApp();
  const [mk, setMk] = useState(MARKETS[0]);
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState(false);
  const key = `uzhavar-${mk.id}`;
  const c = cart(key);
  return (
    <div>
      <PageHeader title="Uzhavar Sandhai" sub="Fresh produce direct from farmers · prices set by the market" />
      <Card className="mb-4 grid items-end gap-3 sm:grid-cols-[1fr_auto]">
        <Field label="Market"><Select value={mk.id} onChange={(e) => setMk(MARKETS.find((m) => m.id === e.target.value)!)} options={MARKETS.map((m) => ({ value: m.id, label: `${m.name} (${m.district})` }))} /></Field>
        <p className="text-sm text-muted">{mk.farmers} farmers selling today · <Badge tone="success">Today&apos;s prices</Badge></p>
      </Card>
      <SectionHeader title="Ready-made bundles" />
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        {BUNDLES.map((b) => (
          <Card key={b.id}>
            <p className="flex items-center gap-2 font-bold"><Package size={17} className="text-success" />{b.name}</p>
            <p className="mt-1 text-xs text-muted">{b.desc}</p><p className="mt-1 text-xs">{b.serves}</p>
            <div className="mt-3 flex items-center justify-between"><span className="text-lg font-bold">{inr(b.price)}</span><Qty value={c.find((x) => x.id === b.id)?.qty ?? 0} onChange={(v) => setQty(key, { id: b.id, name: b.name, price: b.price, unit: "Bundle" }, v)} /></div>
          </Card>
        ))}
      </div>
      <SectionHeader title="Daily produce" />
      <div className="no-scrollbar mb-3 flex gap-2">{["All", "Vegetables", "Fruits"].map((x) => <Chip key={x} active={cat === x} onClick={() => setCat(x)}>{x}</Chip>)}</div>
      <ProductGrid icon={Sprout} cartKey={key} store={mk.name} items={PRODUCE.filter((p) => cat === "All" || p.cat === cat).map((p) => ({ ...p, sub: FARMERS.find((f) => f.id === p.farmer)?.name }))} />
      <SectionHeader title="Meet the farmers" />
      <div className="grid gap-3 sm:grid-cols-3">
        {FARMERS.map((f) => (
          <Card key={f.id} className="flex items-center gap-3"><Avatar name={f.name} tone="gold" /><div><p className="font-semibold">{f.name}</p><p className="text-xs text-muted">{f.village} · {f.years} yrs farming</p><p className="text-xs">{f.crops}</p><p className="flex items-center gap-1 text-xs"><Star size={12} className="fill-gold text-gold" />{f.rating}</p></div></Card>
        ))}
      </div>
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={{ cartKey: key, module: "uzhavar", title: "Uzhavar Sandhai order", store: mk.name, category: "Essentials", deliveryFee: 20, platformFee: 0, repeatHref: "/services/uzhavar-sandhai", substitution: true,
        stages: ["Order placed", "Farmers packing", "Rider assigned", "Out for delivery", "Delivered"], extraDetails: { Note: "Farmers are paid to their Wallet on delivery" } }} />
    </div>
  );
}
