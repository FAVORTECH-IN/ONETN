"use client";
import { useState } from "react";
import { Pill, Upload, FileCheck2, Search, Bell, Store, ShieldCheck } from "lucide-react";
import { useApp } from "@/lib/store";
import { MEDICINES, PHARMACIES } from "@/data/delivery";
import { Badge, Card, Chip, Notice, PageHeader, Qty, Toggle, Rating } from "@/components/ui";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { cn, inr } from "@/lib/utils";

export default function Medicines() {
  const { cart, setQty, toast } = useApp();
  const [ph, setPh] = useState(PHARMACIES[0]);
  const [q, setQ] = useState("");
  const [rx, setRx] = useState<string | null>(null);
  const [remind, setRemind] = useState(false);
  const [open, setOpen] = useState(false);
  const key = `medicine-${ph.id}`;
  const c = cart(key);
  const list = MEDICINES.filter((m) => !q || m.name.toLowerCase().includes(q.toLowerCase()) || m.use.toLowerCase().includes(q.toLowerCase()));
  const needsRx = c.some((i) => MEDICINES.find((m) => m.id === i.id.replace("-g", ""))?.rx);
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Medicine Delivery" sub="Government medical shops & licensed pharmacies" />
      <p className="mb-2 text-sm font-semibold">Choose pharmacy</p>
      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        {PHARMACIES.map((p) => (
          <button key={p.id} onClick={() => setPh(p)} className={cn("card p-3 text-left", ph.id === p.id && "border-primary ring-4 ring-primary/10")}>
            <p className="flex items-center gap-2 font-semibold"><Store size={16} className="text-primary" />{p.name}</p>
            <p className="text-xs text-muted">{p.type} · {p.km} km · ~{p.eta} min</p><div className="mt-1 flex items-center gap-2"><Rating value={p.rating} /><Badge tone="success">Licensed</Badge></div>
          </button>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="space-y-3">
          <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search medicine or condition" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
          {list.map((m) => {
            const qty = c.find((x) => x.id === m.id)?.qty ?? 0;
            const gq = c.find((x) => x.id === m.id + "-g")?.qty ?? 0;
            return (
              <Card key={m.id}>
                <div className="flex items-start gap-3">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary"><Pill size={20} /></span>
                  <div className="flex-1"><p className="font-semibold">{m.name} {m.rx && <Badge tone="error">Rx</Badge>}</p><p className="text-xs text-muted">{m.form} · {m.use}</p><p className="mt-1 font-bold">{inr(m.price)}</p></div>
                  <Qty value={qty} onChange={(v) => setQty(key, { id: m.id, name: m.name, price: m.price, unit: m.form }, v)} />
                </div>
                {m.generic && (
                  <div className="mt-3 flex items-center gap-3 rounded-2xl bg-success-soft p-3">
                    <span className="flex-1 text-sm"><b className="text-success">Generic option:</b> {m.generic.name} – {inr(m.generic.price)} <span className="text-success">(save {inr(m.price - m.generic.price)})</span></span>
                    <Qty value={gq} onChange={(v) => setQty(key, { id: m.id + "-g", name: m.generic!.name, price: m.generic!.price, unit: m.form }, v)} />
                  </div>
                )}
              </Card>
            );
          })}
        </div>
        <div className="space-y-4">
          <Card className="space-y-3">
            <p className="font-bold">Prescription</p>
            {rx ? <p className="flex items-center gap-2 text-sm text-success"><FileCheck2 size={18} />{rx} uploaded · awaiting pharmacist verification</p>
              : <p className="text-sm text-muted">Required for medicines marked Rx. A registered pharmacist checks it before dispatch.</p>}
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-primary/40 bg-white py-4 text-sm font-semibold text-primary">
              <Upload size={18} />{rx ? "Replace prescription" : "Upload prescription"}
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) { setRx(f.name); toast("Prescription uploaded"); } }} />
            </label>
            <p className="flex items-center gap-2 text-xs text-muted"><ShieldCheck size={14} />Verified by {ph.pharmacist}</p>
          </Card>
          <Card className="flex items-center gap-3"><Bell className="text-primary" /><div className="flex-1"><p className="text-sm font-semibold">Repeat medicine reminders</p><p className="text-xs text-muted">Monthly reminder & one-tap reorder for long-term medicines</p></div><Toggle checked={remind} onChange={(v) => { setRemind(v); toast(v ? "Monthly reminder set" : "Reminder off", "info"); }} /></Card>
          {needsRx && !rx && <Notice tone="warning">Your cart has prescription medicines. Upload a valid prescription to check out.</Notice>}
          <div className="flex flex-wrap gap-2">{["Fever", "Diabetes", "Allergy", "First aid"].map((x) => <Chip key={x} onClick={() => setQ(x)}>{x}</Chip>)}</div>
        </div>
      </div>
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={{
        cartKey: key, module: "medicine", title: "Medicine order", store: ph.name, category: "Healthcare", deliveryFee: 20, platformFee: 0, repeatHref: "/services/medicines",
        stages: ["Order placed", "Pharmacist verifying prescription", "Packed", "Out for delivery", "Delivered"],
        validate: () => (needsRx && !rx ? "Upload a valid prescription for Rx medicines" : null),
        extraDetails: { Prescription: rx ?? "Not required", Pharmacist: ph.pharmacist, "Repeat reminder": remind ? "Monthly" : "Off" },
        notice: <Notice tone="info">Prescription medicines are dispatched only after a registered pharmacist verifies your prescription. Stored and carried as per handling rules.</Notice>,
      }} />
    </div>
  );
}
