import type { CartConfig } from "@/components/flows/CartCheckout";
import type { StoreT } from "@/data/delivery";
export const quickCfg = (st: StoreT): CartConfig => ({
  cartKey: `grocery-${st.id}`, module: "grocery", title: "Grocery order", store: st.name, category: "Groceries", deliveryFee: 25, platformFee: 5, freeDeliveryAbove: 499,
  repeatHref: `/services/quick-delivery/store?id=${st.id}`, coupons: true, substitution: true, instructions: true,
});
