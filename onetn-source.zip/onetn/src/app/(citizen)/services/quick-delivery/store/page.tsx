"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Clock, Star, MapPin, Store as StoreIcon } from "lucide-react";
import { STORES, PRODUCTS, QUICK_CATS } from "@/data/delivery";
import { Badge, Card, Chip, PageHeader, Thumb, Empty } from "@/components/ui";
import { ProductGrid } from "@/components/flows/ProductGrid";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { quickCfg } from "./cfg";

function Inner() {
  const st = STORES.find((s) => s.id === useSearchParams().get("id")) ?? STORES[0];
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState(false);
  const prods = PRODUCTS.filter((p) => cat === "All" || p.cat === cat);
  return (
    <div>
      <PageHeader title={st.name} sub={`${st.type} · ${st.area}`} />
      <Card className="mb-4 flex flex-wrap items-center gap-4">
        <Thumb hue={st.hue} icon={StoreIcon} size={72} />
        <div className="flex-1 space-y-1 text-sm">
          <p className="flex items-center gap-2"><Star size={14} className="fill-gold text-gold" /><b>{st.rating}</b> · <Clock size={14} />{st.eta} min · <MapPin size={14} />{st.km} km</p>
          <p className="text-muted">Open {st.open} · Prices set by the store</p>
          <div className="flex gap-1.5">{st.tags.map((t) => <Badge key={t}>{t}</Badge>)}<Badge tone="success">Verified store</Badge></div>
        </div>
      </Card>
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto">{["All", ...QUICK_CATS].map((c) => <Chip key={c} active={cat === c} onClick={() => setCat(c)}>{c}</Chip>)}</div>
      {prods.length ? <ProductGrid items={prods} cartKey={`grocery-${st.id}`} store={st.name} hrefFor={(id) => `/services/quick-delivery/product?id=${id}&store=${st.id}`} /> : <Empty title="Nothing in this category" />}
      <CartBar cartKey={`grocery-${st.id}`} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={quickCfg(st)} />
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
