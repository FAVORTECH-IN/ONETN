"use client";
import Link from "next/link";
import { useState } from "react";
import { Search, Clock, Star, Store } from "lucide-react";
import { STORES, PRODUCTS, QUICK_CATS } from "@/data/delivery";
import { Badge, Chip, Empty, PageHeader, SectionHeader, Thumb } from "@/components/ui";
import { ProductGrid } from "@/components/flows/ProductGrid";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { quickCfg } from "./store/cfg";

export default function Quick() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState(false);
  const prods = PRODUCTS.filter((p) => (cat === "All" || p.cat === cat) && (!q || p.name.toLowerCase().includes(q.toLowerCase())));
  const stores = STORES.filter((s) => cat === "All" || s.tags.includes(cat));
  const st = STORES[0];
  return (
    <div>
      <PageHeader title="Quick Delivery" sub="Groceries & daily needs from nearby stores" />
      <div className="relative mb-3"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search rice, milk, notebook…" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto">{["All", ...QUICK_CATS].map((c) => <Chip key={c} active={cat === c} onClick={() => setCat(c)}>{c}</Chip>)}</div>
      {!q && (
        <section className="mb-6">
          <SectionHeader title="Nearby stores" />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {stores.map((s) => (
              <Link key={s.id} href={`/services/quick-delivery/store?id=${s.id}`} className="card flex gap-3 p-3 hover:shadow-[var(--shadow-lift)]">
                <Thumb hue={s.hue} icon={Store} size={64} />
                <div className="min-w-0"><p className="truncate font-semibold">{s.name}</p><p className="text-xs text-muted">{s.type} · {s.area}</p>
                  <p className="mt-1 flex items-center gap-2 text-xs"><Clock size={12} />{s.eta} min · {s.km} km <Star size={12} className="fill-gold text-gold" />{s.rating}</p>
                  {s.type.startsWith("Government") && <Badge tone="gold" className="mt-1">Cooperative</Badge>}</div>
              </Link>
            ))}
          </div>
        </section>
      )}
      <SectionHeader title={q ? `Results for “${q}”` : cat === "All" ? `Popular at ${st.name}` : cat} />
      {prods.length ? <ProductGrid items={prods} cartKey={`grocery-${st.id}`} store={st.name} hrefFor={(id) => `/services/quick-delivery/product?id=${id}`} /> : <Empty title="No products found" body="Try a different search or category." />}
      <CartBar cartKey={`grocery-${st.id}`} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={quickCfg(st)} />
    </div>
  );
}
