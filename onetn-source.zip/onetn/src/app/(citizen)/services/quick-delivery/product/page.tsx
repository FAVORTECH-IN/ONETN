"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ShoppingBasket, ShieldCheck, Truck, RotateCcw } from "lucide-react";
import { PRODUCTS, STORES } from "@/data/delivery";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Empty, PageHeader, Qty, Thumb, Notice } from "@/components/ui";
import { ProductGrid } from "@/components/flows/ProductGrid";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { quickCfg } from "../store/cfg";
import { inr } from "@/lib/utils";

function Inner() {
  const sp = useSearchParams();
  const p = PRODUCTS.find((x) => x.id === sp.get("id"));
  const st = STORES.find((s) => s.id === sp.get("store")) ?? STORES[0];
  const { cart, setQty } = useApp();
  const [open, setOpen] = useState(false);
  const [img, setImg] = useState(0);
  if (!p) return <Empty title="Product not found" action={<Button href="/services/quick-delivery">Back to store</Button>} />;
  const key = `grocery-${st.id}`;
  const q = cart(key).find((x) => x.id === p.id)?.qty ?? 0;
  return (
    <div>
      <PageHeader title={p.name} sub={`Sold by ${st.name}`} />
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <Thumb hue={p.hue + img} icon={ShoppingBasket} className="h-72 w-full" size={260} />
          <div className="mt-2 flex gap-2">{[0, 1, 2].map((i) => <button key={i} onClick={() => setImg(i)} aria-label={`Image ${i + 1}`} className={i === img ? "rounded-2xl ring-2 ring-primary" : ""}><Thumb hue={p.hue + i} icon={ShoppingBasket} size={64} /></button>)}</div>
        </div>
        <div className="space-y-4">
          <div><Badge>{p.cat}</Badge>{p.ta && <p className="mt-2 text-muted">{p.ta}</p>}<p className="mt-1 text-3xl font-extrabold">{inr(p.price)} {p.mrp && <span className="text-base font-normal text-muted line-through">{inr(p.mrp)}</span>}</p><p className="text-sm text-muted">{p.unit} · inclusive of all taxes</p></div>
          <p>{p.desc ?? "Quality-checked by the store. Stored and packed as per food-safety rules."}</p>
          <div className="flex items-center gap-3"><Qty value={q} onChange={(v) => setQty(key, { id: p.id, name: p.name, price: p.price, unit: p.unit, store: st.name }, v)} />{q > 0 && <Button onClick={() => setOpen(true)}>Go to cart</Button>}</div>
          <Card className="space-y-2 text-sm"><p className="flex items-center gap-2"><Truck size={16} className="text-primary" />Delivery in ~{st.eta} min</p><p className="flex items-center gap-2"><RotateCcw size={16} className="text-primary" />Wrong/damaged items refunded to Wallet</p><p className="flex items-center gap-2"><ShieldCheck size={16} className="text-primary" />Verified store · food-safety compliant</p></Card>
          <Notice tone="info">Items restricted by law are never offered.</Notice>
        </div>
      </div>
      <h2 className="mb-3 mt-8 text-lg font-bold">You may also need</h2>
      <ProductGrid items={PRODUCTS.filter((x) => x.cat === p.cat && x.id !== p.id).slice(0, 4)} cartKey={key} store={st.name} hrefFor={(id) => `/services/quick-delivery/product?id=${id}&store=${st.id}`} />
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={quickCfg(st)} />
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
