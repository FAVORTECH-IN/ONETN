"use client";
import { useEffect, useRef, useState } from "react";
import { Brain, Send, Plus, MessageSquare, Trash2, Sparkles } from "lucide-react";
import { useApp, type ChatMsg } from "@/lib/store";
import { Button, Card, Chip, Notice, PageHeader, Select, SimTag } from "@/components/ui";
import { cn, uid } from "@/lib/utils";

const EXAMS = ["NEET", "TNPSC Group 4", "Class 10 Board", "Class 12 Board", "GRE", "JEE"];
function reply(q: string, lang: string, exam: string, weeks: number): string {
  const x = q.toLowerCase();
  const ta = lang === "Tamil";
  if (/plan|schedule|timetable|திட்டம்/.test(x)) {
    const w = Math.max(1, weeks);
    return (ta ? `${exam} க்கான ${w} வார படிப்புத் திட்டம்:\n` : `${w}-week study plan for ${exam}:\n`) +
      Array.from({ length: Math.min(w, 6) }, (_, i) => `Week ${i + 1}: ${["Foundations & syllabus mapping", "Core concepts – high-weightage units", "Practice sets + previous papers", "Weak-topic revision", "Full-length mock tests", "Final revision & rest"][i]}`).join("\n") +
      (ta ? "\n\nதினமும் 1 மாதிரித் தேர்வு பகுதி செய்யுங்கள்." : "\n\nTip: take one topic test daily in Mock Tests and review mistakes.");
  }
  if (/practice|question|quiz|பயிற்சி/.test(x)) return ta ? "பயிற்சி வினாக்கள்:\n1. ஒளிச்சேர்க்கை எங்கு நடைபெறுகிறது?\n2. நியூட்டனின் இரண்டாம் விதியைக் கூறுக.\n3. pH 7 என்றால் என்ன?\nவிடைகளை எழுதி அனுப்புங்கள் – நான் சரிபார்க்கிறேன்." : `Practice questions (${exam}):\n1. Where does photosynthesis take place, and what are its products?\n2. State Newton's second law with its SI unit.\n3. Why is DNA replication called semi-conservative?\nReply with your answers and I'll check them.`;
  if (/photosynth|ஒளிச்சேர்க்கை/.test(x)) return ta ? "ஒளிச்சேர்க்கை: பச்சை தாவரங்கள் சூரிய ஒளி, நீர், கார்பன் டை ஆக்சைடு கொண்டு குளுக்கோஸ் மற்றும் ஆக்சிஜனை உருவாக்கும் செயல். இது பசுங்கணிகத்தில் (chloroplast) நடைபெறுகிறது." : "Photosynthesis: green plants use sunlight, water and CO₂ to make glucose and release oxygen. It happens in chloroplasts – the light reactions in the thylakoids and the Calvin cycle in the stroma.\n6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂.\nSee: Class 10 Science – State Board, Chapter on Plant Physiology.";
  if (/newton|force|விசை/.test(x)) return ta ? "நியூட்டனின் இரண்டாம் விதி: விசை = நிறை × முடுக்கம் (F = ma). அலகு நியூட்டன்." : "Newton's second law: Force = mass × acceleration (F = ma). Unit: newton (N) = kg·m/s². Doubling the force on the same mass doubles its acceleration.";
  return ta ? `நல்ல கேள்வி! "${q}" பற்றி நூலகத்தின் உள்ளடக்கத்தைப் பயன்படுத்தி எளிமையாக விளக்குகிறேன். (டெமோ: உண்மையான AI இணைக்கப்படவில்லை.) "explain photosynthesis", "study plan" அல்லது "practice questions" என்று முயற்சிக்கவும்.`
    : `Good question! I'd explain "${q}" step by step using the library's own material. (Demo: the AI provider isn't connected yet, so I answer a few topics.) Try "explain photosynthesis", "make a study plan" or "practice questions".`;
}

export default function AIGuide() {
  const { s, set } = useApp();
  const [lang, setLang] = useState("English");
  const [exam, setExam] = useState("NEET");
  const [weeks, setWeeks] = useState(8);
  const [cid, setCid] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<ChatMsg[]>([{ role: "ai", text: "Vanakkam! I'm your AI study guide. Ask me to explain a concept, build a study plan or give practice questions – in Tamil or English." }]);
  const [q, setQ] = useState("");
  const [typing, setTyping] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs, typing]);
  const send = (text = q) => {
    if (!text.trim()) return;
    const next: ChatMsg[] = [...msgs, { role: "user", text }];
    setMsgs(next); setQ(""); setTyping(true);
    setTimeout(() => {
      const all: ChatMsg[] = [...next, { role: "ai", text: reply(text, lang, exam, weeks) }];
      setMsgs(all); setTyping(false);
      const id = cid ?? uid("C");
      if (!cid) setCid(id);
      set((p) => ({ ...p, conversations: [{ id, title: all.find((m) => m.role === "user")?.text.slice(0, 40) ?? "Chat", at: new Date().toISOString(), msgs: all }, ...p.conversations.filter((c) => c.id !== id)] }));
    }, 700);
  };
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="AI Study Guide" sub="Explains, plans and quizzes – safe and age-appropriate" right={<SimTag label="Demo answers" />} />
      <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
        <aside className="space-y-3">
          <Card className="space-y-3">
            <div><p className="mb-1 text-xs font-semibold text-muted">Language</p><div className="flex gap-2">{["English", "Tamil"].map((l) => <Chip key={l} active={lang === l} onClick={() => setLang(l)}>{l === "Tamil" ? "தமிழ்" : l}</Chip>)}</div></div>
            <div><p className="mb-1 text-xs font-semibold text-muted">Exam</p><Select value={exam} onChange={(e) => setExam(e.target.value)} options={EXAMS} /></div>
            <div><p className="mb-1 text-xs font-semibold text-muted">Preparation time: {weeks} weeks</p><input type="range" min={1} max={24} value={weeks} onChange={(e) => setWeeks(Number(e.target.value))} className="w-full accent-[#8B0000]" /></div>
            <Button size="sm" full variant="soft" onClick={() => send(`Make a study plan for ${exam}`)}><Sparkles size={15} />Build study plan</Button>
            <p className="text-xs text-muted">Recommended topics for {exam}: {exam === "NEET" ? "Genetics, Human physiology, Mechanics" : exam.includes("TNPSC") ? "Tamil literature, Polity, TN history" : "Algebra, Physics basics"}</p>
          </Card>
          <Card className="p-3">
            <div className="mb-2 flex items-center justify-between"><p className="text-sm font-bold">Saved chats</p><button aria-label="New chat" onClick={() => { setCid(null); setMsgs([{ role: "ai", text: "New chat started. What shall we study?" }]); }}><Plus size={17} /></button></div>
            {s.conversations.length === 0 ? <p className="text-xs text-muted">None yet</p> : s.conversations.slice(0, 6).map((c) => (
              <div key={c.id} className={cn("flex items-center gap-2 rounded-xl px-2 py-1.5 text-sm", cid === c.id && "bg-primary-soft")}>
                <button className="flex flex-1 items-center gap-2 truncate text-left" onClick={() => { setCid(c.id); setMsgs(c.msgs); }}><MessageSquare size={14} />{c.title}</button>
                <button aria-label="Delete chat" onClick={() => set((p) => ({ ...p, conversations: p.conversations.filter((x) => x.id !== c.id) }))}><Trash2 size={13} className="text-muted" /></button>
              </div>
            ))}
          </Card>
        </aside>
        <Card className="flex h-[70vh] flex-col p-0">
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <div key={i} className={cn("flex gap-2", m.role === "user" && "justify-end")}>
                {m.role === "ai" && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#EFE6F6] text-[#5B3A86]"><Brain size={16} /></span>}
                <p className={cn("max-w-[80%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm", m.role === "user" ? "bg-primary text-white" : "bg-cream")}>{m.text}</p>
              </div>
            ))}
            {typing && <p className="pulse-dot text-sm text-muted">Thinking…</p>}
            <div ref={end} />
          </div>
          <div className="border-t border-line p-3">
            <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">{["Explain photosynthesis", "Practice questions", "Newton's second law", "ஒளிச்சேர்க்கை விளக்கு"].map((x) => <Chip key={x} className="h-8 text-xs" onClick={() => send(x)}>{x}</Chip>)}</div>
            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={lang === "Tamil" ? "உங்கள் கேள்வியைக் கேளுங்கள்…" : "Ask anything…"} className="h-12 flex-1 rounded-2xl border border-line px-4 outline-none focus:border-primary" />
              <Button type="submit" aria-label="Send"><Send size={18} /></Button>
            </form>
          </div>
        </Card>
      </div>
      <Notice tone="info" className="mt-4">Supports learning; does not replace teachers. Answers are reviewed regularly and student data is protected. A real AI provider must be connected and approved before launch.</Notice>
    </div>
  );
}
