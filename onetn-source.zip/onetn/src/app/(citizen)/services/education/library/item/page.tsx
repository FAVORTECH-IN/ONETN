"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { BookOpen, Bookmark, BookmarkCheck, Download, Play, Pause, Video } from "lucide-react";
import { useApp } from "@/lib/store";
import { LIBRARY } from "@/data/learning";
import { Badge, Button, Card, Empty, KV, Notice, PageHeader, Sheet, Thumb } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { downloadText, inr } from "@/lib/utils";

function Inner() {
  const l = LIBRARY.find((x) => x.id === useSearchParams().get("id"));
  const { s, set, toast } = useApp();
  const [reader, setReader] = useState(false);
  const [playing, setPlaying] = useState(false);
  const owned = l && (l.free || s.bookings.some((b) => b.details["Item"] === l.id));
  const prog = l ? s.progress[l.id] ?? 0 : 0;
  useEffect(() => {
    if (!playing || !l) return;
    const t = setInterval(() => set((p) => ({ ...p, progress: { ...p.progress, [l.id]: Math.min(100, (p.progress[l.id] ?? 0) + 2) } })), 600);
    return () => clearInterval(t);
  }, [playing, l, set]);
  if (!l) return <Empty title="Item not found" />;
  const saved = s.library.includes(l.id);
  const isVideo = l.kind === "Video" || l.kind === "Course";
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={l.title} sub={`${l.kind} · ${l.stage}`} right={<button aria-label="Save" onClick={() => { set((p) => ({ ...p, library: saved ? p.library.filter((x) => x !== l.id) : [...p.library, l.id] })); toast(saved ? "Removed from library" : "Saved for offline"); }} className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white">{saved ? <BookmarkCheck className="text-primary" size={19} /> : <Bookmark size={19} />}</button>} />
      {isVideo ? (
        <div className="relative grid aspect-video place-items-center overflow-hidden rounded-[20px] bg-ink text-white">
          <Video size={48} className="opacity-30" />
          {owned && <button onClick={() => setPlaying(!playing)} aria-label={playing ? "Pause" : "Play"} className="absolute grid h-16 w-16 place-items-center rounded-full bg-primary">{playing ? <Pause /> : <Play />}</button>}
          <div className="absolute inset-x-0 bottom-0 h-1.5 bg-white/20"><div className="h-full bg-gold" style={{ width: `${prog}%` }} /></div>
          <span className="absolute left-3 top-3 rounded-full bg-white/15 px-2 py-0.5 text-[11px]">Demo player · content not loaded</span>
        </div>
      ) : <Thumb hue={l.hue} icon={BookOpen} className="h-48 w-full" size={180} />}
      <div className="flex flex-wrap gap-2">{l.free ? <Badge tone="success">Free</Badge> : <Badge tone="gold">{inr(l.price!)}</Badge>}<Badge>{l.lang}</Badge><Badge>{l.subject}</Badge></div>
      <p>{l.desc}</p>
      <Card><KV rows={[["Source", l.source], [l.pages ? "Pages" : "Duration", l.pages ? l.pages : `${l.mins} min`], ["Your progress", `${prog}%`]]} /></Card>
      {owned ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {!isVideo && <Button onClick={() => { setReader(true); set((p) => ({ ...p, progress: { ...p.progress, [l.id]: Math.max(p.progress[l.id] ?? 0, 12) } })); }}><BookOpen size={18} />{prog ? "Continue reading" : "Read now"}</Button>}
          {isVideo && <Button onClick={() => setPlaying(!playing)}>{playing ? "Pause" : prog ? "Resume" : "Start"} lesson</Button>}
          <Button variant="outline" onClick={() => { downloadText(`${l.title}.txt`, `${l.title}\nSource: ${l.source}\n(Demo placeholder – licensed file would download here for offline use.)`); set((p) => ({ ...p, library: Array.from(new Set([...p.library, l.id])) })); }}><Download size={18} />Download for offline</Button>
        </div>
      ) : (
        <CheckoutButton label={`Buy for ${inr(l.price!)}`} category="Education" onDone={() => toast("Unlocked – happy learning!")}
          build={() => ({ module: "education", kind: "booking", title: `Library: ${l.title}`, subtitle: l.source, status: "completed", stageIdx: 0, stages: ["Purchased"], fees: [{ label: l.title, amount: l.price!, payee: "Publisher (licensed)" }], details: { Item: l.id, Licence: "Personal use, 1 year" } })} />
      )}
      <Notice tone="info">Content is added with the owner&apos;s permission. Government textbooks are always free.</Notice>
      <Sheet open={reader} onClose={() => setReader(false)} title={l.title} wide>
        <article className="prose max-w-none text-[15px] leading-7">
          <p className="text-xs text-muted">Reader preview · page 1 of {l.pages}</p>
          <h3 className="mt-2 text-lg font-bold">Chapter 1</h3>
          <p>This is a demo reader. In production, the licensed PDF/EPUB is rendered here with bookmarks, Tamil/English toggle and offline caching. Your place is remembered so you can continue where you stopped.</p>
          <Button className="mt-4" onClick={() => { set((p) => ({ ...p, progress: { ...p.progress, [l.id]: Math.min(100, (p.progress[l.id] ?? 0) + 10) } })); toast("Progress saved"); }}>Next page</Button>
        </article>
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
