"use client";
import Link from "next/link";
import { useState } from "react";
import { BookOpen, Video, FileText, ScrollText, GraduationCap, Search } from "lucide-react";
import { LIBRARY } from "@/data/learning";
import { Badge, Chip, Empty, PageHeader, Thumb } from "@/components/ui";
import { inr } from "@/lib/utils";

const ICON = { Textbook: BookOpen, "Reference book": BookOpen, Notes: FileText, "Previous paper": ScrollText, Video: Video, Course: GraduationCap };
export default function Library() {
  const [stage, setStage] = useState("All");
  const [kind, setKind] = useState("All");
  const [lang, setLang] = useState("All");
  const [free, setFree] = useState(false);
  const [q, setQ] = useState("");
  const list = LIBRARY.filter((l) => (stage === "All" || l.stage === stage) && (kind === "All" || l.kind === kind) && (lang === "All" || l.lang.includes(lang)) && (!free || l.free) && (!q || (l.title + l.subject).toLowerCase().includes(q.toLowerCase())));
  return (
    <div>
      <PageHeader title="Learning Library" sub="School · College · Competitive exams (NEET, GRE, TNPSC) · Skills" />
      <div className="relative mb-3"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search books, subjects, exams" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <div className="space-y-2">
        <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", "School", "College", "Competitive exams", "Skills & careers"].map((x) => <Chip key={x} active={stage === x} onClick={() => setStage(x)}>{x}</Chip>)}</div>
        <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", "Textbook", "Reference book", "Notes", "Previous paper", "Video", "Course"].map((x) => <Chip key={x} className="h-8 text-xs" active={kind === x} onClick={() => setKind(x)}>{x}</Chip>)}
          {["All", "Tamil", "English"].map((x) => <Chip key={"l" + x} className="h-8 text-xs" active={lang === x} onClick={() => setLang(x)}>{x === "All" ? "Any language" : x}</Chip>)}
          <Chip className="h-8 text-xs" active={free} onClick={() => setFree(!free)}>Free only</Chip></div>
      </div>
      <div className="mt-5">
        {list.length === 0 ? <Empty title="Nothing matches" /> : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((l) => { const I = ICON[l.kind]; return (
              <Link key={l.id} href={`/services/education/library/item?id=${l.id}`} className="card flex gap-3 p-3 hover:shadow-[var(--shadow-lift)]">
                <Thumb hue={l.hue} icon={I} size={70} />
                <div className="min-w-0 flex-1"><p className="line-clamp-2 text-sm font-semibold">{l.title}</p><p className="text-xs text-muted">{l.kind} · {l.subject} · {l.lang}</p>
                  <div className="mt-1.5">{l.free ? <Badge tone="success">Free</Badge> : <Badge tone="gold">{inr(l.price!)}</Badge>}</div></div>
              </Link>
            ); })}
          </div>
        )}
      </div>
    </div>
  );
}
