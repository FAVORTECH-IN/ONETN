"use client";
import Link from "next/link";
import { BookOpen, Brain, ClipboardCheck, HandHeart, Stethoscope, Bookmark, TrendingUp } from "lucide-react";
import { useApp } from "@/lib/store";
import { LIBRARY } from "@/data/learning";
import { Card, Notice, PageHeader, SectionHeader, Thumb, Badge } from "@/components/ui";

const tiles = [
  { i: BookOpen, t: "Learning Library", d: "Textbooks, references, notes, papers, videos", h: "/services/education/library", c: "bg-[#E6EEF8] text-[#1D4E89]" },
  { i: Brain, t: "AI Study Guide", d: "Explain, practise, plan – Tamil or English", h: "/services/education/ai-guide", c: "bg-[#EFE6F6] text-[#5B3A86]" },
  { i: ClipboardCheck, t: "Mock Tests", d: "Timed tests with topic analysis", h: "/services/education/mock-tests", c: "bg-warning-soft text-[#B5700D]" },
  { i: HandHeart, t: "Teachers & Counsellors", d: "Tuition, career & wellbeing sessions", h: "/services/education/counselling", c: "bg-success-soft text-success" },
  { i: Stethoscope, t: "Doctor Appointments", d: "In-person or video", h: "/services/healthcare", c: "bg-primary-soft text-primary" },
];
export default function Edu() {
  const { s } = useApp();
  const saved = LIBRARY.filter((l) => s.library.includes(l.id));
  const inProg = LIBRARY.filter((l) => (s.progress[l.id] ?? 0) > 0);
  return (
    <div className="space-y-6">
      <PageHeader title="Education & Counselling" sub="Every student, every district – the same resources" />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {tiles.map((x) => <Link key={x.t} href={x.h} className="card p-4 hover:shadow-[var(--shadow-lift)]"><span className={`grid h-12 w-12 place-items-center rounded-2xl ${x.c}`}><x.i /></span><p className="mt-3 font-bold">{x.t}</p><p className="text-xs text-muted">{x.d}</p></Link>)}
      </div>
      {inProg.length > 0 && <section><SectionHeader title="Continue learning" /><div className="grid gap-3 sm:grid-cols-2">{inProg.map((l) => <Link key={l.id} href={`/services/education/library/item?id=${l.id}`} className="card flex items-center gap-3 p-3"><Thumb hue={l.hue} icon={TrendingUp} size={52} /><div className="flex-1"><p className="text-sm font-semibold">{l.title}</p><div className="mt-1 h-2 rounded-full bg-line"><div className="h-2 rounded-full bg-success" style={{ width: `${s.progress[l.id]}%` }} /></div></div><span className="text-sm font-bold">{s.progress[l.id]}%</span></Link>)}</div></section>}
      <section><SectionHeader title="Saved library" href="/services/education/library" />{saved.length ? <div className="grid gap-3 sm:grid-cols-3">{saved.map((l) => <Link key={l.id} href={`/services/education/library/item?id=${l.id}`} className="card flex items-center gap-3 p-3"><Bookmark className="text-primary" size={18} /><span className="text-sm font-semibold">{l.title}</span></Link>)}</div> : <Card className="text-sm text-muted">Save books, notes and videos to read offline later.</Card>}</section>
      <section><SectionHeader title="Free government content" href="/services/education/library" />
        <div className="grid gap-3 sm:grid-cols-3">{LIBRARY.filter((l) => l.free).slice(0, 6).map((l) => <Link key={l.id} href={`/services/education/library/item?id=${l.id}`} className="card flex items-center gap-3 p-3"><Thumb hue={l.hue} icon={BookOpen} size={52} /><div className="min-w-0"><p className="truncate text-sm font-semibold">{l.title}</p><p className="text-xs text-muted">{l.kind} · {l.lang}</p><Badge tone="success">Free</Badge></div></Link>)}</div></section>
      <Notice tone="info">All content is added with the owner&apos;s permission – government content free, publisher content under licence. Works on low data with offline saving.</Notice>
    </div>
  );
}
