"use client";
import Link from "next/link";
import { ClipboardCheck, Clock, History } from "lucide-react";
import { useApp } from "@/lib/store";
import { EXAMS } from "@/data/learning";
import { Badge, Button, Card, PageHeader, SectionHeader } from "@/components/ui";
import { fmtDate } from "@/lib/utils";

export default function Mocks() {
  const { s } = useApp();
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <PageHeader title="Mock Tests" sub="Real exam patterns · instant results with explanations" />
      <div className="grid gap-3 sm:grid-cols-3">
        {Object.entries(EXAMS).map(([k, e]) => (
          <Card key={k} className="flex flex-col">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-warning-soft text-[#B5700D]"><ClipboardCheck /></span>
            <p className="mt-3 font-bold">{e.name}</p><p className="text-xs text-muted">{e.desc}</p>
            <p className="mt-1 flex items-center gap-1 text-xs"><Clock size={12} />{e.mins} min</p>
            <Badge tone="success" className="mt-2 self-start">Free</Badge>
            <Button className="mt-4" href={`/services/education/mock-tests/test?exam=${k}`}>Start test</Button>
          </Card>
        ))}
      </div>
      <section>
        <SectionHeader title="Performance history" />
        {s.tests.length === 0 ? <Card className="text-sm text-muted">No attempts yet. Your scores and weak topics will appear here.</Card> : (
          <Card className="divide-y divide-line p-0">
            {s.tests.map((t) => (
              <div key={t.id} className="flex items-center gap-3 px-4 py-3"><History size={18} className="text-primary" /><div className="flex-1"><p className="text-sm font-semibold">{EXAMS[t.exam]?.name}</p><p className="text-xs text-muted">{fmtDate(t.at, true)}</p></div><Badge tone={t.score / t.total >= 0.6 ? "success" : "warning"}>{t.score}/{t.total}</Badge></div>
            ))}
          </Card>
        )}
      </section>
      <p className="text-center text-sm text-muted">Need help with weak topics? <Link href="/services/education/counselling" className="font-semibold text-primary">Book a teacher</Link></p>
    </div>
  );
}
