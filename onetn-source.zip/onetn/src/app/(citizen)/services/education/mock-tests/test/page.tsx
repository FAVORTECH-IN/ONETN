"use client";
import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Clock, Flag, CheckCircle2, XCircle, TrendingUp, TrendingDown } from "lucide-react";
import { useApp } from "@/lib/store";
import { EXAMS } from "@/data/learning";
import { Badge, Button, Card, Empty, Notice, PageHeader, Sheet } from "@/components/ui";
import { cn, uid } from "@/lib/utils";

function Inner() {
  const key = useSearchParams().get("exam") ?? "neet";
  const e = EXAMS[key];
  const { set } = useApp();
  const [phase, setPhase] = useState<"intro" | "test" | "result">("intro");
  const [i, setI] = useState(0);
  const [ans, setAns] = useState<Record<number, number>>({});
  const [mark, setMark] = useState<number[]>([]);
  const [left, setLeft] = useState(e ? e.mins * 60 : 0);
  const [confirm, setConfirm] = useState(false);
  useEffect(() => {
    if (phase !== "test") return;
    if (left <= 0) { finish(); return; }
    const t = setTimeout(() => setLeft(left - 1), 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, left]);
  const res = useMemo(() => {
    if (!e) return null;
    const topics: Record<string, { c: number; t: number }> = {};
    let score = 0;
    e.qs.forEach((q, k) => { topics[q.topic] ??= { c: 0, t: 0 }; topics[q.topic].t++; if (ans[k] === q.a) { score++; topics[q.topic].c++; } });
    return { score, topics };
  }, [ans, e]);
  if (!e) return <Empty title="Test not found" />;
  function finish() {
    setPhase("result"); setConfirm(false);
    set((p) => ({ ...p, tests: [{ id: uid("T"), exam: key, score: res!.score, total: e.qs.length, at: new Date().toISOString(), topics: res!.topics }, ...p.tests] }));
  }
  if (phase === "intro") return (
    <div className="mx-auto max-w-2xl space-y-4">
      <PageHeader title={e.name} sub={e.desc} />
      <Card><p className="font-bold">Instructions</p><ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted"><li>{e.qs.length} questions · {e.mins} minutes</li><li>The test submits automatically when time runs out.</li><li>Use “Mark for review” to revisit questions.</li><li>You can move between questions freely.</li><li>Results show correct answers, explanations and topic analysis.</li></ul></Card>
      <Button full size="lg" onClick={() => setPhase("test")}>I&apos;m ready – start</Button>
    </div>
  );
  if (phase === "result" && res) {
    const pct = Math.round((res.score / e.qs.length) * 100);
    const tops = Object.entries(res.topics).map(([t, v]) => ({ t, p: v.c / v.t }));
    return (
      <div className="mx-auto max-w-3xl space-y-4">
        <PageHeader title="Your result" sub={e.name} backHref="/services/education/mock-tests" />
        <Card className="flex items-center gap-5"><div className="grid h-24 w-24 place-items-center rounded-full border-8 border-success/30 text-2xl font-extrabold">{pct}%</div><div><p className="text-2xl font-bold">{res.score} / {e.qs.length}</p><p className="text-muted">{pct >= 70 ? "Excellent work!" : pct >= 40 ? "Good effort – focus on weak topics." : "Keep practising – you'll get there."}</p></div></Card>
        <div className="grid gap-3 sm:grid-cols-2">
          <Card><p className="mb-2 flex items-center gap-2 font-bold text-success"><TrendingUp size={18} />Strong areas</p>{tops.filter((x) => x.p >= 0.6).map((x) => <Badge key={x.t} tone="success" className="mb-1 mr-1">{x.t}</Badge>)}{!tops.some((x) => x.p >= 0.6) && <p className="text-sm text-muted">—</p>}</Card>
          <Card><p className="mb-2 flex items-center gap-2 font-bold text-error"><TrendingDown size={18} />Weak areas</p>{tops.filter((x) => x.p < 0.6).map((x) => <Badge key={x.t} tone="error" className="mb-1 mr-1">{x.t}</Badge>)}{!tops.some((x) => x.p < 0.6) && <p className="text-sm text-muted">None 🎉</p>}</Card>
        </div>
        <Card><p className="mb-3 font-bold">Topic analysis</p>{tops.map((x) => <div key={x.t} className="mb-2"><div className="flex justify-between text-sm"><span>{x.t}</span><span>{Math.round(x.p * 100)}%</span></div><div className="h-2 rounded-full bg-line"><div className={cn("h-2 rounded-full", x.p >= 0.6 ? "bg-success" : "bg-warning")} style={{ width: `${x.p * 100}%` }} /></div></div>)}</Card>
        <Card className="space-y-4"><p className="font-bold">Answers & explanations</p>
          {e.qs.map((q, k) => (
            <div key={k} className="border-b border-line pb-3 last:border-0">
              <p className="text-sm font-semibold">{k + 1}. {q.q}</p>
              <p className={cn("mt-1 flex items-center gap-1 text-sm", ans[k] === q.a ? "text-success" : "text-error")}>{ans[k] === q.a ? <CheckCircle2 size={15} /> : <XCircle size={15} />}Your answer: {ans[k] !== undefined ? q.opts[ans[k]] : "Not answered"}</p>
              {ans[k] !== q.a && <p className="text-sm text-success">Correct: {q.opts[q.a]}</p>}
              <p className="mt-1 text-xs text-muted">{q.exp}</p>
            </div>
          ))}
        </Card>
        <div className="flex gap-2"><Button variant="outline" full href="/services/education/ai-guide">Ask AI guide about weak topics</Button><Button full onClick={() => { setAns({}); setMark([]); setI(0); setLeft(e.mins * 60); setPhase("intro"); }}>Retake</Button></div>
      </div>
    );
  }
  const q = e.qs[i];
  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="font-bold">{e.name}</p>
        <span className={cn("flex items-center gap-1 rounded-full px-3 py-1.5 text-sm font-bold", left < 60 ? "bg-error-soft text-error" : "bg-white border border-line")}><Clock size={15} />{Math.floor(left / 60)}:{String(left % 60).padStart(2, "0")}</span>
      </div>
      <div className="grid gap-4 lg:grid-cols-[1fr_220px]">
        <Card>
          <p className="text-sm text-muted">Question {i + 1} of {e.qs.length} · {q.topic}</p>
          <p className="mt-2 text-lg font-semibold">{q.q}</p>
          <div className="mt-4 space-y-2">
            {q.opts.map((o, k) => <button key={k} onClick={() => setAns({ ...ans, [i]: k })} className={cn("flex w-full items-center gap-3 rounded-2xl border p-3 text-left", ans[i] === k ? "border-primary bg-primary-soft" : "border-line bg-white")}><span className={cn("grid h-7 w-7 place-items-center rounded-full border text-sm font-bold", ans[i] === k ? "border-primary bg-primary text-white" : "border-line")}>{String.fromCharCode(65 + k)}</span>{o}</button>)}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button variant="outline" disabled={i === 0} onClick={() => setI(i - 1)}>Previous</Button>
            <Button variant="ghost" onClick={() => setMark(mark.includes(i) ? mark.filter((x) => x !== i) : [...mark, i])}><Flag size={16} />{mark.includes(i) ? "Unmark" : "Mark for review"}</Button>
            {ans[i] !== undefined && <Button variant="ghost" onClick={() => { const a = { ...ans }; delete a[i]; setAns(a); }}>Clear</Button>}
            <span className="flex-1" />
            {i < e.qs.length - 1 ? <Button onClick={() => setI(i + 1)}>Save & next</Button> : <Button variant="success" onClick={() => setConfirm(true)}>Submit test</Button>}
          </div>
        </Card>
        <Card>
          <p className="mb-2 text-sm font-bold">Questions</p>
          <div className="grid grid-cols-5 gap-2">{e.qs.map((_, k) => <button key={k} onClick={() => setI(k)} className={cn("h-9 rounded-lg text-sm font-bold", k === i && "ring-2 ring-ink", mark.includes(k) ? "bg-warning text-white" : ans[k] !== undefined ? "bg-success text-white" : "bg-cream")}>{k + 1}</button>)}</div>
          <div className="mt-3 space-y-1 text-xs text-muted"><p><i className="mr-1 inline-block h-2.5 w-2.5 rounded bg-success" />Answered ({Object.keys(ans).length})</p><p><i className="mr-1 inline-block h-2.5 w-2.5 rounded bg-warning" />Marked ({mark.length})</p></div>
          <Button size="sm" full variant="success" className="mt-3" onClick={() => setConfirm(true)}>Submit</Button>
        </Card>
      </div>
      <Sheet open={confirm} onClose={() => setConfirm(false)} title="Submit test?" footer={<div className="flex gap-2"><Button variant="outline" full onClick={() => setConfirm(false)}>Keep going</Button><Button full onClick={finish}>Submit</Button></div>}>
        <p>You answered {Object.keys(ans).length} of {e.qs.length}. {mark.length > 0 && `${mark.length} marked for review.`}</p>
        {Object.keys(ans).length < e.qs.length && <Notice tone="warning" className="mt-3">Unanswered questions score zero.</Notice>}
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
