"use client";
import { useState } from "react";
import { ShieldCheck, Languages, MapPin } from "lucide-react";
import { MENTORS } from "@/data/learning";
import { useApp } from "@/lib/store";
import { Avatar, Badge, Button, Card, Chip, PageHeader, Rating, SectionHeader } from "@/components/ui";
import { AppointmentSheet } from "@/components/flows/Appointment";
import { BookingRow } from "@/components/flows/BookingList";
import { inr } from "@/lib/utils";

export default function Counselling() {
  const { s } = useApp();
  const [role, setRole] = useState("All");
  const [sel, setSel] = useState<(typeof MENTORS)[number] | null>(null);
  const list = MENTORS.filter((m) => role === "All" || m.role === role);
  const hist = s.bookings.filter((b) => b.module === "counselling");
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <PageHeader title="Teachers & Counsellors" sub="Doubt-clearing, tuition, career and wellbeing sessions" />
      <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", "Teacher", "Mentor", "Career counsellor", "Mental-wellbeing counsellor"].map((r) => <Chip key={r} active={role === r} onClick={() => setRole(r)}>{r}</Chip>)}</div>
      <div className="grid gap-3 md:grid-cols-2">
        {list.map((m) => (
          <Card key={m.id}>
            <div className="flex gap-3">
              <Avatar name={m.name.replace(/^(Dr\.|Prof\.) /, "")} size={56} tone="gold" />
              <div className="min-w-0 flex-1"><p className="font-bold">{m.name} <ShieldCheck size={14} className="inline text-success" /></p><p className="text-sm text-muted">{m.role} · {m.subject}</p>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs"><Rating value={m.rating} /><span>{m.exp} yrs</span><span className="flex items-center gap-1"><Languages size={12} />{m.lang}</span><span className="flex items-center gap-1"><MapPin size={12} />{m.place}</span></div>
                {"reg" in m && m.reg && <p className="mt-1 text-xs text-muted">{m.reg}</p>}
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between"><div className="flex gap-1">{m.mode.map((x) => <Badge key={x}>{x}</Badge>)}</div><span className="font-bold">{inr(m.fee)}<span className="text-xs font-normal text-muted">/session</span></span></div>
            <Button full className="mt-3" onClick={() => setSel(m)}>View slots & book</Button>
          </Card>
        ))}
      </div>
      {hist.length > 0 && <section><SectionHeader title="Appointment history" />{hist.map((b) => <BookingRow key={b.id} b={b} />)}</section>}
      {sel && <AppointmentSheet open onClose={() => setSel(null)} who={sel.name} role={sel.role} fee={sel.fee} modes={sel.mode} module="counselling" place={sel.place} privateNote={sel.role.includes("wellbeing")} />}
    </div>
  );
}
