"use client";
import { BellPlus } from "lucide-react";
import { useApp } from "@/lib/store";
import { EXAM_CALENDAR } from "@/data/jobsfood";
import { Button, Card, Notice, PageHeader } from "@/components/ui";

export default function Cal() {
  const { toast } = useApp();
  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title="Exam calendar" sub="Notification, application, exam and result dates" />
      <div className="card overflow-x-auto p-0">
        <table className="w-full min-w-[600px] text-sm">
          <thead className="bg-cream text-left text-muted"><tr>{["Exam", "Notification", "Last date to apply", "Exam", "Result", ""].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-line">{EXAM_CALENDAR.map((e) => <tr key={e.exam}><td className="px-4 py-3 font-semibold">{e.exam}</td><td className="px-4 py-3">{e.notif}</td><td className="px-4 py-3">{e.apply}</td><td className="px-4 py-3">{e.exam_}</td><td className="px-4 py-3">{e.result}</td><td className="px-4 py-3"><Button size="sm" variant="ghost" onClick={() => toast(`Reminder set for ${e.exam}`)}><BellPlus size={15} />Remind</Button></td></tr>)}</tbody>
        </table>
      </div>
      <Card><Notice tone="info">Dates are demo values. In production they come from recruitment bodies&apos; official notifications.</Notice></Card>
    </div>
  );
}
