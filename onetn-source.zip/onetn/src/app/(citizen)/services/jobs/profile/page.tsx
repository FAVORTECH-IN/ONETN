"use client";
import { useState } from "react";
import { Download, Save } from "lucide-react";
import { useApp } from "@/lib/store";
import { Button, Card, Field, Input, PageHeader, Textarea, Notice } from "@/components/ui";
import { downloadText } from "@/lib/utils";

const FIELDS = [["headline", "Headline", "e.g. B.Com graduate · Tally & GST"], ["skills", "Skills (comma separated)", "Tally, GST, Excel, Tamil typing"], ["experience", "Experience", "Company, role, years"], ["education", "Education", "Degree, institution, year"], ["certs", "Certifications", "Course, issuer"], ["langs", "Languages", "Tamil, English"], ["prefs", "Job preferences", "Location, salary, type"]] as const;
export default function Profile() {
  const { s, set, toast } = useApp();
  const [r, setR] = useState<Record<string, string>>(s.resume ?? {});
  const text = () => [`${s.user?.name}`, `${s.user?.mobile} · ${s.user?.email ?? ""} · ${s.user?.city ?? ""}, ${s.user?.district ?? ""}`, "", ...FIELDS.map(([k, l]) => `${l.toUpperCase()}\n${r[k] ?? "—"}\n`)].join("\n");
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="Candidate profile & resume" sub="Build once, apply with one tap" />
      <Card className="grid gap-3">
        {FIELDS.map(([k, l, ph]) => (
          <Field key={k} label={l}>{k === "experience" || k === "education" ? <Textarea value={r[k] ?? ""} placeholder={ph} onChange={(e) => setR({ ...r, [k]: e.target.value })} className="min-h-16" /> : <Input value={r[k] ?? ""} placeholder={ph} onChange={(e) => setR({ ...r, [k]: e.target.value })} />}</Field>
        ))}
      </Card>
      <Notice tone="info">Certificates earned in ONETN courses can be added here. Employers see your resume only when you apply or allow it.</Notice>
      <div className="flex gap-2"><Button full onClick={() => { if (!r.skills || !r.education) return toast("Add at least skills and education", "error"); set((p) => ({ ...p, resume: r })); toast("Profile saved"); }}><Save size={17} />Save profile</Button><Button variant="outline" onClick={() => downloadText("resume.txt", text())}><Download size={17} />Download</Button></div>
      <Card><p className="mb-2 font-bold">Preview</p><pre className="whitespace-pre-wrap text-sm">{text()}</pre></Card>
    </div>
  );
}
