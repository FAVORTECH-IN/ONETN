"use client";
import Link from "next/link";
import { useState } from "react";
import { useApp } from "@/lib/store";
import { JOBS } from "@/data/jobsfood";
import { Badge, Card, Empty, PageHeader, Tabs, statusTone, Button } from "@/components/ui";
import { fmtDate } from "@/lib/utils";

export default function Apps() {
  const { s, set, toast } = useApp();
  const [tab, setTab] = useState<"apps" | "saved">("apps");
  const STEPS = ["Application received", "Viewed by employer", "Shortlisted", "Interview scheduled", "Offer"];
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Applications & saved jobs" />
      <Tabs className="mb-4" value={tab} onChange={setTab} tabs={[{ value: "apps", label: "Applications", count: s.jobApps.length }, { value: "saved", label: "Saved", count: s.savedJobs.length }]} />
      {tab === "apps" ? (s.jobApps.length === 0 ? <Empty title="No applications yet" action={<Button href="/services/jobs">Find jobs</Button>} /> : (
        <div className="space-y-3">{s.jobApps.map((a) => { const j = JOBS.find((x) => x.id === a.jobId)!; const i = STEPS.indexOf(a.status); return (
          <Card key={a.jobId}>
            <div className="flex items-start justify-between gap-3"><Link href={`/services/jobs/job?id=${j.id}`}><p className="font-semibold">{j.title}</p><p className="text-sm text-muted">{j.org} · applied {fmtDate(a.at)}</p></Link><Badge tone={statusTone(a.status)}>{a.status}</Badge></div>
            {i >= 0 && <div className="mt-3 flex gap-1">{STEPS.map((x, k) => <div key={x} title={x} className={`h-1.5 flex-1 rounded-full ${k <= i ? "bg-success" : "bg-line"}`} />)}</div>}
            {i >= 0 && i < STEPS.length - 1 && <button className="mt-2 text-xs font-semibold text-primary" onClick={() => { set((p) => ({ ...p, jobApps: p.jobApps.map((x) => (x.jobId === a.jobId ? { ...x, status: STEPS[i + 1] } : x)) })); toast("Status updated (simulated)", "info"); }}>Simulate employer update</button>}
          </Card>
        ); })}</div>
      )) : (s.savedJobs.length === 0 ? <Empty title="No saved jobs" /> : <div className="space-y-2">{s.savedJobs.map((id) => { const j = JOBS.find((x) => x.id === id)!; return <Link key={id} href={`/services/jobs/job?id=${id}`} className="card block p-4"><p className="font-semibold">{j.title}</p><p className="text-sm text-muted">{j.org}</p></Link>; })}</div>)}
    </div>
  );
}
