"use client";
import Link from "next/link";
import { useState } from "react";
import { Search, Briefcase, Bookmark, BookmarkCheck, BellRing, CalendarDays, UserRound, ClipboardList, BadgeCheck, SlidersHorizontal } from "lucide-react";
import { useApp } from "@/lib/store";
import { JOBS } from "@/data/jobsfood";
import { Badge, Button, Card, Chip, Empty, Field, Notice, PageHeader, Select, Sheet, Tabs, Input } from "@/components/ui";
import { inr } from "@/lib/utils";

export default function Jobs() {
  const { s, set, toast } = useApp();
  const [tab, setTab] = useState<"All" | "Government" | "Private" | "Local" | "Short-term">("All");
  const [q, setQ] = useState("");
  const [f, setF] = useState({ loc: "", min: "", edu: "", exp: "" });
  const [open, setOpen] = useState(false);
  const [alert, setAlert] = useState(false);
  const list = JOBS.filter((j) => (tab === "All" || j.sector === tab) && (!q || (j.title + j.org + j.skills.join(" ") + j.category).toLowerCase().includes(q.toLowerCase())) &&
    (!f.loc || j.district === f.loc || j.district === "All") && (!f.min || j.salary[1] >= Number(f.min)) && (!f.edu || j.edu.toLowerCase().includes(f.edu.toLowerCase())) && (f.exp === "" || j.exp <= Number(f.exp)));
  const saved = (id: string) => s.savedJobs.includes(id);
  return (
    <div className="space-y-4">
      <PageHeader title="Jobs" sub="Government & private jobs in one place · always free for job seekers" />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[{ i: UserRound, t: "My profile & resume", h: "/services/jobs/profile" }, { i: ClipboardList, t: "Applications & saved", h: "/services/jobs/applications" }, { i: CalendarDays, t: "Exam calendar", h: "/services/jobs/calendar" }].map((x) => <Link key={x.t} href={x.h} className="card flex items-center gap-2 p-3 text-sm font-semibold"><x.i size={18} className="text-primary" />{x.t}</Link>)}
        <button onClick={() => setAlert(true)} className="card flex items-center gap-2 p-3 text-left text-sm font-semibold"><BellRing size={18} className="text-primary" />Job alerts</button>
      </div>
      <div className="flex gap-2"><div className="relative flex-1"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Job title, skill or company" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div><Button variant="outline" onClick={() => setOpen(true)} aria-label="Filters"><SlidersHorizontal size={18} /></Button></div>
      <Tabs value={tab} onChange={setTab} tabs={(["All", "Government", "Private", "Local", "Short-term"] as const).map((x) => ({ value: x, label: x, count: JOBS.filter((j) => x === "All" || j.sector === x).length }))} />
      {list.length === 0 ? <Empty title="No jobs match" body="Clear filters or set an alert." /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((j) => (
            <Card key={j.id} className="relative">
              <button aria-label="Save job" onClick={() => { set((p) => ({ ...p, savedJobs: saved(j.id) ? p.savedJobs.filter((x) => x !== j.id) : [...p.savedJobs, j.id] })); toast(saved(j.id) ? "Removed" : "Job saved"); }} className="absolute right-3 top-3">{saved(j.id) ? <BookmarkCheck className="text-primary" size={20} /> : <Bookmark size={20} className="text-muted" />}</button>
              <Link href={`/services/jobs/job?id=${j.id}`} className="block pr-6">
                <div className="flex gap-3"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00]"><Briefcase size={20} /></span>
                  <div className="min-w-0"><p className="font-semibold leading-snug">{j.title}</p><p className="text-sm text-muted">{j.org} {j.verified && <BadgeCheck size={14} className="inline text-success" />}</p></div></div>
                <div className="mt-3 flex flex-wrap gap-1.5"><Badge tone={j.sector === "Government" ? "primary" : "info"}>{j.sector}</Badge><Badge>{j.location}</Badge><Badge>{j.edu}</Badge><Badge>{j.exp ? `${j.exp}+ yrs` : "Freshers"}</Badge></div>
                <div className="mt-2 flex items-center justify-between text-sm"><b>{inr(j.salary[0])} – {inr(j.salary[1])}{j.type.includes("Daily") ? "/day" : "/mo"}</b><span className="text-xs text-muted">{j.posted}{j.lastDate && ` · last date ${new Date(j.lastDate).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}`}</span></div>
              </Link>
            </Card>
          ))}
        </div>
      )}
      <Notice tone="warning">ONETN never charges job seekers. If anyone asks you to pay for a job, report it via Grievance – fake offers are removed quickly.</Notice>
      <Sheet open={open} onClose={() => setOpen(false)} title="Filters" footer={<div className="flex gap-2"><Button variant="outline" full onClick={() => setF({ loc: "", min: "", edu: "", exp: "" })}>Clear</Button><Button full onClick={() => setOpen(false)}>Show {list.length} jobs</Button></div>}>
        <div className="space-y-3">
          <Field label="Location"><Select value={f.loc} onChange={(e) => setF({ ...f, loc: e.target.value })} placeholder="Anywhere" options={["Chennai", "Coimbatore", "Madurai", "Tiruppur"]} /></Field>
          <Field label="Minimum monthly salary (₹)"><Select value={f.min} onChange={(e) => setF({ ...f, min: e.target.value })} placeholder="Any" options={["10000", "15000", "20000", "30000"]} /></Field>
          <Field label="Education"><Select value={f.edu} onChange={(e) => setF({ ...f, edu: e.target.value })} placeholder="Any" options={["10th", "12th", "ITI", "B.Com", "degree", "B.Ed"]} /></Field>
          <Field label="Max experience required (years)"><Select value={f.exp} onChange={(e) => setF({ ...f, exp: e.target.value })} placeholder="Any" options={["0", "1", "2", "5"]} /></Field>
          <div className="flex flex-wrap gap-2">{["Healthcare", "Education", "Retail", "Trades", "Accounts"].map((c) => <Chip key={c} onClick={() => { setQ(c); setOpen(false); }}>{c}</Chip>)}</div>
        </div>
      </Sheet>
      <Sheet open={alert} onClose={() => setAlert(false)} title="Create job alert" footer={<Button full onClick={() => { setAlert(false); toast("Alert created – we'll notify you of matching jobs"); }}>Create alert</Button>}>
        <div className="space-y-3"><Field label="Skill / keyword"><Input defaultValue={q} placeholder="e.g. accountant, nurse" /></Field><Field label="Place"><Select options={["Anywhere in Tamil Nadu", "Chennai", "Coimbatore", "Madurai"]} /></Field><Field label="Minimum pay (₹/month)"><Input type="number" placeholder="15000" /></Field></div>
      </Sheet>
    </div>
  );
}
