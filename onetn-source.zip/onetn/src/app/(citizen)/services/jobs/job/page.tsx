"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { BadgeCheck, Briefcase, MapPin, GraduationCap, Clock, ExternalLink, CheckCircle2, XCircle, Building2, Upload } from "lucide-react";
import { useApp } from "@/lib/store";
import { JOBS } from "@/data/jobsfood";
import { LIBRARY } from "@/data/learning";
import { Badge, Button, Card, Empty, Field, Input, KV, Notice, PageHeader, Select, Sheet } from "@/components/ui";
import { inr } from "@/lib/utils";
import Link from "next/link";

function Inner() {
  const j = JOBS.find((x) => x.id === useSearchParams().get("id"));
  const { s, set, toast, notify } = useApp();
  const [elig, setElig] = useState({ age: "", edu: "" });
  const [res, setRes] = useState<null | boolean>(null);
  const [apply, setApply] = useState(false);
  const [resume, setResume] = useState<string>(s.resume ? "ONETN profile resume" : "");
  if (!j) return <Empty title="Job not found" />;
  const applied = s.jobApps.find((a) => a.jobId === j.id);
  const check = () => setRes(!!elig.age && Number(elig.age) >= 18 && Number(elig.age) <= 37 && elig.edu !== "Below 10th");
  const course = LIBRARY.find((l) => l.stage === "Skills & careers");
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={j.title} sub={j.org} />
      <Card>
        <div className="flex gap-3"><span className="grid h-14 w-14 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00]"><Briefcase /></span><div><p className="font-bold">{j.org}</p>{j.verified ? <Badge tone="success"><BadgeCheck size={12} />Verified employer</Badge> : <Badge tone="warning">Verification pending</Badge>}</div></div>
        <div className="mt-4"><KV rows={[[<span key="1" className="flex items-center gap-1"><MapPin size={14} />Location</span>, j.location], ["Salary", `${inr(j.salary[0])} – ${inr(j.salary[1])}${j.type.includes("Daily") ? " per day" : " per month"}`], [<span key="2" className="flex items-center gap-1"><GraduationCap size={14} />Education</span>, j.edu], ["Experience", j.exp ? `${j.exp}+ years` : "Freshers welcome"], ["Job type", j.type], [<span key="3" className="flex items-center gap-1"><Clock size={14} />Posted</span>, j.posted], ...(j.lastDate ? [["Last date", new Date(j.lastDate).toDateString()] as [string, string]] : [])]} /></div>
      </Card>
      <Card><p className="font-bold">Job description</p><p className="mt-1 text-sm text-muted">{j.desc}</p><p className="mt-3 text-sm font-semibold">Skills</p><div className="mt-1 flex flex-wrap gap-1.5">{j.skills.map((x) => <Badge key={x}>{x}</Badge>)}</div></Card>
      <Card><p className="flex items-center gap-2 font-bold"><Building2 size={17} />About the employer</p><p className="mt-1 text-sm text-muted">{j.sector === "Government" ? "Official recruitment body. Applications are made on the official website; ONETN lists the notification and sends reminders." : `${j.org} is a registered business verified by ONETN before posting. Pay, location and duties are stated as per posting rules.`}</p></Card>
      <Card className="space-y-3">
        <p className="font-bold">Eligibility checker</p>
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Your age"><Input type="number" value={elig.age} onChange={(e) => setElig({ ...elig, age: e.target.value })} /></Field><Field label="Highest education"><Select placeholder="Select" value={elig.edu} onChange={(e) => setElig({ ...elig, edu: e.target.value })} options={["Below 10th", "10th pass", "12th pass", "ITI / Diploma", "Graduate", "Post-graduate"]} /></Field></div>
        <Button variant="outline" onClick={check} disabled={!elig.age || !elig.edu}>Check eligibility</Button>
        {res !== null && (res ? <p className="flex items-center gap-2 text-sm text-success"><CheckCircle2 size={17} />You appear eligible (indicative – the official notification decides).</p> : <p className="flex items-center gap-2 text-sm text-error"><XCircle size={17} />You may not meet the criteria. See matching courses below.</p>)}
      </Card>
      {course && <Card className="flex items-center gap-3"><GraduationCap className="text-primary" /><p className="flex-1 text-sm">Improve your chances: <b>{course.title}</b></p><Link className="text-sm font-semibold text-primary" href={`/services/education/library/item?id=${course.id}`}>View</Link></Card>}
      {j.sector === "Government" ? (
        <>
          <Button full size="lg" onClick={() => { set((p) => ({ ...p, jobApps: [...p.jobApps.filter((a) => a.jobId !== j.id), { jobId: j.id, at: new Date().toISOString(), status: "Applied on official site" }] })); toast(`Would open ${j.official} – reminder set`, "info"); }}><ExternalLink size={18} />Apply on official site ({j.official})</Button>
          <p className="text-center text-xs text-muted">Government jobs are always free to view and apply.</p>
        </>
      ) : applied ? <Notice tone="success" title="Application sent">Status: {applied.status}. Track in Applications.</Notice> : <Button full size="lg" onClick={() => setApply(true)}>Apply – free</Button>}
      <Sheet open={apply} onClose={() => setApply(false)} title="Apply" footer={<Button full disabled={!resume} onClick={() => {
        set((p) => ({ ...p, jobApps: [...p.jobApps, { jobId: j.id, at: new Date().toISOString(), status: "Application received" }] }));
        notify("Application sent", `${j.title} · ${j.org}`, "/services/jobs/applications"); toast("Applied successfully"); setApply(false);
      }}>Submit application</Button>}>
        <div className="space-y-3">
          <KV rows={[["Name", s.user?.name], ["Mobile", s.user?.mobile], ["Email", s.user?.email || "—"]]} />
          <Field label="Resume"><Select value={resume} onChange={(e) => setResume(e.target.value)} placeholder="Choose resume" options={[...(s.resume ? ["ONETN profile resume"] : []), ...(resume && resume !== "ONETN profile resume" ? [resume] : [])]} /></Field>
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-primary/40 py-3 text-sm font-semibold text-primary"><Upload size={16} />Upload resume (PDF)<input type="file" accept=".pdf,.doc,.docx" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setResume(f.name); }} /></label>
          {!s.resume && <Link href="/services/jobs/profile" className="block text-sm font-semibold text-primary">Or build one with the resume builder →</Link>}
          <Notice tone="info">Your resume is shared only with this employer. No fee is ever charged.</Notice>
        </div>
      </Sheet>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
