"use client";
import { useState } from "react";
import Link from "next/link";
import { Milk, CalendarDays, Snowflake } from "lucide-react";
import { useApp } from "@/lib/store";
import { MILK_PRODUCTS } from "@/data/delivery";
import { Badge, Card, Chip, Field, Input, Notice, PageHeader, Qty, Select, Thumb } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { BookingRow } from "@/components/flows/BookingList";
import { cn, inr } from "@/lib/utils";

export default function MilkSub() {
  const { s } = useApp();
  const [prod, setProd] = useState(MILK_PRODUCTS[0]);
  const [qty, setQty] = useState(2);
  const [freq, setFreq] = useState<"Daily" | "Alternate days">("Daily");
  const [dur, setDur] = useState(30);
  const [start, setStart] = useState(new Date(Date.now() + 864e5).toISOString().slice(0, 10));
  const [addr, setAddr] = useState(s.addresses[0]?.id ?? "");
  const deliveries = freq === "Daily" ? dur : Math.ceil(dur / 2);
  const subs = s.bookings.filter((b) => b.module === "milk");
  const fees = [{ label: `${prod.name} ${prod.unit} × ${qty} × ${deliveries} deliveries`, amount: prod.price * qty * deliveries, payee: "Cooperative milk union" }, { label: "Delivery fee", amount: Math.round(deliveries * 1), note: "₹1 per delivery (demo)" }];
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Milk Subscription" sub="Government cooperative milk · early-morning delivery" />
      {subs.length > 0 && <div className="mb-4 space-y-2"><p className="text-sm font-semibold">Your subscriptions</p>{subs.map((b) => <BookingRow key={b.id} b={b} />)}</div>}
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {MILK_PRODUCTS.map((m) => (
              <button key={m.id} onClick={() => setProd(m)} className={cn("card p-3 text-left", prod.id === m.id && "border-primary ring-4 ring-primary/10")}>
                <Thumb hue={m.hue} icon={Milk} className="h-20 w-full" /><p className="mt-2 text-sm font-semibold">{m.name}</p><p className="text-xs text-muted">{m.unit} · {inr(m.price)}</p>
              </button>
            ))}
          </div>
          <Card className="space-y-4">
            <div className="flex items-center justify-between"><span className="font-semibold">Packets per delivery</span><Qty value={qty} min={1} max={10} onChange={setQty} /></div>
            <div><p className="mb-2 text-sm font-semibold">Frequency</p><div className="flex gap-2">{(["Daily", "Alternate days"] as const).map((f) => <Chip key={f} active={freq === f} onClick={() => setFreq(f)}>{f}</Chip>)}</div></div>
            <div><p className="mb-2 text-sm font-semibold">Duration</p><div className="flex flex-wrap gap-2">{[7, 15, 30, 90].map((d) => <Chip key={d} active={dur === d} onClick={() => setDur(d)}>{d} days</Chip>)}</div></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Start date"><Input type="date" value={start} min={new Date(Date.now() + 864e5).toISOString().slice(0, 10)} onChange={(e) => setStart(e.target.value)} /></Field>
              <Field label="Delivery address"><Select value={addr} onChange={(e) => setAddr(e.target.value)} options={s.addresses.map((a) => ({ value: a.id, label: a.label }))} /></Field>
            </div>
          </Card>
        </div>
        <div className="space-y-4">
          <Card><p className="mb-2 font-bold">Plan</p>{fees.map((f) => <div key={f.label} className="flex justify-between gap-3 py-1 text-sm"><span className="text-muted">{f.label}</span><span>{inr(f.amount)}</span></div>)}</Card>
          <Notice tone="info"><Snowflake size={14} className="mr-1 inline" />Delivered 5–7 AM with cold-chain handling. Pause any time when you travel; auto-pay from Wallet with low-balance reminders.</Notice>
          <CheckoutButton label="Start subscription" category="Essentials"
            build={() => ({ module: "milk", kind: "subscription", title: "Milk subscription", subtitle: `${prod.name} × ${qty} · ${freq}`, status: "active", stageIdx: 1, stages: ["Subscribed", "Deliveries active", "Plan completed"], fees,
              details: { Product: `${prod.name} (${prod.unit})`, "Quantity / day": `${qty} packet(s)`, Frequency: freq, Starts: new Date(start).toDateString(), Duration: `${dur} days`, Address: s.addresses.find((a) => a.id === addr)?.line ?? "", Supplier: "District Cooperative Milk Producers' Union" } })} />
          <Link href="/bookings" className="flex items-center gap-1 text-sm font-semibold text-primary"><CalendarDays size={15} />Delivery history in Bookings</Link>
          <Badge tone="gold">Prices: demo values</Badge>
        </div>
      </div>
    </div>
  );
}
