import { RideBooking } from "@/components/flows/RideBooking";
export default function Page() { return <RideBooking mode="auto" />; }
