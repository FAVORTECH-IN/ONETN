"use client";
import { useState } from "react";
import { Package } from "lucide-react";
import { useApp } from "@/lib/store";
import { PARCEL_CATEGORIES, PARCEL_SIZES, PLACES, distanceKm } from "@/data/transport";
import { Card, Chip, Field, Input, Notice, PageHeader, Select, SimTag, Textarea } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { MapView } from "@/components/flows/MapView";
import { cn, inr, nextDays, dayLabel } from "@/lib/utils";

export default function Parcels() {
  const { s } = useApp();
  const [size, setSize] = useState(PARCEL_SIZES[0]);
  const [f, setF] = useState({ pickup: "T. Nagar", drop: "Adyar", pickAddr: s.addresses[0]?.line ?? "", dropAddr: "", recv: "", recvPhone: "", cat: "", weight: "", l: "", w: "", h: "", note: "" });
  const [when, setWhen] = useState("Now");
  const [day, setDay] = useState(0);
  const km = distanceKm(f.pickup, f.drop);
  const kg = Number(f.weight) || 0;
  const freight = Math.round(size.base + km * size.perKm + Math.max(0, kg - 2) * (size.id === "large" ? 4 : 6));
  const fees = [{ label: `${size.name} parcel – base`, amount: size.base }, { label: `Distance ${km} km × ₹${size.perKm}`, amount: Math.round(km * size.perKm) }, { label: "Weight surcharge", amount: freight - size.base - Math.round(km * size.perKm) }, { label: "Handling & booking fee", amount: 10 }];
  const set = (k: keyof typeof f, v: string) => setF({ ...f, [k]: v });
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Parcel Services" sub="Pickup & delivery with tracking and proof of delivery" right={<SimTag label="Demo rates" />} />
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <div className="grid gap-2 sm:grid-cols-3">
            {PARCEL_SIZES.map((p) => (
              <button key={p.id} onClick={() => setSize(p)} className={cn("card p-4 text-left", size.id === p.id && "border-primary ring-4 ring-primary/10")}>
                <Package className="text-primary" size={p.id === "small" ? 22 : p.id === "medium" ? 28 : 34} /><p className="mt-2 font-bold">{p.name}</p><p className="text-xs text-muted">{p.eg}</p><p className="mt-1 text-xs">Up to {p.maxKg} kg · {p.vehicle}</p>
              </button>
            ))}
          </div>
          <Card className="grid gap-3 sm:grid-cols-2">
            <Field label="Pickup area"><Select value={f.pickup} onChange={(e) => set("pickup", e.target.value)} options={PLACES.map((p) => p.name)} /></Field>
            <Field label="Destination area"><Select value={f.drop} onChange={(e) => set("drop", e.target.value)} options={PLACES.filter((p) => p.name !== f.pickup).map((p) => p.name)} /></Field>
            <Field label="Pickup address" required><Input value={f.pickAddr} onChange={(e) => set("pickAddr", e.target.value)} /></Field>
            <Field label="Delivery address" required><Input value={f.dropAddr} onChange={(e) => set("dropAddr", e.target.value)} /></Field>
            <Field label="Receiver name" required><Input value={f.recv} onChange={(e) => set("recv", e.target.value)} /></Field>
            <Field label="Receiver mobile" required><Input inputMode="numeric" maxLength={10} value={f.recvPhone} onChange={(e) => set("recvPhone", e.target.value)} /></Field>
            <Field label="Parcel category" required><Select placeholder="Select" value={f.cat} onChange={(e) => set("cat", e.target.value)} options={PARCEL_CATEGORIES} /></Field>
            <Field label={`Weight (kg, max ${size.maxKg})`} required><Input type="number" min={0.1} step={0.1} value={f.weight} onChange={(e) => set("weight", e.target.value)} /></Field>
            <Field label="Dimensions L × W × H (cm)"><div className="flex gap-2"><Input placeholder="L" value={f.l} onChange={(e) => set("l", e.target.value)} /><Input placeholder="W" value={f.w} onChange={(e) => set("w", e.target.value)} /><Input placeholder="H" value={f.h} onChange={(e) => set("h", e.target.value)} /></div></Field>
            <Field label="Notes for rider"><Textarea className="min-h-12" value={f.note} onChange={(e) => set("note", e.target.value)} /></Field>
          </Card>
          <Card>
            <p className="mb-2 text-sm font-semibold">Schedule</p>
            <div className="flex flex-wrap gap-2">{["Now", "Schedule"].map((x) => <Chip key={x} active={when === x} onClick={() => setWhen(x)}>{x}</Chip>)}{when === "Schedule" && nextDays(4).map((d, i) => <Chip key={i} active={day === i} onClick={() => setDay(i)}>{dayLabel(d)}</Chip>)}</div>
          </Card>
        </div>
        <div className="space-y-4">
          <MapView from={f.pickup} to={f.drop} className="h-52" />
          <Card><p className="mb-2 font-bold">Fare ({size.vehicle})</p>{fees.map((x) => <div key={x.label} className="flex justify-between py-1 text-sm"><span className="text-muted">{x.label}</span><span>{inr(x.amount)}</span></div>)}<div className="mt-2 flex justify-between border-t border-line pt-2 font-bold"><span>Total</span><span>{inr(freight + 10)}</span></div></Card>
          <Notice tone="info">Goods are carried only in vehicles permitted to carry goods. Prohibited items are not accepted.</Notice>
          <CheckoutButton label="Book parcel pickup" category="Parcels"
            validate={() => { if (!f.pickAddr || !f.dropAddr) return "Enter pickup and delivery addresses"; if (!f.recv || !/^[6-9]\d{9}$/.test(f.recvPhone)) return "Enter receiver name and valid mobile"; if (!f.cat) return "Choose a category"; if (!kg || kg > size.maxKg) return `Weight must be between 0.1 and ${size.maxKg} kg for ${size.name}`; return null; }}
            build={() => ({ module: "parcel", kind: "booking", title: `${size.name} parcel`, subtitle: `${f.pickup} → ${f.drop}`, status: "active", stageIdx: 0, stages: ["Booked", "Rider assigned", "Picked up (pickup OTP)", "In transit", "Delivered (delivery OTP)"], fees,
              when: when === "Now" ? undefined : dayLabel(nextDays(4)[day]),
              details: { Pickup: f.pickup, Drop: f.drop, "Pickup address": f.pickAddr, "Delivery address": f.dropAddr, Receiver: `${f.recv} (${f.recvPhone})`, Category: f.cat, Weight: `${kg} kg`, ...(f.l ? { Dimensions: `${f.l}×${f.w}×${f.h} cm` } : {}), Vehicle: size.vehicle },
              provider: { name: "Rajesh M", rating: 4.7, vehicle: size.id === "large" ? "TN 11 GV 4410 · Tata Ace" : size.id === "medium" ? "TN 09 GA 8810 · 3-wheeler goods" : "TN 09 CK 5521 · Bike" } })} />
        </div>
      </div>
    </div>
  );
}
