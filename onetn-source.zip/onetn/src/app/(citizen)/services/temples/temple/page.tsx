"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Flame, Clock, MapPin, Bell, BellOff, HandCoins, Package, CalendarDays } from "lucide-react";
import { useApp } from "@/lib/store";
import { FESTIVALS, PRASADAM, SEVAS, STARS, TEMPLES } from "@/data/services";
import { Badge, Button, Card, Chip, Empty, Field, Input, Notice, PageHeader, Qty, Select, Sheet, Tabs, Thumb, KV } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { CartBar, CartSheet } from "@/components/flows/CartCheckout";
import { dayLabel, inr, nextDays } from "@/lib/utils";

function Inner() {
  const t = TEMPLES.find((x) => x.id === useSearchParams().get("id"));
  const { s, cart, setQty, toast, set } = useApp();
  const [tab, setTab] = useState<"seva" | "prasadam" | "info" | "donate">("seva");
  const [seva, setSeva] = useState<(typeof SEVAS)[number] | null>(null);
  const [f, setF] = useState({ name: s.user?.name ?? "", star: "", gotra: "", day: 1, slot: "", forWhom: "Self" });
  const [open, setOpen] = useState(false);
  const [don, setDon] = useState(101);
  const [follow, setFollow] = useState(false);
  if (!t) return <Empty title="Temple not found" />;
  const key = `prasadam-${t.id}`;
  const c = cart(key);
  const closedDay = 5; // demo: temple closes bookings on a festival day
  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title={s.lang === "ta" ? t.ta : t.name} sub={`${t.deity} · ${t.district}`} right={<button aria-label="Follow temple" onClick={() => { setFollow(!follow); toast(follow ? "Unfollowed" : "You'll get festival & event updates"); }} className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white">{follow ? <Bell size={18} className="text-primary" /> : <BellOff size={18} />}</button>} />
      <div className="grid grid-cols-3 gap-2">
        <Thumb hue={t.hue} icon={Flame} className="col-span-2 row-span-2 h-56 w-full" size={200} />
        <Thumb hue={t.hue + 1} icon={Flame} className="h-27 w-full" size={100} /><Thumb hue={t.hue + 2} icon={Flame} className="h-27 w-full" size={100} />
      </div>
      <p className="text-xs text-muted">Gallery images to be supplied and approved by the temple.</p>
      <Card className="flex flex-wrap gap-4 text-sm"><span className="flex items-center gap-1"><Clock size={15} />{t.timings}</span><span className="flex items-center gap-1"><MapPin size={15} />{t.district}</span><Badge tone="gold">HR&CE administered</Badge></Card>
      {!t.booking ? <Notice tone="info">This temple has not enabled online bookings. Information and festival updates only.</Notice> : (
        <>
          <Tabs value={tab} onChange={setTab} tabs={[{ value: "seva", label: "Archana & Seva" }, { value: "prasadam", label: "Prasadam" }, { value: "donate", label: "Donate" }, { value: "info", label: "Calendar" }]} />
          {tab === "seva" && (
            <div className="grid gap-3 sm:grid-cols-2">
              {SEVAS.map((x) => (
                <Card key={x.id}>
                  <p className="font-bold">{x.name}</p><p className="text-xs text-muted">Timings: {x.slots.join(", ")}</p>
                  <div className="mt-3 flex items-center justify-between"><span className="text-lg font-bold">{inr(x.fee)} <span className="text-xs font-normal text-muted">temple fee</span></span><Button size="sm" onClick={() => { setSeva(x); setF({ ...f, slot: "" }); }}>Book</Button></div>
                </Card>
              ))}
            </div>
          )}
          {tab === "prasadam" && (
            <div className="space-y-3">
              {PRASADAM.map((p) => (
                <Card key={p.id} className="flex items-center gap-3">
                  <Thumb hue={t.hue} icon={Package} size={60} />
                  <div className="flex-1"><p className="font-semibold">{p.name}</p><p className="text-xs text-muted">{p.unit} · shelf life {p.shelf}</p><p className="font-bold">{inr(p.price)}</p></div>
                  <Qty value={c.find((x) => x.id === p.id)?.qty ?? 0} onChange={(v) => setQty(key, { id: p.id, name: `${p.name} prasadam`, price: p.price, unit: p.unit }, v)} />
                </Card>
              ))}
              <Notice tone="info">Prepared by the temple&apos;s approved kitchen only, packed sealed and labelled with shelf life. Delivery within Tamil Nadu and other states; overseas later, subject to rules.</Notice>
            </div>
          )}
          {tab === "donate" && (
            <Card className="space-y-3">
              <p className="flex items-center gap-2 font-bold"><HandCoins size={18} />Offering to the temple&apos;s official account</p>
              <div className="flex flex-wrap gap-2">{[51, 101, 251, 501, 1001].map((a) => <Chip key={a} active={don === a} onClick={() => setDon(a)}>{inr(a)}</Chip>)}</div>
              <Field label="Other amount"><Input type="number" min={1} value={don} onChange={(e) => setDon(Number(e.target.value))} /></Field>
              <CheckoutButton label={`Offer ${inr(don)}`} category="Temple bookings" validate={() => (don < 1 ? "Enter an amount" : null)}
                build={() => ({ module: "temple", kind: "booking", title: `Offering – ${t.name}`, subtitle: "Donation to official temple account", status: "completed", stageIdx: 1, stages: ["Received", "Acknowledged by temple"],
                  fees: [{ label: "Offering", amount: don, payee: `${t.name} (official account)` }, { label: "Platform fee", amount: 0, note: "No fee on offerings" }], details: { Temple: t.name, Purpose: "General offering" } })} />
            </Card>
          )}
          {tab === "info" && (
            <Card className="divide-y divide-line p-0">{FESTIVALS.filter((x) => x.temple === t.id).concat(FESTIVALS.filter((x) => x.temple !== t.id).slice(0, 1)).map((x) => <div key={x.name} className="flex items-start gap-3 px-4 py-3"><CalendarDays size={18} className="text-primary" /><div><p className="text-sm font-semibold">{x.name}</p><p className="text-xs text-muted">{x.when} · {x.note}</p></div></div>)}</Card>
          )}
        </>
      )}
      <Sheet open={!!seva} onClose={() => setSeva(null)} title={`Book ${seva?.name}`}
        footer={seva && (
          <CheckoutButton label="Confirm & pay" category="Temple bookings"
            validate={() => (!f.name ? "Enter devotee name" : seva.needs.includes("star") && !f.star ? "Select star (nakshatra)" : seva.needs.includes("gotra") && !f.gotra ? "Enter gotra" : !f.slot ? "Choose a time" : f.day === closedDay ? "Temple is not accepting bookings on this day" : null)}
            build={() => ({ module: "temple", kind: "booking", title: `${seva.name} – ${t.name}`, subtitle: `${dayLabel(nextDays(8)[f.day])}, ${f.slot}`, status: "active", stageIdx: 0, stages: ["Booking confirmed", "Seva performed", "Confirmation sent by temple"],
              fees: [{ label: `${seva.name} fee`, amount: seva.fee, payee: "Temple" }, { label: "Booking fee", amount: 5, payee: "Platform", note: "Kept small and shown separately" }],
              details: { Temple: t.name, Seva: seva.name, Devotee: f.name, ...(f.star ? { Star: f.star } : {}), ...(f.gotra ? { Gotra: f.gotra } : {}), "Booked for": f.forWhom, Date: dayLabel(nextDays(8)[f.day]), Time: f.slot } })} />
        )}>
        {seva && (
          <div className="space-y-3">
            <Field label="Booking for"><Select value={f.forWhom} onChange={(e) => setF({ ...f, forWhom: e.target.value, name: e.target.value === "Self" ? s.user?.name ?? "" : e.target.value.split(" (")[0] })} options={["Self", ...s.family.map((m) => `${m.name} (${m.relation})`)]} /></Field>
            <Field label="Devotee name" required><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            {seva.needs.includes("star") && <Field label="Star (Nakshatra)" required><Select placeholder="Select" value={f.star} onChange={(e) => setF({ ...f, star: e.target.value })} options={STARS} /></Field>}
            {seva.needs.includes("gotra") && <Field label="Gotra" required><Input value={f.gotra} onChange={(e) => setF({ ...f, gotra: e.target.value })} /></Field>}
            <p className="text-sm font-semibold">Date</p>
            <div className="no-scrollbar flex gap-2 overflow-x-auto">{nextDays(8).slice(1).map((d, i) => <Chip key={i} active={f.day === i + 1} onClick={() => setF({ ...f, day: i + 1 })} className={i + 1 === closedDay ? "line-through opacity-60" : ""}>{dayLabel(d)}</Chip>)}</div>
            {f.day === closedDay && <Notice tone="warning">Bookings closed by the temple on this day (festival).</Notice>}
            <p className="text-sm font-semibold">Available slots</p>
            <div className="flex flex-wrap gap-2">{seva.slots.map((x, i) => <Chip key={x} active={f.slot === x} onClick={() => setF({ ...f, slot: x })}>{x} <span className="ml-1 text-xs opacity-70">({12 - i * 3} left)</span></Chip>)}</div>
            <KV rows={[["Seva fee (to temple)", inr(seva.fee)], ["Booking fee (platform)", inr(5)]]} />
          </div>
        )}
      </Sheet>
      <CartBar cartKey={key} onOpen={() => setOpen(true)} />
      <CartSheet open={open} onClose={() => setOpen(false)} cfg={{ cartKey: key, module: "prasadam", title: "Prasadam order", store: t.name, category: "Temple bookings", deliveryFee: 40, platformFee: 0, repeatHref: `/services/temples/temple?id=${t.id}`,
        stages: ["Order placed", "Temple preparing & packing", "Handed to rider", "Out for delivery", "Delivered"],
        extraDetails: { Note: "Prasadam price goes to the temple; delivery fee to platform/rider" }, notice: <Notice tone="gold">Prasadam price → temple. Delivery fee → shown separately.</Notice> }} />
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
