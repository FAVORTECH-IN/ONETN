"use client";
import Link from "next/link";
import { useState } from "react";
import { Flame, Search, Clock, CalendarDays } from "lucide-react";
import { useApp } from "@/lib/store";
import { FESTIVALS, TEMPLES } from "@/data/services";
import { Badge, Card, Chip, Empty, Notice, PageHeader, SectionHeader, Thumb } from "@/components/ui";

export default function Temples() {
  const { s } = useApp();
  const [q, setQ] = useState("");
  const [d, setD] = useState("All");
  const districts = Array.from(new Set(TEMPLES.map((t) => t.district)));
  const list = TEMPLES.filter((t) => (d === "All" || t.district === d) && (!q || (t.name + t.ta + t.deity + t.district).toLowerCase().includes(q.toLowerCase())));
  const temples = s.bookings.filter((b) => b.module === "temple" || b.module === "prasadam");
  return (
    <div className="space-y-5">
      <PageHeader title="Temple Services" sub="Archana, seva and prasadam from participating temples" />
      <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search temple, deity or town" className="h-12 w-full rounded-2xl border border-line bg-white pl-11 outline-none focus:border-primary" /></div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", ...districts].map((x) => <Chip key={x} active={d === x} onClick={() => setD(x)}>{x}</Chip>)}</div>
      {list.length === 0 ? <Empty title="No temples found" /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((t) => (
            <Link key={t.id} href={`/services/temples/temple?id=${t.id}`} className="card flex gap-3 p-3 hover:shadow-[var(--shadow-lift)]">
              <Thumb hue={t.hue} icon={Flame} size={84} />
              <div className="min-w-0 flex-1">
                <p className="font-semibold leading-snug">{s.lang === "ta" ? t.ta : t.name}</p>
                <p className="text-xs text-muted">{t.deity} · {t.district}</p>
                <p className="mt-1 flex items-center gap-1 text-xs"><Clock size={12} />{t.timings}</p>
                <div className="mt-1.5">{t.booking ? <Badge tone="success">Online booking</Badge> : <Badge>Information only</Badge>}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
      {temples.length > 0 && <Link href="/bookings" className="block text-sm font-semibold text-primary">View my seva bookings & prasadam orders →</Link>}
      <section>
        <SectionHeader title="Festival calendar" />
        <Card className="divide-y divide-line p-0">
          {FESTIVALS.map((f) => (
            <div key={f.name} className="flex items-start gap-3 px-4 py-3"><CalendarDays size={18} className="mt-0.5 text-primary" /><div className="flex-1"><p className="text-sm font-semibold">{f.name} <span className="font-normal text-muted">· {TEMPLES.find((t) => t.id === f.temple)?.district}</span></p><p className="text-xs text-muted">{f.when} · {f.note}</p></div></div>
          ))}
        </Card>
      </section>
      <Notice tone="gold">Offered only with approval of the HR&CE Department and each temple&apos;s administration. Temples set their own sevas, timings and customs. Seva fees, offerings and prasadam price go to the temple. No advertising on temple pages.</Notice>
    </div>
  );
}
