"use client";
import { Fragment, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowUpDown, Bus, Clock, Star, Armchair, History, Users } from "lucide-react";
import { useApp } from "@/lib/store";
import { BOARDING, CITIES, CONCESSIONS, DROPPING, bookedSeats, busesFor, type BusSvc } from "@/data/transport";
import { Badge, Button, Card, Chip, Field, Input, Notice, PageHeader, Select, SimTag, Stepper } from "@/components/ui";
import { CheckoutButton } from "@/components/flows/Payment";
import { cn, inr } from "@/lib/utils";

type Pax = { name: string; age: string; gender: string; concession: string };

export default function BusBooking() {
  const { s, toast } = useApp();
  const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const [from, setFrom] = useState("Chennai");
  const [to, setTo] = useState("Madurai");
  const [date, setDate] = useState(tomorrow);
  const [ret, setRet] = useState("");
  const [step, setStep] = useState(0);
  const [op, setOp] = useState("All");
  const [bus, setBus] = useState<BusSvc | null>(null);
  const [seats, setSeats] = useState<number[]>([]);
  const [board, setBoard] = useState(BOARDING[0]);
  const [dropP, setDropP] = useState(DROPPING[0]);
  const [pax, setPax] = useState<Pax[]>([]);
  const buses = useMemo(() => busesFor(from, to).filter((b) => op === "All" || b.operator === op), [from, to, op]);
  const booked = bus ? bookedSeats(bus.id) : new Set<number>();
  const toggleSeat = (n: number) => {
    if (booked.has(n)) return;
    if (seats.includes(n)) { setSeats(seats.filter((x) => x !== n)); return; }
    if (seats.length >= 6) return toast("Maximum 6 seats per booking", "error");
    setSeats([...seats, n]);
  };
  const toPax = () => { setPax(seats.map((_, i) => pax[i] ?? { name: i === 0 ? s.user?.name ?? "" : "", age: "", gender: "", concession: "none" })); setStep(3); };
  const lines = bus ? pax.map((p, i) => {
    const c = CONCESSIONS.find((x) => x.id === p.concession)!;
    return { label: `Seat ${seats[i]} – ${p.name || "Passenger"}${c.pct ? ` (${c.label.split(" (")[0]})` : ""}`, amount: Math.round(bus.fare * (1 - c.pct / 100)) };
  }) : [];
  const fees = [...lines, { label: "Reservation charge (operator)", amount: 10 * seats.length }, { label: "Platform fee", amount: 0, note: "No platform fee on public transport tickets" }];

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Bus Booking" sub="SETC, TNSTC & government buses · listed private operators" right={<Button size="sm" variant="outline" href="/bookings"><History size={15} />My tickets</Button>} />
      <Stepper steps={["Search", "Choose bus", "Seats", "Passengers", "Pay"]} current={step} />
      <div className="mt-5">
        {step === 0 && (
          <Card className="space-y-4">
            <div className="grid items-end gap-3 sm:grid-cols-[1fr_auto_1fr]">
              <Field label="From"><Select value={from} onChange={(e) => setFrom(e.target.value)} options={CITIES} /></Field>
              <button aria-label="Swap" onClick={() => { setFrom(to); setTo(from); }} className="mx-auto grid h-11 w-11 place-items-center rounded-full border border-line bg-white"><ArrowUpDown size={18} /></button>
              <Field label="To"><Select value={to} onChange={(e) => setTo(e.target.value)} options={CITIES.filter((c) => c !== from)} /></Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Journey date"><Input type="date" value={date} min={new Date().toISOString().slice(0, 10)} onChange={(e) => setDate(e.target.value)} /></Field>
              <Field label="Return date (optional)"><Input type="date" value={ret} min={date} onChange={(e) => setRet(e.target.value)} /></Field>
            </div>
            <Button full size="lg" disabled={from === to || !date} onClick={() => setStep(1)}>Search buses</Button>
            <Notice tone="info">Government transport bookings are brought in from existing operator systems. Live availability needs operator integration – showing simulated schedules.</Notice>
          </Card>
        )}
        {step === 1 && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2"><p className="font-semibold">{from} → {to} · {new Date(date).toDateString()}</p><SimTag /></div>
            <div className="no-scrollbar flex gap-2 overflow-x-auto">{["All", "SETC", "TNSTC", "Private"].map((o) => <Chip key={o} active={op === o} onClick={() => setOp(o)}>{o}</Chip>)}</div>
            {buses.map((b) => (
              <Card key={b.id}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2"><Badge tone={b.operator === "Private" ? "info" : "primary"}>{b.operator}</Badge><span className="text-sm font-semibold">{b.type}</span></div>
                    <p className="mt-2 text-xl font-bold">{b.dep} <span className="text-sm font-normal text-muted">— {b.dur} —</span> {b.arr}</p>
                    <p className="text-xs text-muted">{b.id} · via {b.via}</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">{b.amenities.map((a) => <Badge key={a}>{a}</Badge>)}</div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-extrabold">{inr(b.fare)}</p>
                    <p className="text-xs text-muted">{b.seats} seats left</p>
                    <p className="flex items-center justify-end gap-1 text-xs"><Star size={12} className="fill-gold text-gold" />{b.rating}</p>
                    <Button size="sm" className="mt-2" onClick={() => { setBus(b); setSeats([]); setStep(2); }}>Select seats</Button>
                  </div>
                </div>
              </Card>
            ))}
            <Button variant="ghost" onClick={() => setStep(0)}>← Modify search</Button>
          </div>
        )}
        {step === 2 && bus && (
          <div className="grid gap-4 lg:grid-cols-[auto_1fr]">
            <Card className="mx-auto">
              <div className="mb-3 flex items-center justify-between text-xs text-muted"><span>Front</span><span className="rounded-lg border border-line px-2 py-1">🛞 Driver</span></div>
              <div className="grid grid-cols-[repeat(2,40px)_20px_repeat(2,40px)] gap-2">
                {Array.from({ length: 36 }, (_, i) => i + 1).map((n) => {
                  const col = (n - 1) % 4; const isB = booked.has(n), sel = seats.includes(n);
                  return (
                    <Fragment key={n}>
                      {col === 2 && <span key={`a${n}`} />}
                      <button onClick={() => toggleSeat(n)} aria-label={`Seat ${n}${isB ? " booked" : ""}`} disabled={isB}
                        className={cn("grid h-10 w-10 place-items-center rounded-lg border text-xs font-bold", isB ? "border-line bg-line/60 text-muted" : sel ? "border-primary bg-primary text-white" : "border-success/50 bg-white text-success")}>
                        <Armchair size={14} className="hidden" />{n}
                      </button>
                    </Fragment>
                  );
                })}
              </div>
              <div className="mt-4 flex gap-3 text-xs"><span className="flex items-center gap-1"><i className="h-3 w-3 rounded border border-success/50" />Available</span><span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-primary" />Selected</span><span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-line" />Booked</span></div>
            </Card>
            <div className="space-y-3">
              <Card>
                <p className="font-bold">{bus.operator} · {bus.type}</p><p className="text-sm text-muted">{bus.dep} → {bus.arr} · {inr(bus.fare)} per seat</p>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <Field label="Boarding point"><Select value={board} onChange={(e) => setBoard(e.target.value)} options={BOARDING} /></Field>
                  <Field label="Dropping point"><Select value={dropP} onChange={(e) => setDropP(e.target.value)} options={DROPPING.map((d) => `${to} ${d}`)} /></Field>
                </div>
              </Card>
              <Card className="flex items-center justify-between"><span>Selected: <b>{seats.join(", ") || "—"}</b></span><span className="font-bold">{inr(bus.fare * seats.length)}</span></Card>
              <div className="flex gap-2"><Button variant="outline" onClick={() => setStep(1)}>Back</Button><Button full disabled={!seats.length} onClick={toPax}>Continue</Button></div>
            </div>
          </div>
        )}
        {step === 3 && bus && (
          <div className="space-y-3">
            {pax.map((p, i) => (
              <Card key={i}>
                <p className="mb-3 flex items-center gap-2 font-bold"><Users size={16} />Passenger {i + 1} · Seat {seats[i]}</p>
                <div className="grid gap-3 sm:grid-cols-4">
                  <Field label="Name" required><Input value={p.name} onChange={(e) => setPax(pax.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} /></Field>
                  <Field label="Age" required><Input type="number" min={1} max={110} value={p.age} onChange={(e) => setPax(pax.map((x, k) => (k === i ? { ...x, age: e.target.value } : x)))} /></Field>
                  <Field label="Gender" required><Select placeholder="Select" value={p.gender} options={["Female", "Male", "Transgender"]} onChange={(e) => setPax(pax.map((x, k) => (k === i ? { ...x, gender: e.target.value } : x)))} /></Field>
                  <Field label="Concession"><Select value={p.concession} options={CONCESSIONS.filter((c) => c.id !== "women-free").map((c) => ({ value: c.id, label: c.label }))} onChange={(e) => setPax(pax.map((x, k) => (k === i ? { ...x, concession: e.target.value } : x)))} /></Field>
                </div>
              </Card>
            ))}
            <Notice tone="gold">Concessions are applied as per department rules; carry the relevant ID/pass for verification while boarding. Percentages shown are demo values.</Notice>
            <div className="flex gap-2"><Button variant="outline" onClick={() => setStep(2)}>Back</Button>
              <CheckoutButton label="Review fare & pay" category="Bus tickets"
                validate={() => pax.some((p) => !p.name.trim() || !p.age || !p.gender) ? "Fill name, age and gender for every passenger" : null}
                build={() => ({ module: "bus", kind: "booking", title: `Bus ticket – ${from} to ${to}`, subtitle: `${bus.operator} ${bus.type} · ${new Date(date).toDateString()} ${bus.dep}`, status: "active", stageIdx: 0,
                  stages: ["Ticket confirmed", "Bus departed", "Journey completed"], fees,
                  details: { From: from, To: to, Date: new Date(date).toDateString(), Departure: bus.dep, Bus: bus.id, Boarding: board, Dropping: dropP, Seats: seats.join(", "), Passengers: pax.map((p) => `${p.name} (${p.age}${p.gender[0]})`).join(", "), ...(ret ? { "Return date": ret } : {}) },
                })} />
            </div>
          </div>
        )}
      </div>
      <p className="mt-6 text-center text-sm text-muted">Need a city bus or Metro? <Link className="font-semibold text-primary" href="/services/transport">Public transport →</Link> <Bus className="hidden" /><Clock className="hidden" /></p>
    </div>
  );
}
