"use client";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { RideBooking } from "@/components/flows/RideBooking";
function Inner() { const t = useSearchParams().get("type") ?? undefined; return <RideBooking mode="cab" initialType={t} />; }
export default function Page() { return <Suspense><Inner /></Suspense>; }
