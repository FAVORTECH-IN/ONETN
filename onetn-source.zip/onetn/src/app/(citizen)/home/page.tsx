"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Bell, MapPin, Search, Plus, History, Wallet as WalletIcon, ChevronRight, ChevronDown, MoreHorizontal, Megaphone, Star, Clock, Phone, MessageCircle, BadgePercent, Briefcase, IndianRupee } from "lucide-react";
import { useApp } from "@/lib/store";
import { SERVICES, HOME_GRID, svc } from "@/data/catalog";
import { STORES, PRODUCTS } from "@/data/delivery";
import { HOME_CATS, TEMPLES } from "@/data/services";
import { LIBRARY, DOCTORS } from "@/data/learning";
import { JOBS, RESTAURANTS } from "@/data/jobsfood";
import { Avatar, Badge, Card, SectionHeader, Thumb, Rating, statusTone } from "@/components/ui";
import { LogoMark } from "@/components/shell/Logo";
import { cn, inr, fmtDate } from "@/lib/utils";
import { Wheat, Milk, Pill, Sprout, ShoppingCart, BookOpen, Video, FileText, Flame } from "lucide-react";

const tones = ["bg-primary-soft text-primary", "bg-gold-soft text-[#8A6A00]", "bg-success-soft text-success", "bg-[#E6EEF8] text-[#1D4E89]", "bg-warning-soft text-[#B5700D]", "bg-[#EFE6F6] text-[#5B3A86]", "bg-[#E4F1F1] text-[#1F6F6F]"];

export default function HomePage() {
  const { s, t, tx } = useApp();
  const r = useRouter();
  const [q, setQ] = useState("");
  const first = s.user?.name.split(" ")[0] ?? "";
  const unread = s.notifications.filter((n) => !n.read).length;
  const recentB = s.bookings.filter((b) => b.kind !== "order").slice(0, 3);
  const recentO = s.bookings.filter((b) => b.kind === "order").slice(0, 3);
  const results = q.trim() ? SERVICES.filter((x) => (x.name.en + x.name.ta + x.desc.en + x.group).toLowerCase().includes(q.toLowerCase())).slice(0, 6) : [];

  return (
    <div className="space-y-7">
      {/* Mobile header */}
      <header className="flex items-center gap-3 lg:hidden">
        <LogoMark size={40} />
        <Link href="/profile/addresses" className="min-w-0 flex-1">
          <span className="block text-[11px] font-semibold uppercase tracking-wide text-muted">Location</span>
          <span className="flex items-center gap-1 truncate text-sm font-bold"><MapPin size={14} className="text-primary" />{s.location}<ChevronDown size={14} /></span>
        </Link>
        <Link href="/notifications" aria-label="Notifications" className="relative grid h-10 w-10 place-items-center rounded-full border border-line bg-white"><Bell size={19} />{unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-primary text-[10px] font-bold text-white">{unread}</span>}</Link>
        <Link href="/profile" aria-label="Profile">{s.user?.photo ? <img src={s.user.photo} alt="" className="h-10 w-10 rounded-full object-cover" /> : <Avatar name={s.user?.name ?? "U"} size={40} />}</Link>
      </header>

      {/* Welcome + search */}
      <section className="relative overflow-hidden rounded-[22px] bg-primary px-5 pb-5 pt-5 text-white sm:px-7 sm:pt-7">
        <svg className="absolute -right-10 -top-16 h-56 w-56 opacity-20" viewBox="0 0 100 100" aria-hidden><circle cx="50" cy="50" r="44" fill="none" stroke="#D4AF37" strokeWidth="6" /><circle cx="50" cy="50" r="24" fill="none" stroke="#D4AF37" strokeWidth="3" /></svg>
        <p className="relative text-sm text-white/80">{t("hello")}, {t("welcomeTo")}</p>
        <h1 className="relative mt-0.5 text-2xl font-extrabold sm:text-3xl">{first} 👋</h1>
        <p className="relative mt-1 flex items-center gap-1 text-sm text-white/80"><MapPin size={14} />{s.location}</p>
        <div className="relative mt-4">
          <Search size={19} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && r.push(`/services?q=${encodeURIComponent(q)}`)}
            placeholder={t("searchPlaceholder")} aria-label={t("searchPlaceholder")}
            className="h-13 w-full rounded-2xl bg-white py-3.5 pl-12 pr-4 text-[15px] text-ink outline-none ring-gold/50 focus:ring-4" />
          {results.length > 0 && (
            <div className="absolute inset-x-0 top-full z-20 mt-2 overflow-hidden rounded-2xl border border-line bg-white text-ink shadow-[var(--shadow-lift)]">
              {results.map((x) => (
                <Link key={x.id} href={x.href} className="flex items-center gap-3 px-4 py-3 hover:bg-cream">
                  <x.icon size={18} className="text-primary" /><span className="flex-1"><span className="block text-sm font-semibold">{tx(x.name)}</span><span className="text-xs text-muted">{tx(x.desc)}</span></span><ChevronRight size={16} className="text-muted" />
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Wallet card */}
      <section className="card relative overflow-hidden p-0">
        <div className="flex items-center justify-between gap-4 p-5">
          <div>
            <p className="flex items-center gap-2 text-sm text-muted"><WalletIcon size={16} className="text-primary" />{t("wallet")} · {t("availableBalance")}</p>
            <p className="mt-1 text-3xl font-extrabold">{inr(s.wallet.balance)}</p>
            {s.wallet.frozen && <Badge tone="error" className="mt-1">Frozen</Badge>}
          </div>
          <span className="hidden h-16 w-16 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00] sm:grid"><IndianRupee size={30} /></span>
        </div>
        <div className="grid grid-cols-3 border-t border-line text-sm font-semibold">
          <Link href="/wallet/add" className="flex flex-col items-center gap-1 py-3 text-primary hover:bg-cream sm:flex-row sm:justify-center"><Plus size={18} />{t("addMoney")}</Link>
          <Link href="/wallet/history" className="flex flex-col items-center gap-1 border-x border-line py-3 hover:bg-cream sm:flex-row sm:justify-center"><History size={18} />{t("history")}</Link>
          <Link href="/wallet" className="flex flex-col items-center gap-1 py-3 hover:bg-cream sm:flex-row sm:justify-center"><WalletIcon size={18} />{t("viewWallet")}</Link>
        </div>
      </section>

      {/* Our services grid */}
      <section>
        <SectionHeader title={t("ourServices")} href="/services" />
        <div className="grid grid-cols-3 gap-3 sm:gap-4 md:grid-cols-5 lg:grid-cols-9">
          {HOME_GRID.map((id) => { const x = svc(id); return (
            <Link key={id} href={x.href} className="card group flex flex-col items-center gap-2 px-2 py-4 text-center transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]">
              <span className={cn("grid h-14 w-14 place-items-center rounded-[18px] transition group-hover:scale-105", tones[(x.tone ?? 0) % tones.length])}><x.icon size={27} /></span>
              <span className="text-[12.5px] font-semibold leading-tight">{tx(x.name)}</span>
            </Link>
          ); })}
          <Link href="/services" className="card group flex flex-col items-center gap-2 px-2 py-4 text-center transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]">
            <span className="grid h-14 w-14 place-items-center rounded-[18px] bg-primary text-white"><MoreHorizontal size={27} /></span>
            <span className="text-[12.5px] font-semibold leading-tight">{t("moreServices")}</span>
          </Link>
        </div>
      </section>

      {/* Offers */}
      <section className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        {[
          { t: "Fair fares, always", d: "Auto & cab fares shown before you book. No surge.", h: "/services/auto-booking", c: "bg-primary text-white" },
          { t: "Ration at your doorstep", d: "Book your monthly entitlement for home delivery.", h: "/services/ration", c: "bg-gold text-ink" },
          { t: "₹50 off first grocery order", d: "Partner-funded · code FIRST50", h: "/services/quick-delivery", c: "bg-success text-white" },
        ].map((o) => (
          <Link key={o.t} href={o.h} className={cn("min-w-[78%] rounded-[20px] p-5 sm:min-w-0 sm:flex-1", o.c)}>
            <BadgePercent size={22} /><p className="mt-2 text-lg font-bold">{o.t}</p><p className="text-sm opacity-85">{o.d}</p>
          </Link>
        ))}
      </section>

      {/* Popular near you */}
      <section>
        <SectionHeader title={t("popularNearYou")} href="/services" />
        <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 sm:mx-0 sm:grid sm:grid-cols-4 sm:px-0">
          {[svc("auto"), svc("milk"), svc("home"), svc("food")].map((x, i) => (
            <Link key={x.id} href={x.href} className="card min-w-[150px] overflow-hidden p-0">
              <Thumb hue={i * 2} icon={x.icon} className="h-24 w-full rounded-none" size={90} />
              <div className="p-3"><p className="text-sm font-semibold">{tx(x.name)}</p><p className="text-xs text-muted">{tx(x.desc)}</p></div>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-7 lg:grid-cols-2">
        {/* Quick Delivery */}
        <section>
          <SectionHeader title={t("quickDelivery")} href="/services/quick-delivery" sub="Groceries in ~20 minutes from nearby stores" />
          <div className="grid grid-cols-2 gap-3">
            {STORES.slice(0, 2).map((st) => (
              <Link key={st.id} href={`/services/quick-delivery/store?id=${st.id}`} className="card p-3">
                <Thumb hue={st.hue} icon={ShoppingCart} className="h-20 w-full" />
                <p className="mt-2 truncate text-sm font-semibold">{st.name}</p>
                <p className="flex items-center gap-2 text-xs text-muted"><Clock size={12} />{st.eta} min · {st.km} km</p>
              </Link>
            ))}
          </div>
          <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
            {PRODUCTS.slice(0, 6).map((p) => <Link key={p.id} href={`/services/quick-delivery/product?id=${p.id}`} className="shrink-0 rounded-full border border-line bg-white px-3 py-1.5 text-xs font-semibold">{p.name} · {inr(p.price)}</Link>)}
          </div>
        </section>

        {/* Essentials */}
        <section>
          <SectionHeader title={t("essentials")} href="/services/essentials" sub="Government-supplied items delivered home" />
          <div className="grid grid-cols-5 gap-2">
            {[{ i: Wheat, l: "Ration", h: "/services/ration" }, { i: Milk, l: "Milk", h: "/services/milk" }, { i: Pill, l: "Medicine", h: "/services/medicines" }, { i: Sprout, l: "Uzhavar", h: "/services/uzhavar-sandhai" }, { i: ShoppingCart, l: "Co-op", h: "/services/essentials/cooperative" }].map((x, i) => (
              <Link key={x.l} href={x.h} className="card flex flex-col items-center gap-1.5 px-1 py-3 text-center"><span className={cn("grid h-11 w-11 place-items-center rounded-2xl", tones[i])}><x.i size={20} /></span><span className="text-[11.5px] font-semibold">{x.l}</span></Link>
            ))}
          </div>
          <Card className="mt-3 flex items-center gap-3 bg-gold-soft"><Wheat className="text-[#8A6A00]" /><p className="flex-1 text-sm"><b>November entitlement ready.</b> Doorstep delivery or shop collection — your choice.</p><Link href="/services/ration" className="text-sm font-bold text-primary">Book</Link></Card>
        </section>
      </div>

      {/* Home services */}
      <section>
        <SectionHeader title={t("homeServices")} href="/services/home-services" sub="Verified professionals · rate card shown upfront" />
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-8">
          {HOME_CATS.slice(0, 8).map((c, i) => (
            <Link key={c.id} href={`/services/home-services/${c.id}`} className="flex flex-col items-center gap-1.5 text-center">
              <span className={cn("grid h-14 w-14 place-items-center rounded-[18px] border border-line bg-white shadow-[var(--shadow-soft)]")}><c.icon size={24} className={["text-primary", "text-[#8A6A00]", "text-success", "text-[#1D4E89]"][i % 4]} /></span>
              <span className="text-[11.5px] font-semibold leading-tight">{s.lang === "ta" ? c.ta : c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Food */}
      <section>
        <SectionHeader title={t("food")} href="/services/food" />
        <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 sm:mx-0 sm:grid sm:grid-cols-3 sm:px-0">
          {RESTAURANTS.slice(0, 3).map((rs) => (
            <Link key={rs.id} href={`/services/food/restaurant?id=${rs.id}`} className="card min-w-[230px] overflow-hidden p-0">
              <Thumb hue={rs.hue} icon={Flame} className="h-28 w-full rounded-none" size={110} />
              <div className="p-3">
                <div className="flex items-center justify-between gap-2"><p className="truncate font-semibold">{rs.name}</p><Rating value={rs.rating} /></div>
                <p className="truncate text-xs text-muted">{rs.cuisine.join(" · ")} · {rs.eta} min</p>
                {rs.offer && <p className="mt-1 text-xs font-semibold text-success">{rs.offer}</p>}
              </div>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-7 lg:grid-cols-2">
        {/* Temple */}
        <section>
          <SectionHeader title={t("temples")} href="/services/temples" sub="With HR&CE and temple approval" />
          <div className="space-y-2">
            {TEMPLES.slice(0, 2).map((tp) => (
              <Link key={tp.id} href={`/services/temples/temple?id=${tp.id}`} className="card flex items-center gap-3 p-3">
                <Thumb hue={tp.hue} icon={Flame} size={56} />
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{s.lang === "ta" ? tp.ta : tp.name}</p><p className="text-xs text-muted">{tp.district} · Archana, seva, prasadam</p></div>
                <ChevronRight size={18} className="text-muted" />
              </Link>
            ))}
          </div>
        </section>
        {/* Education */}
        <section>
          <SectionHeader title={t("education")} href="/services/education" />
          <div className="space-y-2">
            {LIBRARY.filter((l) => l.free).slice(0, 2).map((l) => (
              <Link key={l.id} href={`/services/education/library/item?id=${l.id}`} className="card flex items-center gap-3 p-3">
                <Thumb hue={l.hue} icon={l.kind === "Video" ? Video : BookOpen} size={56} />
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{l.title}</p><p className="text-xs text-muted">{l.kind} · {l.lang} · <span className="font-semibold text-success">Free</span></p></div>
              </Link>
            ))}
          </div>
        </section>
        {/* Healthcare */}
        <section>
          <SectionHeader title={t("healthcare")} href="/services/healthcare" />
          <div className="space-y-2">
            {DOCTORS.slice(0, 2).map((d) => (
              <Link key={d.id} href={`/services/healthcare/doctor?id=${d.id}`} className="card flex items-center gap-3 p-3">
                <Avatar name={d.name.replace("Dr. ", "")} size={52} tone="gold" />
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{d.name}</p><p className="text-xs text-muted">{d.spec} · {d.exp} yrs · {inr(d.fee)}</p></div>
                <Rating value={d.rating} />
              </Link>
            ))}
          </div>
        </section>
        {/* Gov updates */}
        <section>
          <SectionHeader title={t("govUpdates")} href="/services/government" />
          <div className="card divide-y divide-line p-0">
            {[
              { t: "Ration card member addition now in-app", d: "Civil Supplies · Connected service", h: "/services/government/service?id=ration-member" },
              { t: "Post-matric scholarship window open", d: "Adi Dravidar & Tribal Welfare", h: "/services/government/service?id=scholarship-pm" },
              { t: "Annual pension life confirmation reminder", d: "Social Welfare · due this month", h: "/services/government/service?id=oap" },
            ].map((u) => (
              <Link key={u.t} href={u.h} className="flex items-center gap-3 px-4 py-3 hover:bg-cream"><Megaphone size={18} className="shrink-0 text-primary" /><span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{u.t}</span><span className="text-xs text-muted">{u.d}</span></span><ChevronRight size={16} className="text-muted" /></Link>
            ))}
          </div>
        </section>
      </div>

      {/* Jobs */}
      <section>
        <SectionHeader title={t("recommendedJobs")} href="/services/jobs" />
        <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 sm:mx-0 sm:grid sm:grid-cols-3 sm:px-0">
          {JOBS.slice(0, 3).map((j) => (
            <Link key={j.id} href={`/services/jobs/job?id=${j.id}`} className="card min-w-[260px] p-4">
              <div className="flex items-start gap-3"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gold-soft text-[#8A6A00]"><Briefcase size={20} /></span>
                <div className="min-w-0"><p className="line-clamp-2 text-sm font-semibold">{j.title}</p><p className="truncate text-xs text-muted">{j.org}</p></div></div>
              <div className="mt-3 flex flex-wrap gap-1.5"><Badge tone={j.sector === "Government" ? "primary" : "info"}>{j.sector}</Badge><Badge>{j.location}</Badge></div>
              <p className="mt-2 text-sm font-semibold">{inr(j.salary[0])} – {inr(j.salary[1])}{j.type.includes("Daily") ? "/day" : "/month"}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Recent */}
      <div className="grid gap-7 lg:grid-cols-2">
        {[{ title: t("recentBookings"), list: recentB, href: "/bookings" }, { title: t("recentOrders"), list: recentO, href: "/orders" }].map((g) => (
          <section key={g.title}>
            <SectionHeader title={g.title} href={g.href} />
            {g.list.length === 0 ? <Card className="text-sm text-muted">{t("noItems")}</Card> : (
              <div className="card divide-y divide-line p-0">
                {g.list.map((b) => (
                  <Link key={b.id} href={`/bookings/detail?id=${b.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-cream">
                    <FileText size={18} className="text-primary" />
                    <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{b.title}</span><span className="block truncate text-xs text-muted">{b.subtitle} · {fmtDate(b.createdAt)}</span></span>
                    <Badge tone={statusTone(b.status)}>{b.status}</Badge>
                  </Link>
                ))}
              </div>
            )}
          </section>
        ))}
      </div>

      {/* Help */}
      <section className="card flex flex-col gap-4 bg-white sm:flex-row sm:items-center">
        <div className="flex-1"><p className="text-lg font-bold">{t("support")}</p><p className="text-sm text-muted">Tamil & English help desk · grievances tracked to resolution</p></div>
        <div className="flex gap-2">
          <Link href="/support/chat" className="flex items-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-sm font-semibold text-white"><MessageCircle size={17} />Chat</Link>
          <a href="tel:1800000000" className="flex items-center gap-2 rounded-2xl border border-line px-4 py-2.5 text-sm font-semibold"><Phone size={17} />Call</a>
          <Link href="/grievance" className="flex items-center gap-2 rounded-2xl border border-line px-4 py-2.5 text-sm font-semibold"><Star size={17} />Grievance</Link>
        </div>
      </section>
    </div>
  );
}
