"use client";
import Link from "next/link";
import { Bell, CheckCheck, Trash2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { Button, Empty, PageHeader } from "@/components/ui";
import { cn, fmtDate } from "@/lib/utils";

export default function Notifs() {
  const { s, set, t } = useApp();
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title={t("notifications")} right={<div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => set((p) => ({ ...p, notifications: p.notifications.map((n) => ({ ...n, read: true })) }))}><CheckCheck size={15} />Read all</Button><Button size="sm" variant="ghost" aria-label="Clear all" onClick={() => set((p) => ({ ...p, notifications: [] }))}><Trash2 size={15} /></Button></div>} />
      {s.notifications.length === 0 ? <Empty title="You're all caught up" /> : (
        <div className="card divide-y divide-line p-0">
          {s.notifications.map((n) => {
            const inner = (<><span className={cn("mt-1 grid h-9 w-9 shrink-0 place-items-center rounded-full", n.read ? "bg-cream text-muted" : "bg-primary-soft text-primary")}><Bell size={16} /></span><div className="min-w-0 flex-1"><p className={cn("text-sm", !n.read && "font-bold")}>{n.title}</p><p className="text-sm text-muted">{n.body}</p><p className="text-xs text-muted">{fmtDate(n.at, true)}</p></div>{!n.read && <span className="mt-2 h-2.5 w-2.5 rounded-full bg-primary" />}</>);
            const mark = () => set((p) => ({ ...p, notifications: p.notifications.map((x) => (x.id === n.id ? { ...x, read: true } : x)) }));
            return n.link ? <Link key={n.id} href={n.link} onClick={mark} className="flex gap-3 px-4 py-3 hover:bg-cream">{inner}</Link> : <button key={n.id} onClick={mark} className="flex w-full gap-3 px-4 py-3 text-left hover:bg-cream">{inner}</button>;
          })}
        </div>
      )}
    </div>
  );
}
