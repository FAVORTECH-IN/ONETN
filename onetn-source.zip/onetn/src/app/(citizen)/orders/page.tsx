import { BookingList } from "@/components/flows/BookingList";
export default function Page() { return <BookingList kind="orders" />; }
