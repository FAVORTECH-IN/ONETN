import { CitizenShell } from "@/components/shell/CitizenShell";
export default function L({ children }: { children: React.ReactNode }) { return <CitizenShell>{children}</CitizenShell>; }
