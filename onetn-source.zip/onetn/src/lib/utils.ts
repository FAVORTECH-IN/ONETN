import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const inr = (n: number, opts: { sign?: boolean } = {}) => {
  const abs = Math.abs(n);
  const s = "₹" + abs.toLocaleString("en-IN", { maximumFractionDigits: 2, minimumFractionDigits: abs % 1 ? 2 : 0 });
  if (opts.sign) return (n < 0 ? "− " : "+ ") + s;
  return n < 0 ? "− " + s : s;
};

export const uid = (prefix = "") =>
  prefix + Math.random().toString(36).slice(2, 6).toUpperCase() + Date.now().toString(36).slice(-4).toUpperCase();

export const fmtDate = (iso: string | number | Date, withTime = false) => {
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}) });
};

export const otp4 = () => String(Math.floor(1000 + Math.random() * 9000));

export const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

export const maskMobile = (m: string) => (m && m.length >= 10 ? m.slice(0, 2) + "XXXXXX" + m.slice(-2) : m);

export const nextDays = (n: number) =>
  Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });

export const dayLabel = (d: Date) => d.toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short" });

export function downloadText(filename: string, text: string, mime = "text/plain") {
  const blob = new Blob([text], { type: mime });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

export function toCSV(rows: Record<string, unknown>[]) {
  if (!rows.length) return "";
  const keys = Object.keys(rows[0]);
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [keys.join(","), ...rows.map((r) => keys.map((k) => esc(r[k])).join(","))].join("\n");
}
