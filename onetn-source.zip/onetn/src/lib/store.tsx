"use client";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { dict, type Bi, type DictKey, type Lang } from "./i18n";
import { otp4, uid } from "./utils";

export type Role =
  | "citizen" | "driver" | "professional" | "merchant" | "restaurant" | "temple"
  | "education" | "healthcare" | "employer" | "department" | "admin";

export type ModuleKey =
  | "auto" | "cab" | "bus" | "metro" | "parcel" | "grocery" | "ration" | "milk" | "medicine"
  | "uzhavar" | "coop" | "home" | "government" | "temple" | "prasadam" | "education" | "counselling"
  | "healthcare" | "jobs" | "food" | "takeaway" | "table" | "wallet";

export interface User {
  name: string; mobile: string; email?: string; dob?: string; address?: string; district?: string;
  taluk?: string; city?: string; pincode?: string; photo?: string; role: Role;
}
export interface Txn {
  id: string; at: string; title: string; category: string; amount: number;
  status: "success" | "failed" | "pending" | "refunded"; method: string; ref?: string;
}
export interface LineItem { name: string; qty: number; price: number; }
export interface Fee { label: string; amount: number; note?: string; payee?: string; }
export interface Booking {
  id: string; module: ModuleKey; title: string; subtitle?: string; createdAt: string; when?: string;
  amount: number; status: "active" | "completed" | "cancelled" | "paused"; stages: string[]; stageIdx: number;
  details: Record<string, string>; items?: LineItem[]; fees: Fee[]; otp?: string;
  provider?: { name: string; rating?: number; phone?: string; vehicle?: string; extra?: string };
  rating?: number; review?: string; payment: string; kind: "booking" | "order" | "subscription" | "appointment" | "application";
  extraApproval?: { desc: string; amount: number; state: "pending" | "approved" | "declined" };
}
export interface Grievance {
  id: string; service: string; category: string; ref?: string; description: string; createdAt: string;
  status: GStatus; history: { status: GStatus; note: string; at: string }[]; feedback?: number; attachments?: string[];
}
export type GStatus = "Submitted" | "Under Review" | "Assigned" | "In Progress" | "Awaiting Information" | "Resolved" | "Closed";
export interface Notif { id: string; title: string; body: string; at: string; read: boolean; link?: string; kind?: string; }
export interface CartItem { id: string; name: string; price: number; qty: number; unit?: string; store?: string; img?: string; }
export interface Address { id: string; label: string; line: string; pincode: string; }
export interface Family { id: string; name: string; relation: string; age?: string; }
export interface TestAttempt { id: string; exam: string; score: number; total: number; at: string; topics: Record<string, { c: number; t: number }>; }
export interface ChatMsg { role: "user" | "ai"; text: string; }
export interface Conversation { id: string; title: string; at: string; msgs: ChatMsg[]; }
export interface JobApp { jobId: string; at: string; status: string; }

export interface AppState {
  lang: Lang; user: User | null; onboarded: boolean; location: string;
  wallet: { balance: number; frozen: boolean; dailyLimit: number; pinSet: boolean; upiLinked: boolean; bankLinked: boolean };
  txns: Txn[]; bookings: Booking[]; grievances: Grievance[]; notifications: Notif[];
  carts: Record<string, CartItem[]>; addresses: Address[]; family: Family[]; favourites: string[];
  savedJobs: string[]; jobApps: JobApp[]; consents: Record<string, boolean>; tests: TestAttempt[];
  conversations: Conversation[]; library: string[]; progress: Record<string, number>; rationLinked: boolean;
  resume?: Record<string, string>; deletionRequested?: boolean; portalRole?: Role; accounts: Record<string, User>;
}

const now = () => new Date().toISOString();
const ago = (h: number) => new Date(Date.now() - h * 3600e3).toISOString();

export const initialState = (): AppState => ({
  lang: "en", user: null, onboarded: false, location: "T. Nagar, Chennai",
  wallet: { balance: 2450, frozen: false, dailyLimit: 10000, pinSet: true, upiLinked: true, bankLinked: true },
  txns: [
    { id: "TXN8F21", at: ago(5), title: "Auto ride – T. Nagar to Guindy", category: "Rides", amount: -142, status: "success", method: "Wallet" },
    { id: "TXN8E10", at: ago(28), title: "Added money via UPI", category: "Add money", amount: 1000, status: "success", method: "UPI" },
    { id: "TXN8D55", at: ago(50), title: "Milk subscription – weekly", category: "Essentials", amount: -196, status: "success", method: "Wallet" },
    { id: "TXN8C02", at: ago(72), title: "Refund – Grocery order item missing", category: "Refunds", amount: 48, status: "refunded", method: "Wallet" },
    { id: "TXN8B90", at: ago(120), title: "Scholarship credit (demo)", category: "Government benefits", amount: 1500, status: "success", method: "Department credit" },
    { id: "TXN8A77", at: ago(160), title: "Cashback – partner offer", category: "Cashback", amount: 25, status: "success", method: "Wallet" },
  ],
  bookings: [
    {
      id: "BK7Q2A", module: "auto", kind: "booking", title: "Auto ride", subtitle: "T. Nagar → Guindy", createdAt: ago(5), amount: 142,
      status: "completed", stages: ["Booked", "Driver assigned", "Driver arriving", "Trip started", "Trip completed"], stageIdx: 4,
      details: { Pickup: "T. Nagar", Drop: "Guindy", Distance: "6.2 km" }, fees: [{ label: "Trip fare", amount: 134 }, { label: "Platform fee", amount: 8 }],
      provider: { name: "Murugan K", rating: 4.8, vehicle: "TN 09 AB 4521" }, payment: "Wallet", rating: 5,
    },
    {
      id: "OR3K9P", module: "grocery", kind: "order", title: "Grocery order", subtitle: "Annachi Stores · 6 items", createdAt: ago(30), amount: 486,
      status: "completed", stages: ["Placed", "Store preparing", "Rider assigned", "Out for delivery", "Delivered"], stageIdx: 4,
      details: { Store: "Annachi Stores, T. Nagar", Slot: "Today, 6–7 PM" }, fees: [{ label: "Items", amount: 456 }, { label: "Delivery fee", amount: 25 }, { label: "Platform fee", amount: 5 }],
      items: [{ name: "Ponni Rice 5kg", qty: 1, price: 320 }, { name: "Toor Dal 1kg", qty: 1, price: 136 }], payment: "Wallet",
    },
  ],
  grievances: [
    {
      id: "GRV10421", service: "Quick Delivery", category: "Missing item", ref: "OR3K9P", description: "One packet of rava was missing from the order.",
      createdAt: ago(70), status: "Resolved",
      history: [
        { status: "Submitted", note: "Complaint registered", at: ago(70) },
        { status: "Assigned", note: "Assigned to Quick Delivery support team", at: ago(69) },
        { status: "Resolved", note: "₹48 refunded to Wallet", at: ago(66) },
      ],
    },
  ],
  notifications: [
    { id: "N1", title: "Welcome to ONETN", body: "One Platform. Every Service. Explore transport, essentials, government services and more.", at: ago(1), read: false, link: "/services" },
    { id: "N2", title: "Ration entitlement available", body: "Your November ration entitlement is ready. Book doorstep delivery or collect from the shop.", at: ago(8), read: false, link: "/services/ration" },
    { id: "N3", title: "TNPSC Group 4 – last date approaching", body: "Application window closes in 5 days. Check eligibility in Jobs.", at: ago(30), read: true, link: "/services/jobs" },
  ],
  carts: {}, addresses: [
    { id: "A1", label: "Home", line: "12, Bazaar Street, T. Nagar, Chennai", pincode: "600017" },
    { id: "A2", label: "Parents' home", line: "4/221, Temple Road, Srirangam, Tiruchirappalli", pincode: "620006" },
  ],
  family: [
    { id: "F1", name: "Lakshmi", relation: "Mother", age: "68" },
    { id: "F2", name: "Kavya", relation: "Daughter", age: "17" },
  ],
  favourites: [], savedJobs: [], jobApps: [], tests: [], conversations: [], library: [], progress: {},
  consents: { location: true, notifications: true, govDataShare: false, schemeSuggestions: true, healthData: false, marketing: false },
  rationLinked: false,
  accounts: { "9876543210": { name: "Priya Raman", mobile: "9876543210", email: "priya.r@example.com", dob: "1990-06-14", address: "12, Bazaar Street, T. Nagar", district: "Chennai", taluk: "Mambalam", city: "Chennai", pincode: "600017", role: "citizen" } },
});

type Ctx = {
  s: AppState; ready: boolean;
  set: (fn: (s: AppState) => AppState) => void;
  t: (k: DictKey) => string; tx: (b: Bi | string) => string;
  login: (u: User) => void; logout: () => void;
  pay: (args: { amount: number; title: string; category: string; method: string; fail?: boolean }) => { ok: boolean; txnId: string; reason?: string };
  addBooking: (b: Omit<Booking, "id" | "createdAt" | "otp"> & { id?: string }) => Booking;
  updateBooking: (id: string, patch: Partial<Booking>) => void;
  notify: (title: string, body: string, link?: string) => void;
  cart: (key: string) => CartItem[];
  setQty: (key: string, item: Omit<CartItem, "qty">, qty: number) => void;
  clearCart: (key: string) => void;
  credit: (amount: number, title: string, category: string, method: string) => void;
  toast: (msg: string, tone?: "success" | "error" | "info") => void;
  toasts: { id: string; msg: string; tone: string }[];
};

const AppCtx = createContext<Ctx | null>(null);
const KEY = "onetn-state-v1";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [s, setS] = useState<AppState>(initialState);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<{ id: string; msg: string; tone: string }[]>([]);
  const first = useRef(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setS({ ...initialState(), ...JSON.parse(raw) });
    } catch {}
    setReady(true);
  }, []);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    if (!ready) return;
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {}
  }, [s, ready]);
  useEffect(() => {
    if (typeof document !== "undefined") document.documentElement.lang = s.lang === "ta" ? "ta" : "en";
  }, [s.lang]);

  const set = useCallback((fn: (s: AppState) => AppState) => setS((p) => fn(p)), []);
  const t = useCallback((k: DictKey) => dict[k]?.[s.lang] ?? String(k), [s.lang]);
  const tx = useCallback((b: Bi | string) => (typeof b === "string" ? b : b[s.lang] || b.en), [s.lang]);

  const toast = useCallback((msg: string, tone: "success" | "error" | "info" = "success") => {
    const id = uid();
    setToasts((x) => [...x, { id, msg, tone }]);
    setTimeout(() => setToasts((x) => x.filter((y) => y.id !== id)), 3200);
  }, []);

  const notify = useCallback((title: string, body: string, link?: string) => {
    set((p) => ({ ...p, notifications: [{ id: uid("N"), title, body, link, at: now(), read: false }, ...p.notifications] }));
  }, [set]);

  const ctx = useMemo<Ctx>(() => ({
    s, ready, set, t, tx, toast, toasts, notify,
    login: (u) => set((p) => ({ ...p, user: u, accounts: { ...p.accounts, [u.mobile]: u } })),
    logout: () => set((p) => ({ ...p, user: null, portalRole: undefined })),
    pay: ({ amount, title, category, method, fail }) => {
      const txnId = uid("TXN");
      let reason: string | undefined;
      if (fail) reason = "Payment declined by bank (simulated failure)";
      else if (method === "Wallet" && s.wallet.frozen) reason = "Wallet is frozen. Unfreeze it in Wallet security settings.";
      else if (method === "Wallet" && s.wallet.balance < amount) reason = "Insufficient Wallet balance. Add money or choose another method.";
      else if (amount > s.wallet.dailyLimit) reason = `Amount exceeds your daily limit of ₹${s.wallet.dailyLimit}.`;
      const ok = !reason;
      set((p) => ({
        ...p,
        wallet: ok && method === "Wallet" ? { ...p.wallet, balance: +(p.wallet.balance - amount).toFixed(2) } : p.wallet,
        txns: [{ id: txnId, at: now(), title, category, amount: -amount, status: ok ? "success" : "failed", method, ref: reason }, ...p.txns],
      }));
      return { ok, txnId, reason };
    },
    credit: (amount, title, category, method) => set((p) => ({
      ...p, wallet: { ...p.wallet, balance: +(p.wallet.balance + amount).toFixed(2) },
      txns: [{ id: uid("TXN"), at: now(), title, category, amount, status: category === "Refunds" ? "refunded" : "success", method }, ...p.txns],
    })),
    addBooking: (b) => {
      const nb: Booking = { ...b, id: b.id ?? uid(b.kind === "order" ? "OR" : "BK"), createdAt: now(), otp: otp4() } as Booking;
      set((p) => ({ ...p, bookings: [nb, ...p.bookings] }));
      return nb;
    },
    updateBooking: (id, patch) => set((p) => ({ ...p, bookings: p.bookings.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
    cart: (key) => s.carts[key] ?? [],
    setQty: (key, item, qty) => set((p) => {
      const list = p.carts[key] ?? [];
      const exists = list.find((x) => x.id === item.id);
      let next: CartItem[];
      if (qty <= 0) next = list.filter((x) => x.id !== item.id);
      else if (exists) next = list.map((x) => (x.id === item.id ? { ...x, qty } : x));
      else next = [...list, { ...item, qty }];
      return { ...p, carts: { ...p.carts, [key]: next } };
    }),
    clearCart: (key) => set((p) => ({ ...p, carts: { ...p.carts, [key]: [] } })),
  }), [s, ready, set, t, tx, toast, toasts, notify]);

  return <AppCtx.Provider value={ctx}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp outside provider");
  return c;
}
