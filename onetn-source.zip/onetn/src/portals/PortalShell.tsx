"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { Menu, X, LogOut, ArrowLeftRight, Bell, Lock, ShieldCheck } from "lucide-react";
import { useApp } from "@/lib/store";
import { Logo } from "@/components/shell/Logo";
import { LangToggle } from "@/components/shell/AuthFrame";
import { Avatar, Badge, Button, Card, Notice } from "@/components/ui";
import { cn } from "@/lib/utils";
import type { Portal, Section } from "./types";

export function PortalShell({ p, section, children }: { p: Portal; section: Section; children: React.ReactNode }) {
  const { s, set, ready, toast, logout } = useApp();
  const path = usePathname();
  const r = useRouter();
  const [open, setOpen] = useState(false);
  if (!ready) return <div className="grid min-h-dvh place-items-center"><span className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" /></div>;
  if (s.portalRole !== p.role)
    return (
      <div className="grid min-h-dvh place-items-center px-4">
        <Card className="max-w-md space-y-4 p-6 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary"><Lock /></span>
          <p className="text-xl font-bold">{p.name}</p>
          <p className="text-sm text-muted">This portal is only available to verified {p.short.toLowerCase()} accounts. Access is role-based – you see only what your role is authorised to view.</p>
          <Button full onClick={() => { if (!s.user) set((x) => ({ ...x, user: x.accounts["9876543210"] })); set((x) => ({ ...x, portalRole: p.role })); toast(`Signed in as ${p.who.name} (demo)`); }}>Sign in with demo {p.short} account</Button>
          <Button full variant="ghost" href="/select-role">Choose another role</Button>
        </Card>
      </div>
    );
  const groups = Array.from(new Set(p.sections.map((x) => x.group ?? "")));
  const nav = (
    <nav className="space-y-4">
      {groups.map((g) => (
        <div key={g}>
          {g && <p className="mb-1 px-3 text-[11px] font-bold uppercase tracking-wider text-muted">{g}</p>}
          <div className="space-y-0.5">
            {p.sections.filter((x) => (x.group ?? "") === g).map((x) => {
              const href = x.id === "overview" ? p.base : `${p.base}/${x.id}`;
              const act = x.id === section.id;
              return <Link key={x.id} href={href} onClick={() => setOpen(false)} className={cn("flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold", act ? "bg-primary text-white" : "text-muted hover:bg-cream hover:text-ink")}><x.icon size={17} />{x.label}{x.restricted && <Lock size={12} className="ml-auto" />}</Link>;
            })}
          </div>
        </div>
      ))}
    </nav>
  );
  return (
    <div className="min-h-dvh lg:flex">
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col overflow-y-auto border-r border-line bg-white px-3 py-5 lg:flex">
        <Link href={p.base} className="px-2"><Logo size={34} /></Link>
        <Badge tone="gold" className="mx-2 mt-3 self-start">{p.name}</Badge>
        <div className="mt-5 flex-1">{nav}</div>
        <div className="mt-4 space-y-1 border-t border-line pt-3">
          <Link href="/select-role" className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-muted hover:bg-cream"><ArrowLeftRight size={16} />Switch role</Link>
          <button onClick={() => { logout(); r.replace("/login"); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-muted hover:bg-cream"><LogOut size={16} />Logout</button>
        </div>
      </aside>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-white p-4">
            <div className="mb-4 flex items-center justify-between"><Logo size={30} /><button aria-label="Close menu" onClick={() => setOpen(false)}><X /></button></div>
            {nav}
            <Link href="/select-role" className="mt-4 flex items-center gap-2 px-3 py-2 text-sm font-semibold text-muted"><ArrowLeftRight size={16} />Switch role</Link>
          </aside>
        </div>
      )}
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-cream/90 px-4 py-3 backdrop-blur sm:px-6">
          <button aria-label="Open menu" onClick={() => setOpen(true)} className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white lg:hidden"><Menu size={19} /></button>
          <div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold text-muted">{p.name}</p><p className="truncate font-bold">{section.title ?? section.label}</p></div>
          <div className="hidden sm:block"><LangToggle /></div>
          <button aria-label="Notifications" onClick={() => toast("No new alerts", "info")} className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white"><Bell size={18} /></button>
          <span className="hidden items-center gap-2 md:flex"><Avatar name={p.who.name} size={38} /><span className="text-sm leading-tight"><b className="block">{p.who.name}</b><span className="text-xs text-muted">{p.who.org}</span></span></span>
        </header>
        <main className={cn("mx-auto w-full px-4 py-5 sm:px-6", p.mobileFirst ? "max-w-3xl" : "max-w-7xl")}>
          {section.sub && <p className="mb-4 text-sm text-muted">{section.sub}</p>}
          {section.restricted ? <Notice tone="warning" title="Access restricted"><span className="flex items-center gap-1"><ShieldCheck size={14} />Your role is not authorised to view this data. Request access from the platform administrator.</span></Notice> : children}
          <p className="mt-8 text-center text-xs text-muted">ONETN · {p.name} · demo data · {path}</p>
        </main>
      </div>
    </div>
  );
}
