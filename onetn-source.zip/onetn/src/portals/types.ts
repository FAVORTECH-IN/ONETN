import type { Role } from "@/lib/store";
export type Icon = React.ComponentType<{ size?: number; className?: string }>;
export type Row = Record<string, string | number> & { id: string };
export type Col = { k: string; label: string; type?: "status" | "money" | "badge" | "rating" | "mask" };
export type FieldDef = { k: string; label: string; type?: "text" | "number" | "select" | "date" | "textarea" | "file" | "time"; options?: string[]; required?: boolean; placeholder?: string };
export type Action = { label: string; to?: string; tone?: "primary" | "outline" | "danger" | "success" | "ghost"; when?: string[]; reason?: boolean; toast?: string; remove?: boolean };
export type Block =
  | { type: "stats"; items: { label: string; value: string; delta?: string; icon?: Icon }[] }
  | { type: "chart"; title: string; kind: "bar" | "line" | "area" | "pie"; data: Record<string, string | number>[]; x: string; series: string[]; span?: 1 | 2; stacked?: boolean }
  | { type: "table"; id: string; title: string; cols: Col[]; rows: Row[]; actions?: Action[]; add?: { label: string; fields: FieldDef[]; defaults?: Record<string, string | number> }; filters?: { k: string; label: string }[]; search?: boolean; export?: boolean; detail?: boolean; editable?: boolean }
  | { type: "form"; id: string; title: string; fields: FieldDef[]; submit: string; success: string; values?: Record<string, string> }
  | { type: "notice"; tone: "info" | "warning" | "success" | "gold" | "error"; title?: string; text: string }
  | { type: "wizard"; id: string; title: string; steps: { title: string; fields: FieldDef[]; docs?: string[] }[]; done: string }
  | { type: "list"; title: string; items: { title: string; sub?: string; right?: string; tone?: string }[] }
  | { type: "custom"; id: string };
export type Section = { id: string; label: string; icon: Icon; title?: string; sub?: string; blocks: Block[]; group?: string; restricted?: boolean };
export type Portal = { id: string; base: string; name: string; short: string; role: Role; who: { name: string; org: string }; sections: Section[]; mobileFirst?: boolean };
