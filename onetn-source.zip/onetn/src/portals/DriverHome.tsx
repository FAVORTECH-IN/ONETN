"use client";
import { useEffect, useState } from "react";
import { Power, Navigation, KeyRound, CheckCircle2, X, Phone, MapPin, IndianRupee, Clock, Siren, Package, Car } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Input, Notice, SimTag, Toggle } from "@/components/ui";
import { MapView } from "@/components/flows/MapView";
import { PLACES } from "@/data/transport";
import { inr } from "@/lib/utils";

type Job = { id: string; type: string; from: string; to: string; km: number; pay: number; customer: string; otp: string; isRide: boolean };
const TYPES = ["Passenger trip", "Parcel", "Grocery order", "Ration delivery", "Milk delivery", "Medicine delivery", "Restaurant order", "Temple prasadam"];
const mk = (n: number): Job => {
  const a = PLACES[n % PLACES.length].name, b = PLACES[(n * 5 + 3) % PLACES.length].name;
  const type = TYPES[n % TYPES.length];
  const km = +(2 + ((n * 37) % 90) / 10).toFixed(1);
  return { id: `JB${6000 + n}`, type, from: a, to: b === a ? "Adyar" : b, km, pay: Math.round(30 + km * (type === "Passenger trip" ? 14 : 10)), customer: ["Priya", "Karthik", "Meena", "Abdul", "Revathi"][n % 5], otp: String(1000 + ((n * 7919) % 9000)), isRide: type === "Passenger trip" };
};
const STEPS = ["Go to pickup", "Verify pickup OTP", "On trip / delivering", "Verify delivery OTP", "Completed"];

export function DriverHome() {
  const { toast } = useApp();
  const [online, setOnline] = useState(false);
  const [n, setN] = useState(1);
  const [offer, setOffer] = useState<Job | null>(null);
  const [left, setLeft] = useState(20);
  const [job, setJob] = useState<Job | null>(null);
  const [step, setStep] = useState(0);
  const [code, setCode] = useState("");
  const [stats, setStats] = useState({ earn: 1240, jobs: 9, mins: 312 });
  useEffect(() => { try { const r = localStorage.getItem("onetn-driver-stats"); if (r) setStats(JSON.parse(r)); } catch {} }, []);
  useEffect(() => { try { localStorage.setItem("onetn-driver-stats", JSON.stringify(stats)); } catch {} }, [stats]);
  useEffect(() => {
    if (!online || offer || job) return;
    const t = setTimeout(() => { setOffer(mk(n)); setN(n + 1); setLeft(20); }, 3500);
    return () => clearTimeout(t);
  }, [online, offer, job, n]);
  useEffect(() => {
    if (!offer) return;
    if (left <= 0) { setOffer(null); toast("Offer expired", "info"); return; }
    const t = setTimeout(() => setLeft(left - 1), 1000);
    return () => clearTimeout(t);
  }, [offer, left, toast]);
  const next = () => {
    if (!job) return;
    if (step === 1 || step === 3) {
      const expect = step === 1 ? job.otp : String(Number(job.otp) + 1).slice(-4);
      if (code !== expect) return toast(`Wrong OTP – ask the ${step === 1 ? (job.isRide ? "passenger" : "store/sender") : "customer"} (demo ${expect})`, "error");
      setCode("");
    }
    if (step === 3) { setStats({ earn: stats.earn + job.pay, jobs: stats.jobs + 1, mins: stats.mins + Math.round(job.km * 4) }); toast(`${inr(job.pay)} added to your Wallet`); }
    setStep(step + 1);
  };
  return (
    <div className="space-y-4">
      <Card className={online ? "border-success" : ""}>
        <div className="flex items-center gap-3">
          <span className={`grid h-12 w-12 place-items-center rounded-2xl ${online ? "bg-success text-white" : "bg-cream text-muted"}`}><Power /></span>
          <div className="flex-1"><p className="font-bold">{online ? "You're online" : "You're offline"}</p><p className="text-sm text-muted">{online ? "Receiving trips, parcels and deliveries nearby" : "Go online to start receiving work"}</p></div>
          <Toggle checked={online} onChange={(v) => { if (!v && job) return toast("Finish the active job first", "error"); setOnline(v); setOffer(null); }} label="Online" />
        </div>
      </Card>
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-3 text-center"><IndianRupee size={18} className="mx-auto text-success" /><p className="mt-1 text-lg font-bold">{inr(stats.earn)}</p><p className="text-xs text-muted">Today</p></Card>
        <Card className="p-3 text-center"><CheckCircle2 size={18} className="mx-auto text-primary" /><p className="mt-1 text-lg font-bold">{stats.jobs}</p><p className="text-xs text-muted">Jobs</p></Card>
        <Card className="p-3 text-center"><Clock size={18} className="mx-auto text-[#8A6A00]" /><p className="mt-1 text-lg font-bold">{Math.floor(stats.mins / 60)}h {stats.mins % 60}m</p><p className="text-xs text-muted">Online</p></Card>
      </div>
      {online && !offer && !job && <Card className="flex items-center gap-3"><span className="h-3 w-3 rounded-full bg-success pulse-dot" /><p className="text-sm">Looking for nearby jobs… <SimTag /></p></Card>}
      {offer && (
        <Card className="fade-in border-primary ring-4 ring-primary/10">
          <div className="flex items-center justify-between"><Badge tone="primary">{offer.type}</Badge><span className="text-sm font-bold text-error">{left}s</span></div>
          <p className="mt-2 text-2xl font-extrabold">{inr(offer.pay)} <span className="text-sm font-normal text-muted">· {offer.km} km</span></p>
          <p className="mt-1 flex items-center gap-1 text-sm"><MapPin size={14} className="text-success" />{offer.from}</p>
          <p className="flex items-center gap-1 text-sm"><MapPin size={14} className="text-primary" />{offer.to}</p>
          <p className="mt-1 text-xs text-muted">Fare shown before you accept · {offer.isRide ? "Customer rating 4.7" : "Pickup from verified partner"}</p>
          <div className="mt-3 grid grid-cols-2 gap-2"><Button variant="outline" onClick={() => { setOffer(null); toast("Declined – no penalty", "info"); }}><X size={16} />Decline</Button><Button variant="success" onClick={() => { setJob(offer); setOffer(null); setStep(0); }}>Accept</Button></div>
        </Card>
      )}
      {job && (
        <Card className="space-y-3">
          <div className="flex items-center justify-between"><Badge tone="primary">{job.isRide ? <Car size={12} /> : <Package size={12} />}{job.type}</Badge><span className="text-sm text-muted">{job.id}</span></div>
          <MapView from={job.from} to={job.to} progress={step >= 2 ? (step >= 4 ? 1 : 0.5) : 0.05} className="h-44" vehicle={job.isRide ? "car" : "bike"} />
          <div className="flex flex-wrap gap-1">{STEPS.map((s, i) => <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-success" : "bg-line"}`} />)}</div>
          <p className="font-bold">{STEPS[step]}</p>
          <p className="text-sm">{step < 2 ? `Pickup: ${job.from}` : `Drop: ${job.to}`} · {job.customer}</p>
          {(step === 1 || step === 3) && <div className="flex items-center gap-2"><KeyRound size={18} className="text-[#8A6A00]" /><Input value={code} onChange={(e) => setCode(e.target.value)} maxLength={4} placeholder={step === 1 ? "Pickup OTP" : "Delivery OTP"} className="h-11" inputMode="numeric" /></div>}
          {(step === 1 || step === 3) && <p className="text-xs text-muted">Demo OTP: {step === 1 ? job.otp : String(Number(job.otp) + 1).slice(-4)}</p>}
          {step < 4 ? (
            <div className="grid grid-cols-[auto_auto_1fr] gap-2">
              <Button variant="outline" aria-label="Call customer" onClick={() => toast("Calling via masked number (simulated)", "info")}><Phone size={16} /></Button>
              <Button variant="outline" aria-label="Navigate" onClick={() => toast("Navigation opens in maps app once integrated", "info")}><Navigation size={16} /></Button>
              <Button onClick={next}>{step === 0 ? "Arrived at pickup" : step === 1 ? "Verify & start" : step === 2 ? "Arrived at drop" : "Verify & complete"}</Button>
            </div>
          ) : (
            <><Notice tone="success" title={`Completed · ${inr(job.pay)} earned`}>Statement added to Earnings. Proof of delivery recorded.</Notice><Button full onClick={() => { setJob(null); setStep(0); }}>Back to jobs</Button></>
          )}
        </Card>
      )}
      <Card className="flex items-center gap-3"><Siren className="text-error" /><p className="flex-1 text-sm">Emergency help is available 24×7.</p><Button size="sm" variant="danger" href="/driver/sos">SOS</Button></Card>
      <Notice tone="info">You can mix passenger trips, parcels, groceries, ration, milk, medicine, restaurant and prasadam deliveries through the day from one registration.</Notice>
    </div>
  );
}

export function SOS() {
  const { toast } = useApp();
  return (
    <div className="space-y-3">
      <Notice tone="error" title="Emergency SOS (simulated)">Alerts the ONETN safety desk with your live location and trip details, and notifies your emergency contact.</Notice>
      <Button full size="lg" variant="danger" onClick={() => toast("Safety desk alerted (simulated)")}><Siren />Send SOS alert</Button>
      <Button full variant="outline" href="tel:112">Call 112</Button>
      <Button full variant="outline" href="tel:108">Ambulance 108</Button>
      <Notice tone="info">Accident insurance claims can be raised from Welfare & insurance.</Notice>
    </div>
  );
}
