"use client";
import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Area, AreaChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Download, Plus, Search, CheckCircle2, Upload, Eye } from "lucide-react";
import { useApp } from "@/lib/store";
import { Badge, Button, Card, Field, Input, KV, Notice, Select, Sheet, Stepper, Textarea, statusTone, Empty } from "@/components/ui";
import { downloadText, inr, toCSV, uid } from "@/lib/utils";
import type { Block, Col, FieldDef, Row } from "./types";

const fmtY = (v: number) => (Math.abs(v) >= 1e7 ? `${+(v / 1e7).toFixed(1)}Cr` : Math.abs(v) >= 1e5 ? `${+(v / 1e5).toFixed(1)}L` : Math.abs(v) >= 1e3 ? `${+(v / 1e3).toFixed(1)}k` : String(v));
const COLORS = ["#8B0000", "#D4AF37", "#218653", "#1D4E89", "#D68A16", "#6B625C", "#5B3A86"];

function usePersist<T>(key: string, init: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(init);
  useEffect(() => { try { const r = localStorage.getItem(key); if (r) setV(JSON.parse(r)); } catch {} }, [key]);
  return [v, (n: T) => { setV(n); try { localStorage.setItem(key, JSON.stringify(n)); } catch {} }];
}

function Cell_({ c, v }: { c: Col; v: string | number | undefined }) {
  if (v === undefined || v === "") return <span className="text-muted">—</span>;
  if (c.type === "status") return <Badge tone={statusTone(String(v))}>{v}</Badge>;
  if (c.type === "badge") return <Badge>{v}</Badge>;
  if (c.type === "money") return <span className="font-semibold tabular-nums">{inr(Number(v))}</span>;
  if (c.type === "rating") return <span className="whitespace-nowrap">★ {v}</span>;
  if (c.type === "mask") return <span className="font-mono text-xs">{String(v).replace(/.(?=.{4})/g, "•")}</span>;
  return <span>{v}</span>;
}

export function FieldInput({ f, value, onChange }: { f: FieldDef; value: string; onChange: (v: string) => void }) {
  if (f.type === "select") return <Select value={value} onChange={(e) => onChange(e.target.value)} options={f.options ?? []} placeholder="Select" />;
  if (f.type === "textarea") return <Textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={f.placeholder} />;
  if (f.type === "file") return (
    <label className="flex cursor-pointer items-center gap-2 rounded-2xl border-2 border-dashed border-line bg-white px-4 py-3 text-sm">
      {value ? <CheckCircle2 size={17} className="text-success" /> : <Upload size={17} className="text-muted" />}<span className="flex-1 truncate">{value || "Upload file"}</span>
      <input type="file" className="hidden" onChange={(e) => onChange(e.target.files?.[0]?.name ?? "")} />
    </label>
  );
  return <Input type={f.type ?? "text"} value={value} placeholder={f.placeholder} onChange={(e) => onChange(e.target.value)} />;
}

function TableBlock({ b, pkey }: { b: Extract<Block, { type: "table" }>; pkey: string }) {
  const { toast } = useApp();
  const [rows, setRows] = usePersist<Row[]>(`onetn-portal-${pkey}-${b.id}`, b.rows);
  const [q, setQ] = useState("");
  const [flt, setFlt] = useState<Record<string, string>>({});
  const [add, setAdd] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});
  const [view, setView] = useState<Row | null>(null);
  const [reason, setReason] = useState<{ row: Row; to: string; label: string } | null>(null);
  const [why, setWhy] = useState("");
  const list = rows.filter((r) => (!q || Object.values(r).join(" ").toLowerCase().includes(q.toLowerCase())) && Object.entries(flt).every(([k, v]) => !v || String(r[k]) === v));
  const statusKey = b.cols.find((c) => c.type === "status")?.k ?? "status";
  const act = (row: Row, to?: string, remove?: boolean, msg?: string, note?: string) => {
    if (remove) setRows(rows.filter((r) => r.id !== row.id));
    else if (to) setRows(rows.map((r) => (r.id === row.id ? { ...r, [statusKey]: to, ...(note ? { note } : {}) } : r)));
    toast(msg ?? `${row.id}: ${to ?? "updated"}`);
  };
  return (
    <Card className="p-0">
      <div className="flex flex-wrap items-center gap-2 border-b border-line p-4">
        <p className="mr-auto font-bold">{b.title} <span className="text-sm font-normal text-muted">({list.length})</span></p>
        {b.search !== false && <div className="relative"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" aria-label={`Search ${b.title}`} className="h-9 w-40 rounded-xl border border-line pl-8 text-sm outline-none focus:border-primary sm:w-52" /></div>}
        {b.filters?.map((f) => (
          <select key={f.k} aria-label={f.label} value={flt[f.k] ?? ""} onChange={(e) => setFlt({ ...flt, [f.k]: e.target.value })} className="h-9 rounded-xl border border-line bg-white px-2 text-sm">
            <option value="">{f.label}: All</option>{Array.from(new Set(rows.map((r) => String(r[f.k])))).map((o) => <option key={o}>{o}</option>)}
          </select>
        ))}
        {b.export !== false && <Button size="sm" variant="outline" onClick={() => downloadText(`${b.id}.csv`, toCSV(list), "text/csv")}><Download size={14} />Export</Button>}
        {b.add && <Button size="sm" onClick={() => { setForm(Object.fromEntries(Object.entries(b.add!.defaults ?? {}).map(([k, v]) => [k, String(v)]))); setAdd(true); }}><Plus size={14} />{b.add.label}</Button>}
      </div>
      {list.length === 0 ? <div className="p-6"><Empty title="No records" body="Try clearing search or filters." /></div> : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-cream/70 text-left text-xs uppercase tracking-wide text-muted"><tr>{b.cols.map((c) => <th key={c.k} className="px-4 py-2.5 font-semibold">{c.label}</th>)}{(b.actions?.length || b.detail) && <th className="px-4 py-2.5 text-right font-semibold">Actions</th>}</tr></thead>
            <tbody className="divide-y divide-line">
              {list.map((r) => (
                <tr key={r.id} className="hover:bg-cream/40">
                  {b.cols.map((c) => <td key={c.k} className="px-4 py-3"><Cell_ c={c} v={r[c.k]} /></td>)}
                  {(b.actions?.length || b.detail) && (
                    <td className="px-4 py-2 text-right"><div className="flex justify-end gap-1.5">
                      {b.detail !== false && <button aria-label="View" onClick={() => setView(r)} className="grid h-8 w-8 place-items-center rounded-lg border border-line bg-white"><Eye size={15} /></button>}
                      {b.actions?.filter((a) => !a.when || a.when.includes(String(r[statusKey]))).map((a) => (
                        <Button key={a.label} size="sm" variant={a.tone ?? "outline"} className="h-8 px-2.5 text-xs" onClick={() => (a.reason ? setReason({ row: r, to: a.to!, label: a.label }) : act(r, a.to, a.remove, a.toast))}>{a.label}</Button>
                      ))}
                    </div></td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Sheet open={add} onClose={() => setAdd(false)} title={b.add?.label} footer={<Button full onClick={() => {
        const miss = b.add!.fields.find((f) => f.required && !form[f.k]); if (miss) return toast(`Fill “${miss.label}”`, "error");
        const row: Row = { id: uid(b.id.slice(0, 2).toUpperCase()), ...Object.fromEntries(b.cols.map((c) => [c.k, ""])), ...form } as Row;
        b.cols.forEach((c) => { if (c.type === "money" || c.type === "rating") row[c.k] = Number(row[c.k] || 0); });
        setRows([row, ...rows]); setAdd(false); toast("Saved");
      }}>Save</Button>}>
        <div className="space-y-3">{b.add?.fields.map((f) => <Field key={f.k} label={f.label} required={f.required}><FieldInput f={f} value={form[f.k] ?? ""} onChange={(v) => setForm({ ...form, [f.k]: v })} /></Field>)}</div>
      </Sheet>
      <Sheet open={!!view} onClose={() => setView(null)} title={`Record ${view?.id ?? ""}`}>
        {view && <><KV rows={Object.entries(view).map(([k, v]) => [b.cols.find((c) => c.k === k)?.label ?? k, String(v)])} />
          {b.actions && <div className="mt-4 flex flex-wrap gap-2">{b.actions.filter((a) => !a.when || a.when.includes(String(view[statusKey]))).map((a) => <Button key={a.label} size="sm" variant={a.tone ?? "outline"} onClick={() => { if (a.reason) setReason({ row: view, to: a.to!, label: a.label }); else act(view, a.to, a.remove, a.toast); setView(null); }}>{a.label}</Button>)}</div>}</>}
      </Sheet>
      <Sheet open={!!reason} onClose={() => setReason(null)} title={`${reason?.label} – reason required`} footer={<Button full variant="danger" disabled={why.trim().length < 5} onClick={() => { act(reason!.row, reason!.to, false, undefined, why); setReason(null); setWhy(""); }}>Confirm</Button>}>
        <p className="mb-2 text-sm text-muted">The reason is shared with the person concerned, who can appeal.</p>
        <Textarea value={why} onChange={(e) => setWhy(e.target.value)} placeholder="Reason" />
      </Sheet>
    </Card>
  );
}

function ChartBlock({ b }: { b: Extract<Block, { type: "chart" }> }) {
  return (
    <Card className={b.span === 2 ? "lg:col-span-2" : ""}>
      <p className="mb-3 font-bold">{b.title}</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          {b.kind === "pie" ? (
            <PieChart><Pie data={b.data} dataKey={b.series[0]} nameKey={b.x} innerRadius={55} outerRadius={90} paddingAngle={2}>{b.data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart>
          ) : b.kind === "line" ? (
            <LineChart data={b.data}><CartesianGrid strokeDasharray="3 3" stroke="#E9DED2" /><XAxis dataKey={b.x} tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={44} tickFormatter={fmtY} /><Tooltip />{b.series.length > 1 && <Legend />}{b.series.map((s, i) => <Line key={s} dataKey={s} stroke={COLORS[i]} strokeWidth={2.5} dot={false} />)}</LineChart>
          ) : b.kind === "area" ? (
            <AreaChart data={b.data}><CartesianGrid strokeDasharray="3 3" stroke="#E9DED2" /><XAxis dataKey={b.x} tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={44} tickFormatter={fmtY} /><Tooltip />{b.series.map((s, i) => <Area key={s} dataKey={s} stroke={COLORS[i]} fill={COLORS[i]} fillOpacity={0.15} strokeWidth={2} />)}</AreaChart>
          ) : (
            <BarChart data={b.data}><CartesianGrid strokeDasharray="3 3" stroke="#E9DED2" vertical={false} /><XAxis dataKey={b.x} tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={44} tickFormatter={fmtY} /><Tooltip cursor={{ fill: "#F9F1E7" }} />{b.series.length > 1 && <Legend />}{b.series.map((s, i) => <Bar key={s} dataKey={s} fill={COLORS[i]} radius={[6, 6, 0, 0]} stackId={b.stacked ? "a" : undefined} />)}</BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </Card>
  );
}

function FormBlock({ b, pkey }: { b: Extract<Block, { type: "form" }>; pkey: string }) {
  const { toast } = useApp();
  const [v, setV] = usePersist<Record<string, string>>(`onetn-portal-${pkey}-${b.id}`, b.values ?? {});
  const [draft, setDraft] = useState(v);
  useEffect(() => setDraft(v), [v]);
  return (
    <Card>
      <p className="mb-3 font-bold">{b.title}</p>
      <div className="grid gap-3 sm:grid-cols-2">{b.fields.map((f) => <div key={f.k} className={f.type === "textarea" ? "sm:col-span-2" : ""}><Field label={f.label} required={f.required}><FieldInput f={f} value={draft[f.k] ?? ""} onChange={(x) => setDraft({ ...draft, [f.k]: x })} /></Field></div>)}</div>
      <Button className="mt-4" onClick={() => { const m = b.fields.find((f) => f.required && !draft[f.k]); if (m) return toast(`Fill “${m.label}”`, "error"); setV(draft); toast(b.success); }}>{b.submit}</Button>
    </Card>
  );
}

function WizardBlock({ b, pkey }: { b: Extract<Block, { type: "wizard" }>; pkey: string }) {
  const { toast } = useApp();
  const [st, setSt] = usePersist<{ step: number; vals: Record<string, string>; status?: string }>(`onetn-portal-${pkey}-${b.id}`, { step: 0, vals: {} });
  const s = b.steps[st.step];
  if (st.status) return (
    <Card className="space-y-3">
      <p className="font-bold">{b.title}</p>
      <div className="flex items-center gap-3 rounded-2xl bg-success-soft p-4 text-success"><CheckCircle2 /><div><p className="font-semibold">{st.status}</p><p className="text-sm">{b.done}</p></div></div>
      <ol className="space-y-2 text-sm">{["Submitted", "Document verification", "Background / licence check", "Training", "Approved"].map((x, i) => <li key={x} className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${i < (st.status === "Approved" ? 5 : 2) ? "bg-success" : "bg-line"}`} />{x}</li>)}</ol>
      <div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => { setSt({ ...st, status: "Approved" }); toast("Verification approved (simulated)"); }}>Simulate approval</Button><Button size="sm" variant="ghost" onClick={() => setSt({ step: 0, vals: {} })}>Edit details</Button></div>
    </Card>
  );
  return (
    <Card className="space-y-4">
      <p className="font-bold">{b.title}</p>
      <Stepper steps={b.steps.map((x) => x.title)} current={st.step} />
      <p className="font-semibold">{s.title}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {s.fields.map((f) => <Field key={f.k} label={f.label} required={f.required}><FieldInput f={f} value={st.vals[f.k] ?? ""} onChange={(x) => setSt({ ...st, vals: { ...st.vals, [f.k]: x } })} /></Field>)}
        {s.docs?.map((d) => <Field key={d} label={d} required><FieldInput f={{ k: d, label: d, type: "file" }} value={st.vals[d] ?? ""} onChange={(x) => setSt({ ...st, vals: { ...st.vals, [d]: x } })} /></Field>)}
      </div>
      <div className="flex gap-2">
        {st.step > 0 && <Button variant="outline" onClick={() => setSt({ ...st, step: st.step - 1 })}>Back</Button>}
        <Button onClick={() => {
          const m = s.fields.find((f) => f.required && !st.vals[f.k]) ?? (s.docs?.find((d) => !st.vals[d]) ? { label: s.docs.find((d) => !st.vals[d])! } : null);
          if (m) return toast(`Fill “${m.label}”`, "error");
          if (st.step < b.steps.length - 1) setSt({ ...st, step: st.step + 1 }); else { setSt({ ...st, status: "Under verification" }); toast("Submitted for verification"); }
        }}>{st.step < b.steps.length - 1 ? "Continue" : "Submit for verification"}</Button>
      </div>
    </Card>
  );
}

export function Blocks({ blocks, pkey, custom }: { blocks: Block[]; pkey: string; custom?: Record<string, React.ReactNode> }) {
  const grid = useMemo(() => blocks, [blocks]);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {grid.map((b, i) => {
        if (b.type === "stats") return (
          <div key={i} className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:col-span-2 xl:grid-cols-4">
            {b.items.map((s) => (
              <Card key={s.label} className="p-4">
                <div className="flex items-center justify-between">{s.icon && <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary-soft text-primary"><s.icon size={17} /></span>}{s.delta && <span className={`text-xs font-semibold ${s.delta.startsWith("-") ? "text-error" : "text-success"}`}>{s.delta}</span>}</div>
                <p className="mt-2 text-2xl font-extrabold tabular-nums">{s.value}</p><p className="text-xs text-muted">{s.label}</p>
              </Card>
            ))}
          </div>
        );
        if (b.type === "chart") return <ChartBlock key={i} b={b} />;
        if (b.type === "table") return <div key={i} className="lg:col-span-2"><TableBlock b={b} pkey={pkey} /></div>;
        if (b.type === "form") return <div key={i} className="lg:col-span-2"><FormBlock b={b} pkey={pkey} /></div>;
        if (b.type === "wizard") return <div key={i} className="lg:col-span-2"><WizardBlock b={b} pkey={pkey} /></div>;
        if (b.type === "notice") return <div key={i} className="lg:col-span-2"><Notice tone={b.tone} title={b.title}>{b.text}</Notice></div>;
        if (b.type === "list") return (
          <Card key={i} className="p-0"><p className="border-b border-line px-4 py-3 font-bold">{b.title}</p>
            <ul className="divide-y divide-line">{b.items.map((x) => <li key={x.title} className="flex items-center gap-3 px-4 py-3 text-sm"><div className="flex-1"><p className="font-semibold">{x.title}</p>{x.sub && <p className="text-xs text-muted">{x.sub}</p>}</div>{x.right && <Badge tone={statusTone(x.tone ?? x.right)}>{x.right}</Badge>}</li>)}</ul></Card>
        );
        if (b.type === "custom") return <div key={i} className="lg:col-span-2">{custom?.[b.id] ?? null}</div>;
        return null;
      })}
    </div>
  );
}
