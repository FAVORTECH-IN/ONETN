"use client";
import { useEffect, useMemo, useState } from "react";
import { CalendarRange, Filter, Building2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { Card, Select, Notice, Empty, Button } from "@/components/ui";
import { DISTRICTS8 } from "./mock";
import { PortalShell } from "./PortalShell";
import { Blocks } from "./Blocks";
import { DriverHome, SOS } from "./DriverHome";
import { DRIVER, PROFESSIONAL, MERCHANT, RESTAURANT, TEMPLE, EDUCATION, HEALTH, EMPLOYER } from "./configs/partners";
import { DEPARTMENT, ADMIN } from "./configs/gov";
import type { Block, Portal } from "./types";

export const PORTALS: Record<string, Portal> = { driver: DRIVER, professional: PROFESSIONAL, merchant: MERCHANT, restaurant: RESTAURANT, temple: TEMPLE, education: EDUCATION, healthcare: HEALTH, employer: EMPLOYER, department: DEPARTMENT, admin: ADMIN };

const DEPT_VIEWS = ["Civil Supplies & Consumer Protection", "Steering committee (all modules)", "Transport Department", "HR&CE Department"];
const DEPT_ALLOW: Record<string, string[] | "all"> = {
  "Civil Supplies & Consumer Protection": ["overview", "districts", "applications", "ration", "essentials", "milk", "medicine", "uzhavar", "grievances", "delivery", "schemes", "reports", "consent", "audit"],
  "Steering committee (all modules)": "all",
  "Transport Department": ["overview", "districts", "transport", "grievances", "delivery", "reports", "consent", "audit"],
  "HR&CE Department": ["overview", "districts", "temples", "grievances", "reports", "consent", "audit"],
};

function scaleBlocks(blocks: Block[], f: number): Block[] {
  if (f === 1) return blocks;
  const sc = (v: string) => v.replace(/[\d,]+(\.\d+)?/, (m) => { const n = parseFloat(m.replace(/,/g, "")); if (isNaN(n)) return m; const r = n * f; return m.includes(".") ? r.toFixed(1) : Math.round(r).toLocaleString("en-IN"); });
  return blocks.map((b) => {
    if (b.type === "stats") return { ...b, items: b.items.map((i) => (/[%★]|days|min|Same day|h /.test(i.value) ? i : { ...i, value: sc(i.value) })) };
    if (b.type === "chart") return { ...b, data: b.data.map((d) => Object.fromEntries(Object.entries(d).map(([k, v]) => [k, typeof v === "number" && !k.includes("%") ? Math.round(v * f) : v]))) };
    return b;
  });
}

export function PortalPage({ portal, section }: { portal: string; section?: string }) {
  const p = PORTALS[portal];
  const { toast } = useApp();
  const [range, setRange] = useState("This month");
  const [dist, setDist] = useState("All districts");
  const [dept, setDept] = useState("All departments");
  const [view, setView] = useState(DEPT_VIEWS[0]);
  useEffect(() => { try { const v = localStorage.getItem("onetn-dept-view"); if (v) setView(v); } catch {} }, []);
  const sec = p.sections.find((x) => x.id === (section ?? "overview")) ?? p.sections[0];
  const factor = (range === "Today" ? 0.04 : range === "This week" ? 0.24 : range === "Last 6 months" ? 5.6 : 1) * (dist === "All districts" ? 1 : 0.14 + (DISTRICTS8.indexOf(dist) % 4) * 0.03) * (dept === "All departments" ? 1 : 0.35);
  const isGov = portal === "department" || portal === "admin";
  const allowed = portal === "department" ? DEPT_ALLOW[view] : "all";
  const portalSections = useMemo(() => (portal === "department" ? { ...p, sections: p.sections.map((x) => ({ ...x, restricted: allowed !== "all" && !allowed.includes(x.id) })) } : p), [p, portal, allowed]);
  const shownSec = portalSections.sections.find((x) => x.id === sec.id)!;
  const filters = (
    <div className="space-y-3">
      {portal === "department" && (
        <Card className="flex flex-wrap items-center gap-3 p-3">
          <Building2 size={18} className="text-primary" /><span className="text-sm font-semibold">Viewing as</span>
          <Select className="h-10 w-auto" value={view} onChange={(e) => { setView(e.target.value); localStorage.setItem("onetn-dept-view", e.target.value); toast(`Role switched – data limited to ${e.target.value}`, "info"); }} options={DEPT_VIEWS} />
          <span className="text-xs text-muted">Demo of role-based access: each department sees only its authorised data.</span>
        </Card>
      )}
      <Card className="flex flex-wrap items-center gap-2 p-3">
        <Filter size={16} className="text-muted" />
        <span className="flex items-center gap-1 text-sm"><CalendarRange size={15} /></span>
        <Select aria-label="Date range" className="h-10 w-auto" value={range} onChange={(e) => setRange(e.target.value)} options={["Today", "This week", "This month", "Last 6 months"]} />
        <Select aria-label="District" className="h-10 w-auto" value={dist} onChange={(e) => setDist(e.target.value)} options={["All districts", ...DISTRICTS8]} />
        {portal === "admin" && <Select aria-label="Department" className="h-10 w-auto" value={dept} onChange={(e) => setDept(e.target.value)} options={["All departments", "Transport", "Civil Supplies", "Cooperation", "Health", "HR&CE", "Revenue", "Labour"]} />}
        <Button size="sm" variant="ghost" onClick={() => { setRange("This month"); setDist("All districts"); setDept("All departments"); }}>Reset</Button>
      </Card>
    </div>
  );
  const custom = { "driver-home": <DriverHome />, sos: <SOS />, filters };
  if (!p) return <Empty title="Portal not found" />;
  return (
    <PortalShell p={portalSections} section={shownSec}>
      {isGov && !shownSec.blocks.some((b) => b.type === "custom") && <div className="mb-4">{filters}</div>}
      <Blocks key={`${sec.id}-${factor}`} blocks={isGov ? scaleBlocks(shownSec.blocks, factor) : shownSec.blocks} pkey={`${portal}-${sec.id}`} custom={custom} />
      {isGov && factor !== 1 && <Notice tone="info" className="mt-4">Filters applied: {range} · {dist}{portal === "admin" ? ` · ${dept}` : ""}. Figures are simulated.</Notice>}
    </PortalShell>
  );
}
