// Section ids per portal (kept server-safe for generateStaticParams)
import { DRIVER, PROFESSIONAL, MERCHANT, RESTAURANT, TEMPLE, EDUCATION, HEALTH, EMPLOYER } from "./configs/partners";
import { DEPARTMENT, ADMIN } from "./configs/gov";
const ids = (p: { sections: { id: string }[] }) => p.sections.map((s) => s.id).filter((x) => x !== "overview");
export const PORTAL_SECTIONS: Record<string, string[]> = {
  driver: ids(DRIVER), professional: ids(PROFESSIONAL), merchant: ids(MERCHANT), restaurant: ids(RESTAURANT), temple: ids(TEMPLE),
  education: ids(EDUCATION), healthcare: ids(HEALTH), employer: ids(EMPLOYER), department: ids(DEPARTMENT), admin: ids(ADMIN),
};
