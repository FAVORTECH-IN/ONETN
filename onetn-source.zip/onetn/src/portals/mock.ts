export const rows = <T extends Record<string, string | number>>(n: number, f: (i: number) => T) => Array.from({ length: n }, (_, i) => ({ id: "", ...f(i) })).map((r, i) => ({ ...r, id: (r as { id?: string }).id || `R${1001 + i}` }));
export const pick = <T,>(a: T[], i: number) => a[i % a.length];
export const NAMES = ["Priya Raman", "Karthik S", "Meena Lakshmi", "Abdul Kareem", "Revathi M", "Suresh Kumar", "Anitha J", "Mohammed Riyaz", "Deepa R", "Vignesh P", "Lakshmi N", "Joseph A", "Gowri S", "Senthil V", "Fathima B", "Rajesh K"];
export const AREAS = ["T. Nagar", "Adyar", "Velachery", "Anna Nagar", "Mylapore", "Tambaram", "Porur", "Guindy"];
export const DISTRICTS8 = ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Vellore", "Thanjavur"];
export const MONTHS = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov"];
export const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
export const dateAgo = (d: number) => new Date(Date.now() - d * 864e5).toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
export const series = (keys: string[], labels: string[], base: number[], jitter = 0.18) =>
  labels.map((l, i) => ({ [keys[0] === "_" ? "x" : "x"]: l, ...Object.fromEntries(keys.map((k, j) => [k, Math.round(base[j] * (1 + i * 0.07) * (1 + Math.sin(i * 1.7 + j) * jitter))])) }));
