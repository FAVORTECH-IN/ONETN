import {
  Bus, Car, Landmark, GraduationCap, HeartPulse, Briefcase, FileText, Store, MoreHorizontal, Bike, Package, ShoppingBasket,
  Wheat, Milk, Pill, Sprout, ShoppingCart, Wrench, Sparkles, UtensilsCrossed, TrainFront, Brain, BookOpen, ClipboardCheck,
  Stethoscope, HandHeart, Wallet, Flame, CalendarCheck, Truck, MessageCircleQuestion,
} from "lucide-react";
import type { Bi } from "@/lib/i18n";

export type Svc = { id: string; name: Bi; href: string; icon: React.ComponentType<{ size?: number; className?: string }>; group: string; desc: Bi; tone?: number };

export const SERVICES: Svc[] = [
  { id: "bus", name: { en: "Bus Booking", ta: "பேருந்து முன்பதிவு" }, href: "/services/bus-booking", icon: Bus, group: "Mobility & Transport", desc: { en: "Government buses & SETC", ta: "அரசு பேருந்துகள் & SETC" }, tone: 0 },
  { id: "cab", name: { en: "Rapido / Cab", ta: "ரேபிடோ / கார்" }, href: "/services/cab-booking", icon: Car, group: "Mobility & Transport", desc: { en: "Bike, auto & cab at standard fares", ta: "நிலையான கட்டணத்தில் பயணம்" }, tone: 1 },
  { id: "government", name: { en: "Government Services", ta: "அரசு சேவைகள்" }, href: "/services/government", icon: Landmark, group: "Government", desc: { en: "Certificates, pensions, schemes", ta: "சான்றிதழ், ஓய்வூதியம், திட்டங்கள்" }, tone: 3 },
  { id: "education", name: { en: "Education", ta: "கல்வி" }, href: "/services/education", icon: GraduationCap, group: "Education & Health", desc: { en: "Library, AI guide, mock tests", ta: "நூலகம், AI வழிகாட்டி, தேர்வுகள்" }, tone: 5 },
  { id: "healthcare", name: { en: "Healthcare", ta: "மருத்துவம்" }, href: "/services/healthcare", icon: HeartPulse, group: "Education & Health", desc: { en: "Doctor appointments", ta: "மருத்துவர் சந்திப்பு" }, tone: 2 },
  { id: "jobs", name: { en: "Jobs", ta: "வேலைகள்" }, href: "/services/jobs", icon: Briefcase, group: "Employment", desc: { en: "Government & private jobs", ta: "அரசு & தனியார் வேலைகள்" }, tone: 4 },
  { id: "grievance", name: { en: "Grievance", ta: "குறைதீர்ப்பு" }, href: "/grievance", icon: FileText, group: "Support", desc: { en: "Raise & track complaints", ta: "புகார் அளி & கண்காணி" }, tone: 0 },
  { id: "local", name: { en: "Local Services", ta: "உள்ளூர் சேவைகள்" }, href: "/services/home-services", icon: Store, group: "Home Services", desc: { en: "Verified home professionals", ta: "சரிபார்க்கப்பட்ட நிபுணர்கள்" }, tone: 1 },
  { id: "auto", name: { en: "Auto Booking", ta: "ஆட்டோ முன்பதிவு" }, href: "/services/auto-booking", icon: Car, group: "Mobility & Transport", desc: { en: "Auto at the approved fare", ta: "அங்கீகரிக்கப்பட்ட கட்டணம்" }, tone: 4 },
  { id: "metro", name: { en: "Metro & Public Transport", ta: "மெட்ரோ & பொதுப் போக்குவரத்து" }, href: "/services/transport", icon: TrainFront, group: "Mobility & Transport", desc: { en: "Metro, Chennai One, journey planner", ta: "மெட்ரோ, சென்னை ஒன்" }, tone: 3 },
  { id: "parcel", name: { en: "Parcels", ta: "பார்சல்" }, href: "/services/parcels", icon: Package, group: "Mobility & Transport", desc: { en: "Small, medium & large parcels", ta: "சிறிய முதல் பெரிய பார்சல்" }, tone: 6 },
  { id: "quick", name: { en: "Quick Delivery", ta: "விரைவு விநியோகம்" }, href: "/services/quick-delivery", icon: ShoppingBasket, group: "Delivery", desc: { en: "Groceries & daily needs", ta: "மளிகை & தினசரி தேவைகள்" }, tone: 2 },
  { id: "essentials", name: { en: "Door-to-Door Essentials", ta: "வீடு தேடி அத்தியாவசியம்" }, href: "/services/essentials", icon: Truck, group: "Delivery", desc: { en: "Ration, milk, medicines, produce", ta: "ரேஷன், பால், மருந்து" }, tone: 1 },
  { id: "ration", name: { en: "Ration Delivery", ta: "ரேஷன் விநியோகம்" }, href: "/services/ration", icon: Wheat, group: "Delivery", desc: { en: "Monthly entitlement at home", ta: "மாதாந்திர உரிமை வீட்டிற்கு" }, tone: 4 },
  { id: "milk", name: { en: "Milk Subscription", ta: "பால் சந்தா" }, href: "/services/milk", icon: Milk, group: "Delivery", desc: { en: "Daily cooperative milk", ta: "தினசரி கூட்டுறவு பால்" }, tone: 3 },
  { id: "medicine", name: { en: "Medicine Delivery", ta: "மருந்து விநியோகம்" }, href: "/services/medicines", icon: Pill, group: "Delivery", desc: { en: "Pharmacist-verified delivery", ta: "மருந்தாளர் சரிபார்ப்புடன்" }, tone: 0 },
  { id: "uzhavar", name: { en: "Uzhavar Sandhai", ta: "உழவர் சந்தை" }, href: "/services/uzhavar-sandhai", icon: Sprout, group: "Delivery", desc: { en: "Fresh from farmers", ta: "விவசாயிகளிடமிருந்து நேரடியாக" }, tone: 2 },
  { id: "coop", name: { en: "Co-op Supermarkets", ta: "கூட்டுறவு அங்காடி" }, href: "/services/essentials/cooperative", icon: ShoppingCart, group: "Delivery", desc: { en: "Government & cooperative stores", ta: "அரசு & கூட்டுறவு கடைகள்" }, tone: 5 },
  { id: "home", name: { en: "Home Services", ta: "வீட்டுச் சேவைகள்" }, href: "/services/home-services", icon: Wrench, group: "Home Services", desc: { en: "Electrician, plumber, cleaning…", ta: "மின், குழாய், சுத்தம்…" }, tone: 6 },
  { id: "beauty", name: { en: "Salon at Home", ta: "வீட்டில் அழகு நிலையம்" }, href: "/services/home-services/beautician", icon: Sparkles, group: "Home Services", desc: { en: "Verified beauticians", ta: "சரிபார்க்கப்பட்ட அழகுக் கலைஞர்கள்" }, tone: 5 },
  { id: "food", name: { en: "Food & Restaurants", ta: "உணவு & உணவகங்கள்" }, href: "/services/food", icon: UtensilsCrossed, group: "Food", desc: { en: "Delivery, takeaway, tables", ta: "விநியோகம், எடுத்துச்செல், மேஜை" }, tone: 0 },
  { id: "temples", name: { en: "Temple Services", ta: "கோயில் சேவைகள்" }, href: "/services/temples", icon: Flame, group: "Temple", desc: { en: "Archana, seva, prasadam", ta: "அர்ச்சனை, சேவை, பிரசாதம்" }, tone: 1 },
  { id: "library", name: { en: "Learning Library", ta: "கற்றல் நூலகம்" }, href: "/services/education/library", icon: BookOpen, group: "Education & Health", desc: { en: "Textbooks, notes, videos", ta: "பாடநூல், குறிப்புகள், வீடியோ" }, tone: 3 },
  { id: "ai", name: { en: "AI Study Guide", ta: "AI படிப்பு வழிகாட்டி" }, href: "/services/education/ai-guide", icon: Brain, group: "Education & Health", desc: { en: "Ask in Tamil or English", ta: "தமிழ் அல்லது ஆங்கிலத்தில் கேளுங்கள்" }, tone: 5 },
  { id: "mock", name: { en: "Mock Tests", ta: "மாதிரித் தேர்வுகள்" }, href: "/services/education/mock-tests", icon: ClipboardCheck, group: "Education & Health", desc: { en: "Timed tests with analysis", ta: "நேர வரம்புடன் தேர்வுகள்" }, tone: 4 },
  { id: "counsel", name: { en: "Teachers & Counsellors", ta: "ஆசிரியர் & ஆலோசகர்" }, href: "/services/education/counselling", icon: HandHeart, group: "Education & Health", desc: { en: "Book sessions", ta: "அமர்வு முன்பதிவு" }, tone: 2 },
  { id: "doctor", name: { en: "Doctor Consultation", ta: "மருத்துவர் ஆலோசனை" }, href: "/services/healthcare", icon: Stethoscope, group: "Education & Health", desc: { en: "In-person or video", ta: "நேரில் அல்லது வீடியோ" }, tone: 0 },
  { id: "wallet", name: { en: "Wallet", ta: "வாலட்" }, href: "/wallet", icon: Wallet, group: "Support", desc: { en: "Pay, refunds, benefits", ta: "கட்டணம், திருப்பம், உதவித்தொகை" }, tone: 1 },
  { id: "bookings", name: { en: "My Bookings", ta: "என் முன்பதிவுகள்" }, href: "/bookings", icon: CalendarCheck, group: "Support", desc: { en: "Track everything", ta: "அனைத்தையும் கண்காணி" }, tone: 3 },
  { id: "help", name: { en: "Help & Support", ta: "உதவி & ஆதரவு" }, href: "/support", icon: MessageCircleQuestion, group: "Support", desc: { en: "FAQ, chat, call", ta: "கேள்விகள், அரட்டை, அழைப்பு" }, tone: 6 },
  { id: "bike", name: { en: "Bike Taxi", ta: "பைக் டாக்ஸி" }, href: "/services/cab-booking?type=bike", icon: Bike, group: "Mobility & Transport", desc: { en: "Quick solo rides", ta: "விரைவான தனிப் பயணம்" }, tone: 2 },
];

export const HOME_GRID = ["bus", "cab", "government", "education", "healthcare", "jobs", "grievance", "local"];
export const svc = (id: string) => SERVICES.find((s) => s.id === id)!;
export { MoreHorizontal };

export const DISTRICTS = [
  "Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram",
  "Kanniyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai",
  "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi", "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli",
  "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar",
];
const TALUKS: Record<string, string[]> = {
  Chennai: ["Egmore", "Guindy", "Mylapore", "Tondiarpet", "Ambattur", "Velachery", "Perambur", "Mambalam", "Sholinganallur", "Alandur"],
  Coimbatore: ["Coimbatore North", "Coimbatore South", "Pollachi", "Mettupalayam", "Sulur", "Annur", "Valparai"],
  Madurai: ["Madurai North", "Madurai South", "Melur", "Thirumangalam", "Usilampatti", "Vadipatti"],
  Tiruchirappalli: ["Srirangam", "Tiruchirappalli West", "Lalgudi", "Manapparai", "Musiri", "Thuraiyur"],
  Salem: ["Salem", "Attur", "Omalur", "Mettur", "Edappadi", "Sankari"],
  Tirunelveli: ["Tirunelveli", "Palayamkottai", "Ambasamudram", "Nanguneri", "Radhapuram"],
};
export const taluksOf = (d: string) => TALUKS[d] ?? [`${d} North`, `${d} South`, `${d} East`, `${d} West`];

export const ROLES: { id: import("@/lib/store").Role; name: string; ta: string; href: string; desc: string }[] = [
  { id: "citizen", name: "Citizen", ta: "குடிமகன்", href: "/home", desc: "Book, order, apply, learn and find work" },
  { id: "driver", name: "Driver / Delivery Partner", ta: "ஓட்டுநர் / விநியோகப் பங்குதாரர்", href: "/driver", desc: "Trips, parcels and deliveries" },
  { id: "professional", name: "Home Service Professional", ta: "வீட்டுச் சேவை நிபுணர்", href: "/professional", desc: "Take home-service jobs" },
  { id: "merchant", name: "Store / Supermarket", ta: "கடை / அங்காடி", href: "/merchant", desc: "List products and fulfil orders" },
  { id: "restaurant", name: "Restaurant Partner", ta: "உணவக பங்குதாரர்", href: "/restaurant", desc: "Menu, orders and settlements" },
  { id: "temple", name: "Temple Administration", ta: "கோயில் நிர்வாகம்", href: "/temple-admin", desc: "Sevas, prasadam and bookings" },
  { id: "education", name: "Education Partner / Teacher", ta: "கல்விப் பங்குதாரர் / ஆசிரியர்", href: "/education-partner", desc: "Courses, content and sessions" },
  { id: "healthcare", name: "Healthcare Professional", ta: "மருத்துவ நிபுணர்", href: "/healthcare-partner", desc: "Appointments and consultations" },
  { id: "employer", name: "Employer / Recruiter", ta: "முதலாளி", href: "/employer", desc: "Post jobs and hire" },
  { id: "department", name: "Government Department", ta: "அரசுத் துறை", href: "/department", desc: "Reports and oversight" },
  { id: "admin", name: "Super Admin", ta: "தலைமை நிர்வாகி", href: "/admin", desc: "Platform administration" },
];
