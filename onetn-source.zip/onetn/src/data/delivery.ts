export type Product = { id: string; name: string; ta?: string; cat: string; price: number; mrp?: number; unit: string; hue: number; desc?: string; veg?: boolean; stock?: number };
export type StoreT = { id: string; name: string; type: "Neighbourhood store" | "Supermarket" | "Government / cooperative store"; area: string; km: number; eta: number; rating: number; open: string; hue: number; tags: string[] };

export const QUICK_CATS = ["Groceries", "Fruits", "Vegetables", "Dairy", "Bakery", "Household", "Cleaning", "Personal care", "Stationery", "School supplies"];

export const STORES: StoreT[] = [
  { id: "annachi", name: "Annachi Stores", type: "Neighbourhood store", area: "T. Nagar", km: 0.8, eta: 18, rating: 4.6, open: "7 AM – 10 PM", hue: 1, tags: ["Groceries", "Dairy", "Household"] },
  { id: "freshmart", name: "Fresh Mart Supermarket", type: "Supermarket", area: "Ashok Nagar", km: 1.9, eta: 25, rating: 4.4, open: "8 AM – 11 PM", hue: 2, tags: ["Fruits", "Vegetables", "Bakery", "Personal care"] },
  { id: "kamadhenu", name: "Kamadhenu Co-op Supermarket", type: "Government / cooperative store", area: "Mylapore", km: 2.6, eta: 35, rating: 4.3, open: "9 AM – 8 PM", hue: 4, tags: ["Groceries", "Cleaning", "Stationery"] },
  { id: "saraswathi", name: "Saraswathi Book & Stationery", type: "Neighbourhood store", area: "West Mambalam", km: 1.2, eta: 22, rating: 4.7, open: "9 AM – 9 PM", hue: 3, tags: ["Stationery", "School supplies"] },
];

export const PRODUCTS: Product[] = [
  { id: "p1", name: "Ponni Raw Rice", ta: "பொன்னி அரிசி", cat: "Groceries", price: 320, mrp: 345, unit: "5 kg", hue: 1, desc: "Aged Ponni rice, ideal for daily meals." },
  { id: "p2", name: "Toor Dal", ta: "துவரம் பருப்பு", cat: "Groceries", price: 136, mrp: 150, unit: "1 kg", hue: 4 },
  { id: "p3", name: "Groundnut Oil (cold-pressed)", ta: "கடலை எண்ணெய்", cat: "Groceries", price: 215, unit: "1 L", hue: 4 },
  { id: "p4", name: "Idli Rice", ta: "இட்லி அரிசி", cat: "Groceries", price: 78, unit: "1 kg", hue: 1 },
  { id: "p5", name: "Banana – Poovan", ta: "பூவன் வாழைப்பழம்", cat: "Fruits", price: 48, unit: "1 dozen", hue: 4 },
  { id: "p6", name: "Apple – Shimla", ta: "ஆப்பிள்", cat: "Fruits", price: 160, unit: "1 kg", hue: 0 },
  { id: "p7", name: "Tomato", ta: "தக்காளி", cat: "Vegetables", price: 32, unit: "1 kg", hue: 0 },
  { id: "p8", name: "Onion (small)", ta: "சின்ன வெங்காயம்", cat: "Vegetables", price: 70, unit: "1 kg", hue: 5 },
  { id: "p9", name: "Drumstick", ta: "முருங்கைக்காய்", cat: "Vegetables", price: 24, unit: "250 g", hue: 2 },
  { id: "p10", name: "Toned Milk", ta: "பால்", cat: "Dairy", price: 27, unit: "500 ml", hue: 3 },
  { id: "p11", name: "Curd", ta: "தயிர்", cat: "Dairy", price: 35, unit: "500 g", hue: 3 },
  { id: "p12", name: "Ghee", ta: "நெய்", cat: "Dairy", price: 330, unit: "500 ml", hue: 4 },
  { id: "p13", name: "Milk Bread", ta: "ரொட்டி", cat: "Bakery", price: 45, unit: "400 g", hue: 4 },
  { id: "p14", name: "Rusk", cat: "Bakery", price: 40, unit: "300 g", hue: 4 },
  { id: "p15", name: "Dishwash Bar", cat: "Cleaning", price: 30, unit: "3 × 150 g", hue: 2 },
  { id: "p16", name: "Floor Cleaner", cat: "Cleaning", price: 115, unit: "1 L", hue: 3 },
  { id: "p17", name: "Detergent Powder", cat: "Household", price: 99, unit: "1 kg", hue: 3 },
  { id: "p18", name: "Mosquito Coil", cat: "Household", price: 42, unit: "10 coils", hue: 2 },
  { id: "p19", name: "Herbal Soap", cat: "Personal care", price: 120, unit: "4 × 100 g", hue: 2 },
  { id: "p20", name: "Coconut Hair Oil", cat: "Personal care", price: 95, unit: "200 ml", hue: 4 },
  { id: "p21", name: "Long Notebook (172 pages)", cat: "Stationery", price: 55, unit: "1 pc", hue: 3 },
  { id: "p22", name: "Ball Pens (blue)", cat: "Stationery", price: 50, unit: "Pack of 10", hue: 3 },
  { id: "p23", name: "Geometry Box", cat: "School supplies", price: 85, unit: "1 set", hue: 5 },
  { id: "p24", name: "School Bag", cat: "School supplies", price: 599, mrp: 799, unit: "1 pc", hue: 0 },
];
export const COUPONS = [
  { code: "FIRST50", desc: "₹50 off on first quick-delivery order above ₹299 (partner-funded)", off: 50, min: 299 },
  { code: "FREEDEL", desc: "Free delivery on orders above ₹199", off: 25, min: 199 },
];

// Door-to-door essentials
export const RATION_CARD = { number: "33XXXXXXXX1234", type: "PHH – Priority Household (demo)", head: "Priya Raman", members: 4, shop: "FPS No. 0412, T. Nagar", shopCode: "TN-CHN-0412" };
export const RATION_ITEMS = [
  { id: "r1", name: "Rice", ta: "அரிசி", ent: 20, unit: "kg", price: 0, note: "As per scheme" },
  { id: "r2", name: "Sugar", ta: "சர்க்கரை", ent: 2, unit: "kg", price: 25, note: "As per scheme" },
  { id: "r3", name: "Toor Dal", ta: "துவரம் பருப்பு", ent: 1, unit: "kg", price: 30, note: "As per scheme" },
  { id: "r4", name: "Palmolein Oil", ta: "பாமாயில்", ent: 1, unit: "L", price: 25, note: "As per scheme" },
  { id: "r5", name: "Wheat", ta: "கோதுமை", ent: 5, unit: "kg", price: 0, note: "As per scheme" },
];

export const MILK_PRODUCTS = [
  { id: "m1", name: "Toned Milk (Blue)", unit: "500 ml", price: 22, hue: 3 },
  { id: "m2", name: "Standardised Milk (Green)", unit: "500 ml", price: 22, hue: 2 },
  { id: "m3", name: "Full Cream Milk (Orange)", unit: "500 ml", price: 30, hue: 4 },
  { id: "m4", name: "Curd", unit: "500 g", price: 30, hue: 3 },
  { id: "m5", name: "Buttermilk", unit: "200 ml", price: 8, hue: 2 },
];

export const PHARMACIES = [
  { id: "ph1", name: "Government Medical Store – T. Nagar", type: "Government-run", km: 1.1, eta: 40, rating: 4.4, pharmacist: "Reg. Pharmacist R. Kalaivani" },
  { id: "ph2", name: "Amman Pharmacy", type: "Licensed pharmacy", km: 0.6, eta: 30, rating: 4.6, pharmacist: "Reg. Pharmacist S. Ganesh" },
  { id: "ph3", name: "Co-optex Medicals (Cooperative)", type: "Cooperative pharmacy", km: 2.4, eta: 50, rating: 4.3, pharmacist: "Reg. Pharmacist M. Hameed" },
];
export const MEDICINES = [
  { id: "md1", name: "Paracetamol 500 mg", form: "Strip of 15 tablets", price: 18, rx: false, generic: null, use: "Fever and mild pain" },
  { id: "md2", name: "Metformin 500 mg (Brand)", form: "Strip of 15 tablets", price: 62, rx: true, generic: { name: "Metformin 500 mg (Generic)", price: 21 }, use: "Type 2 diabetes – prescription required" },
  { id: "md3", name: "Amlodipine 5 mg (Brand)", form: "Strip of 15 tablets", price: 58, rx: true, generic: { name: "Amlodipine 5 mg (Generic)", price: 16 }, use: "Blood pressure – prescription required" },
  { id: "md4", name: "ORS Sachet", form: "Pack of 5", price: 25, rx: false, generic: null, use: "Rehydration" },
  { id: "md5", name: "Cetirizine 10 mg", form: "Strip of 10 tablets", price: 20, rx: false, generic: null, use: "Allergy relief" },
  { id: "md6", name: "Atorvastatin 10 mg (Brand)", form: "Strip of 10 tablets", price: 95, rx: true, generic: { name: "Atorvastatin 10 mg (Generic)", price: 28 }, use: "Cholesterol – prescription required" },
  { id: "md7", name: "Vitamin D3 60K", form: "Pack of 4 capsules", price: 120, rx: true, generic: null, use: "Deficiency – prescription required" },
  { id: "md8", name: "Antiseptic Liquid", form: "250 ml", price: 89, rx: false, generic: null, use: "First aid" },
];

export const MARKETS = [
  { id: "us1", name: "Uzhavar Sandhai – K.K. Nagar", district: "Chennai", farmers: 42, km: 3.1 },
  { id: "us2", name: "Uzhavar Sandhai – Pallavaram", district: "Chengalpattu", farmers: 36, km: 9.4 },
  { id: "us3", name: "Uzhavar Sandhai – R.S. Puram", district: "Coimbatore", farmers: 58, km: 0 },
  { id: "us4", name: "Uzhavar Sandhai – Anna Nagar", district: "Madurai", farmers: 47, km: 0 },
];
export const FARMERS = [
  { id: "fm1", name: "Ramasamy P", village: "Tiruvallur", crops: "Tomato, brinjal, greens", rating: 4.8, years: 22 },
  { id: "fm2", name: "Valliammal S", village: "Kanchipuram", crops: "Banana, drumstick, beans", rating: 4.9, years: 15 },
  { id: "fm3", name: "Karthik M", village: "Chengalpattu", crops: "Organic greens, cucumber", rating: 4.7, years: 6 },
];
export const PRODUCE = [
  { id: "u1", name: "Tomato (Nattu)", unit: "1 kg", price: 26, farmer: "fm1", hue: 0, cat: "Vegetables" },
  { id: "u2", name: "Brinjal", unit: "1 kg", price: 34, farmer: "fm1", hue: 5, cat: "Vegetables" },
  { id: "u3", name: "Arai Keerai (Greens)", unit: "1 bunch", price: 12, farmer: "fm3", hue: 2, cat: "Vegetables" },
  { id: "u4", name: "Cucumber", unit: "500 g", price: 18, farmer: "fm3", hue: 2, cat: "Vegetables" },
  { id: "u5", name: "Beans", unit: "500 g", price: 30, farmer: "fm2", hue: 2, cat: "Vegetables" },
  { id: "u6", name: "Banana – Rasthali", unit: "1 dozen", price: 55, farmer: "fm2", hue: 4, cat: "Fruits" },
  { id: "u7", name: "Papaya", unit: "1 pc (~1 kg)", price: 35, farmer: "fm2", hue: 4, cat: "Fruits" },
  { id: "u8", name: "Guava", unit: "500 g", price: 30, farmer: "fm3", hue: 2, cat: "Fruits" },
];
export const BUNDLES = [
  { id: "b1", name: "Family Vegetable Box", desc: "Tomato 1 kg, brinjal 500 g, beans 500 g, greens 2 bunches, onion 1 kg", price: 149, serves: "Family of 4 · 3 days" },
  { id: "b2", name: "Sambar Kit", desc: "Drumstick, brinjal, small onion, tomato, ash gourd", price: 89, serves: "4 servings" },
  { id: "b3", name: "Fruit Basket", desc: "Banana, papaya, guava – seasonal", price: 129, serves: "Family of 4" },
];
export const COOP_STORES = [
  { id: "c1", name: "Kamadhenu Co-op Supermarket", area: "Mylapore", hue: 4 },
  { id: "c2", name: "Amudham Departmental Store", area: "Anna Nagar", hue: 1 },
  { id: "c3", name: "Pallavan Co-op Store", area: "Tambaram", hue: 3 },
];
export const COOP_PRODUCTS: Product[] = [
  { id: "c-p1", name: "Ponni Rice (Co-op brand)", cat: "Groceries", price: 285, mrp: 320, unit: "5 kg", hue: 1 },
  { id: "c-p2", name: "Urad Dal", cat: "Groceries", price: 118, mrp: 135, unit: "1 kg", hue: 4 },
  { id: "c-p3", name: "Gingelly Oil", cat: "Groceries", price: 290, mrp: 320, unit: "1 L", hue: 4 },
  { id: "c-p4", name: "Tea Powder", cat: "Groceries", price: 125, mrp: 140, unit: "250 g", hue: 0 },
  { id: "c-p5", name: "Handloom Towel", cat: "Household", price: 99, mrp: 140, unit: "1 pc", hue: 3 },
  { id: "c-p6", name: "Washing Soap", cat: "Cleaning", price: 54, mrp: 60, unit: "4 × 200 g", hue: 2 },
  { id: "c-p7", name: "Notebook Bundle", cat: "Stationery", price: 220, mrp: 260, unit: "6 notebooks", hue: 3 },
  { id: "c-p8", name: "Rava", cat: "Groceries", price: 44, mrp: 50, unit: "500 g", hue: 4 },
];
export const SLOTS = ["7 – 8 AM", "8 – 9 AM", "10 – 11 AM", "12 – 1 PM", "4 – 5 PM", "6 – 7 PM", "7 – 8 PM"];
