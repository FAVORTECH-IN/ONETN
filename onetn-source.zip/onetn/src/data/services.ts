import { Zap, Droplets, Hammer, BrickWall, PaintRoller, AirVent, WashingMachine, SprayCan, Bug, Trash2, Sparkles, Scissors, Syringe, HeartHandshake, Flower2, Truck, Drill } from "lucide-react";

export const HOME_CATS = [
  { id: "electrician", name: "Electrician", ta: "மின் பணியாளர்", icon: Zap, group: "Repairs & maintenance", visit: 99 },
  { id: "plumber", name: "Plumber", ta: "குழாய் பணியாளர்", icon: Droplets, group: "Repairs & maintenance", visit: 99 },
  { id: "carpenter", name: "Carpenter", ta: "தச்சர்", icon: Hammer, group: "Repairs & maintenance", visit: 99 },
  { id: "mason", name: "Mason", ta: "கொத்தனார்", icon: BrickWall, group: "Repairs & maintenance", visit: 149 },
  { id: "painter", name: "Painter", ta: "வர்ணம் பூசுபவர்", icon: PaintRoller, group: "Repairs & maintenance", visit: 149 },
  { id: "ac-repair", name: "AC Repair", ta: "ஏசி பழுது", icon: AirVent, group: "Repairs & maintenance", visit: 199 },
  { id: "appliance", name: "Appliance Repair", ta: "சாதன பழுது", icon: WashingMachine, group: "Repairs & maintenance", visit: 149 },
  { id: "cleaning", name: "Home Cleaning", ta: "வீட்டு சுத்தம்", icon: SprayCan, group: "Cleaning & pest control", visit: 0 },
  { id: "pest", name: "Pest Control", ta: "பூச்சிக் கட்டுப்பாடு", icon: Bug, group: "Cleaning & pest control", visit: 0 },
  { id: "sanitation", name: "Sanitation", ta: "சுகாதாரப் பணி", icon: Trash2, group: "Cleaning & pest control", visit: 0 },
  { id: "beautician", name: "Beautician", ta: "அழகுக் கலைஞர்", icon: Sparkles, group: "Beauty & wellness", visit: 0 },
  { id: "salon", name: "Home Salon", ta: "வீட்டு சலூன்", icon: Scissors, group: "Beauty & wellness", visit: 0 },
  { id: "nurse", name: "Home Nurse", ta: "வீட்டு செவிலியர்", icon: Syringe, group: "Health at home", visit: 0 },
  { id: "attendant", name: "Care Attendant", ta: "பராமரிப்பாளர்", icon: HeartHandshake, group: "Health at home", visit: 0 },
  { id: "gardening", name: "Gardening", ta: "தோட்டப் பணி", icon: Flower2, group: "Other household help", visit: 99 },
  { id: "moving", name: "Moving Assistance", ta: "இடமாற்ற உதவி", icon: Truck, group: "Other household help", visit: 0 },
  { id: "installation", name: "Installation Services", ta: "பொருத்தும் சேவை", icon: Drill, group: "Other household help", visit: 99 },
];

export const RATE_CARDS: Record<string, { item: string; price: number; time: string }[]> = {
  electrician: [{ item: "Switch / socket replacement", price: 79, time: "30 min" }, { item: "Fan installation", price: 149, time: "45 min" }, { item: "Tube light / LED fitting", price: 99, time: "30 min" }, { item: "MCB / fuse repair", price: 199, time: "45 min" }, { item: "Inverter installation", price: 449, time: "1.5 hr" }],
  plumber: [{ item: "Tap repair / replacement", price: 99, time: "30 min" }, { item: "Leak fixing (pipe joint)", price: 149, time: "45 min" }, { item: "Wash basin installation", price: 399, time: "1.5 hr" }, { item: "Drain blockage removal", price: 249, time: "1 hr" }, { item: "Overhead tank cleaning", price: 599, time: "2 hr" }],
  carpenter: [{ item: "Door lock repair", price: 149, time: "45 min" }, { item: "Hinge / handle fixing", price: 99, time: "30 min" }, { item: "Furniture assembly (per item)", price: 349, time: "1.5 hr" }, { item: "Cupboard repair", price: 249, time: "1 hr" }],
  mason: [{ item: "Wall crack filling (per sq ft)", price: 35, time: "Estimate" }, { item: "Tile replacement (per tile)", price: 120, time: "Estimate" }, { item: "Plastering (per sq ft)", price: 45, time: "Estimate" }],
  painter: [{ item: "Room painting (1 BHK, labour)", price: 4500, time: "2 days" }, { item: "Wall touch-up", price: 799, time: "4 hr" }, { item: "Waterproofing inspection", price: 299, time: "1 hr" }],
  "ac-repair": [{ item: "AC service (split)", price: 499, time: "1 hr" }, { item: "Gas refill (estimate after check)", price: 1999, time: "1.5 hr" }, { item: "AC installation", price: 1299, time: "2 hr" }],
  appliance: [{ item: "Washing machine repair (visit + diagnosis)", price: 249, time: "1 hr" }, { item: "Refrigerator repair (visit + diagnosis)", price: 249, time: "1 hr" }, { item: "Mixer grinder repair", price: 199, time: "45 min" }, { item: "RO water purifier service", price: 349, time: "1 hr" }],
  cleaning: [{ item: "Bathroom deep clean", price: 449, time: "1.5 hr" }, { item: "Kitchen deep clean", price: 1199, time: "3 hr" }, { item: "Full home deep clean (2 BHK)", price: 3499, time: "6 hr" }, { item: "Sofa cleaning (5 seats)", price: 799, time: "1.5 hr" }],
  pest: [{ item: "Cockroach treatment (2 BHK)", price: 999, time: "1 hr" }, { item: "Termite inspection", price: 0, time: "45 min" }, { item: "Mosquito fogging", price: 699, time: "45 min" }],
  sanitation: [{ item: "Septic tank cleaning (licensed)", price: 2499, time: "2 hr" }, { item: "Garbage clearance (per load)", price: 699, time: "1 hr" }],
  beautician: [{ item: "Facial (classic)", price: 699, time: "1 hr" }, { item: "Threading (eyebrows)", price: 49, time: "10 min" }, { item: "Bridal makeup (trial)", price: 2999, time: "2 hr" }, { item: "Mehendi (both hands)", price: 799, time: "1.5 hr" }],
  salon: [{ item: "Haircut (men)", price: 199, time: "30 min" }, { item: "Haircut (women)", price: 399, time: "45 min" }, { item: "Hair colour (root touch-up)", price: 699, time: "1 hr" }, { item: "Manicure & pedicure", price: 899, time: "1.5 hr" }],
  nurse: [{ item: "Nursing visit (injection, dressing)", price: 399, time: "45 min" }, { item: "12-hour day nursing", price: 1499, time: "12 hr" }, { item: "Post-hospital care (per day)", price: 1999, time: "24 hr" }],
  attendant: [{ item: "Elderly care attendant (12 hr)", price: 999, time: "12 hr" }, { item: "Patient attendant (24 hr)", price: 1599, time: "24 hr" }],
  gardening: [{ item: "Garden maintenance (per visit)", price: 399, time: "2 hr" }, { item: "Plant potting (per 5 pots)", price: 249, time: "1 hr" }],
  moving: [{ item: "Packing & moving help (2 people, 4 hr)", price: 1499, time: "4 hr" }, { item: "Loading / unloading only", price: 799, time: "2 hr" }],
  installation: [{ item: "TV wall mount", price: 399, time: "45 min" }, { item: "Curtain rod installation", price: 199, time: "30 min" }, { item: "Geyser installation", price: 449, time: "1 hr" }],
};

const names = ["Senthil Kumar", "Meenakshi S", "Abdul Rahman", "Karthikeyan V", "Lakshmi Priya", "Joseph Antony", "Revathi M", "Vignesh R"];
export const professionalsFor = (cat: string) =>
  names.slice(0, 4 + (cat.length % 3)).map((n, i) => ({
    id: `${cat}-${i}`, name: (cat === "beautician" || cat === "nurse" || cat === "salon") && i % 2 === 0 ? ["Meenakshi S", "Lakshmi Priya", "Revathi M", "Divya N"][i % 4] : n,
    rating: +(4.9 - (i % 4) * 0.1).toFixed(1), jobs: 120 + i * 87 + cat.length * 11, years: 3 + ((i * 3 + cat.length) % 15),
    certs: i % 2 === 0 ? ["Skill certification (TNSDC – demo)", "Background verified"] : ["Background verified"],
    langs: i % 3 === 0 ? "Tamil, English" : "Tamil", nextSlot: ["Today 4 PM", "Today 6 PM", "Tomorrow 9 AM", "Tomorrow 11 AM"][i % 4],
    team: i === 3 ? "Women's collective – Sakthi SHG" : undefined, regNo: cat === "nurse" ? `TNNMC/RN/${40210 + i}` : undefined,
  }));

// ---------- Government services ----------
export type Level = "Guided access" | "Connected" | "Fully integrated";
export type GovSvc = { id: string; name: string; ta: string; dept: string; area: string; level: Level; time: string; fee: string; eligibility: string[]; docs: string[]; fields: { k: string; label: string; type?: "text" | "select" | "date" | "number"; options?: string[] }[]; family?: boolean };
export const DEPARTMENTS = [
  "Revenue & Disaster Management", "Civil Supplies & Consumer Protection", "Social Welfare & Women Empowerment",
  "Adi Dravidar & Tribal Welfare", "Backward Classes Welfare", "Welfare of Differently Abled Persons", "School Education", "Higher Education",
];
export const GOV_SERVICES: GovSvc[] = [
  { id: "community-cert", name: "Community / Caste Certificate", ta: "சாதிச் சான்றிதழ்", dept: "Revenue & Disaster Management", area: "Certificates", level: "Connected", time: "Up to 30 days (per department)", fee: "As set by the department", eligibility: ["Resident of Tamil Nadu", "Applicant or parent belongs to the community claimed"], docs: ["Aadhaar / identity proof", "Address proof", "Parent's community certificate or school record", "Passport-size photo"], fields: [{ k: "community", label: "Community claimed" }, { k: "father", label: "Father's / guardian's name" }, { k: "religion", label: "Religion", type: "select", options: ["Hindu", "Muslim", "Christian", "Other"] }] },
  { id: "cert-correction", name: "Certificate Correction / Change", ta: "சான்றிதழ் திருத்தம்", dept: "Revenue & Disaster Management", area: "Certificates", level: "Connected", time: "15–30 days", fee: "As set by the department", eligibility: ["Holder of an existing certificate issued in Tamil Nadu"], docs: ["Existing certificate", "Proof supporting the correction (e.g., school record)", "Identity proof"], fields: [{ k: "certNo", label: "Existing certificate number" }, { k: "field", label: "Field to correct", type: "select", options: ["Name", "Father's name", "Community", "Address", "Date of birth"] }, { k: "correct", label: "Correct value" }] },
  { id: "income-cert", name: "Income Certificate", ta: "வருமானச் சான்றிதழ்", dept: "Revenue & Disaster Management", area: "Certificates", level: "Fully integrated", time: "Up to 15 days", fee: "As set by the department", eligibility: ["Resident of Tamil Nadu"], docs: ["Identity proof", "Address proof", "Salary slip / self-declaration of income"], fields: [{ k: "income", label: "Annual family income (₹)", type: "number" }, { k: "occupation", label: "Occupation" }] },
  { id: "nativity-cert", name: "Nativity Certificate", ta: "இருப்பிடச் சான்றிதழ்", dept: "Revenue & Disaster Management", area: "Certificates", level: "Guided access", time: "Per department", fee: "As set by the department", eligibility: ["Born or residing in Tamil Nadu as per rules"], docs: ["Birth certificate", "School records", "Address proof"], fields: [{ k: "birthplace", label: "Place of birth" }] },
  { id: "ration-new", name: "New Ration (Smart) Card", ta: "புதிய ரேஷன் அட்டை", dept: "Civil Supplies & Consumer Protection", area: "Ration card services", level: "Connected", time: "Per department", fee: "As set by the department", eligibility: ["Family not holding another ration card in Tamil Nadu"], docs: ["Aadhaar of all members", "Address proof", "Photo of family head"], fields: [{ k: "cardType", label: "Card type requested", type: "select", options: ["PHH", "NPHH", "NPHH-S", "AAY (as eligible)"] }, { k: "gas", label: "LPG connection number (if any)" }], family: true },
  { id: "ration-correction", name: "Ration Card Correction", ta: "ரேஷன் அட்டை திருத்தம்", dept: "Civil Supplies & Consumer Protection", area: "Ration card services", level: "Connected", time: "Per department", fee: "As set by the department", eligibility: ["Existing ration card holder"], docs: ["Ration card", "Proof of correct details"], fields: [{ k: "card", label: "Ration card number" }, { k: "field", label: "Detail to correct", type: "select", options: ["Name", "Address", "Head of family", "Fair price shop change"] }, { k: "correct", label: "Correct value" }] },
  { id: "ration-member", name: "Add / Remove Family Member", ta: "குடும்ப உறுப்பினர் சேர்/நீக்கம்", dept: "Civil Supplies & Consumer Protection", area: "Ration card services", level: "Connected", time: "Per department", fee: "As set by the department", eligibility: ["Existing ration card holder"], docs: ["Ration card", "Aadhaar of member", "Marriage / birth / death certificate as applicable"], fields: [{ k: "card", label: "Ration card number" }, { k: "action", label: "Action", type: "select", options: ["Add member", "Remove member"] }, { k: "member", label: "Member name" }, { k: "reason", label: "Reason", type: "select", options: ["Birth", "Marriage", "Death", "Migration", "Other"] }], family: true },
  { id: "oap", name: "Old-Age Pension", ta: "முதியோர் ஓய்வூதியம்", dept: "Social Welfare & Women Empowerment", area: "Pensions", level: "Connected", time: "Per department", fee: "No fee", eligibility: ["Age as per scheme rules", "Income criteria as per scheme", "Resident of Tamil Nadu"], docs: ["Age proof", "Income certificate", "Bank passbook", "Photo"], fields: [{ k: "age", label: "Age", type: "number" }, { k: "bank", label: "Bank account (last 4 digits)" }] },
  { id: "widow", name: "Widow Pension", ta: "விதவை ஓய்வூதியம்", dept: "Social Welfare & Women Empowerment", area: "Pensions", level: "Connected", time: "Per department", fee: "No fee", eligibility: ["As per scheme rules"], docs: ["Death certificate of spouse", "Income certificate", "Bank passbook"], fields: [{ k: "spouse", label: "Spouse's name" }, { k: "bank", label: "Bank account (last 4 digits)" }] },
  { id: "disability", name: "Disability Pension", ta: "மாற்றுத்திறனாளி ஓய்வூதியம்", dept: "Welfare of Differently Abled Persons", area: "Pensions", level: "Guided access", time: "Per department", fee: "No fee", eligibility: ["UDID / disability certificate as per scheme"], docs: ["Disability certificate / UDID card", "Income certificate", "Bank passbook"], fields: [{ k: "udid", label: "UDID number" }, { k: "pct", label: "Disability %", type: "number" }] },
  { id: "marriage-assist", name: "Marriage Assistance Scheme", ta: "திருமண உதவித் திட்டம்", dept: "Social Welfare & Women Empowerment", area: "Welfare schemes", level: "Guided access", time: "Per department", fee: "No fee", eligibility: ["As per scheme rules"], docs: ["Marriage invitation / certificate", "Education certificate", "Income certificate"], fields: [{ k: "date", label: "Marriage date", type: "date" }] },
  { id: "scholarship-pm", name: "Post-Matric Scholarship", ta: "மேல்நிலைக் கல்வி உதவித்தொகை", dept: "Adi Dravidar & Tribal Welfare", area: "Scholarships", level: "Connected", time: "Per academic calendar", fee: "No fee", eligibility: ["Student in a recognised institution", "Community & income as per scheme"], docs: ["Community certificate", "Income certificate", "Bonafide certificate", "Mark sheet"], fields: [{ k: "inst", label: "Institution name" }, { k: "course", label: "Course" }, { k: "year", label: "Year of study", type: "select", options: ["1", "2", "3", "4", "5"] }] },
  { id: "scholarship-bc", name: "BC / MBC Scholarship", ta: "பிற்படுத்தப்பட்டோர் உதவித்தொகை", dept: "Backward Classes Welfare", area: "Scholarships", level: "Guided access", time: "Per academic calendar", fee: "No fee", eligibility: ["As per scheme rules"], docs: ["Community certificate", "Income certificate", "Bonafide certificate"], fields: [{ k: "inst", label: "Institution name" }] },
  { id: "first-grad", name: "First Graduate Certificate", ta: "முதல் பட்டதாரி சான்றிதழ்", dept: "Revenue & Disaster Management", area: "Certificates", level: "Fully integrated", time: "Up to 15 days", fee: "As set by the department", eligibility: ["No graduate in the family as per rules"], docs: ["Family declaration", "Ration card", "School certificates"], fields: [{ k: "course", label: "Course applying for" }] },
];

// ---------- Temples ----------
export const TEMPLES = [
  { id: "meenakshi", name: "Arulmigu Meenakshi Sundareswarar Temple", ta: "அருள்மிகு மீனாட்சி சுந்தரேசுவரர் திருக்கோயில்", district: "Madurai", deity: "Meenakshi Amman & Sundareswarar", timings: "5:00 AM – 12:30 PM, 4:00 PM – 9:30 PM", hue: 4, booking: true },
  { id: "srirangam", name: "Arulmigu Ranganathaswamy Temple", ta: "அருள்மிகு ரங்கநாதசுவாமி திருக்கோயில்", district: "Tiruchirappalli", deity: "Sri Ranganathar", timings: "6:00 AM – 1:00 PM, 3:00 PM – 9:00 PM", hue: 1, booking: true },
  { id: "palani", name: "Arulmigu Dhandayuthapani Swamy Temple", ta: "அருள்மிகு தண்டாயுதபாணி சுவாமி திருக்கோயில்", district: "Dindigul", deity: "Lord Murugan", timings: "6:00 AM – 8:00 PM", hue: 0, booking: true },
  { id: "kapaleeshwarar", name: "Arulmigu Kapaleeshwarar Temple", ta: "அருள்மிகு கபாலீசுவரர் திருக்கோயில்", district: "Chennai", deity: "Kapaleeshwarar & Karpagambal", timings: "5:30 AM – 12:00 PM, 4:00 PM – 9:30 PM", hue: 2, booking: true },
  { id: "thiruchendur", name: "Arulmigu Subramaniya Swamy Temple", ta: "அருள்மிகு சுப்பிரமணிய சுவாமி திருக்கோயில்", district: "Thoothukudi", deity: "Lord Murugan", timings: "5:00 AM – 9:00 PM", hue: 3, booking: true },
  { id: "rameswaram", name: "Arulmigu Ramanathaswamy Temple", ta: "அருள்மிகு ராமநாதசுவாமி திருக்கோயில்", district: "Ramanathapuram", deity: "Sri Ramanathaswamy", timings: "5:00 AM – 1:00 PM, 3:00 PM – 9:00 PM", hue: 5, booking: false },
];
export const SEVAS = [
  { id: "archana", name: "Archana", fee: 10, needs: ["name", "star"], slots: ["6:30 AM", "8:00 AM", "10:00 AM", "5:00 PM", "7:00 PM"] },
  { id: "sahasranama", name: "Sahasranama Archana", fee: 100, needs: ["name", "star", "gotra"], slots: ["7:00 AM", "6:00 PM"] },
  { id: "abhishekam", name: "Abhishekam", fee: 500, needs: ["name", "star", "gotra"], slots: ["6:00 AM"] },
  { id: "special-darshan", name: "Special Darshan Ticket", fee: 100, needs: ["name"], slots: ["7:00 AM", "9:00 AM", "11:00 AM", "5:00 PM", "7:00 PM"] },
  { id: "annadhanam", name: "Annadhanam Contribution", fee: 250, needs: ["name"], slots: ["Any day"] },
];
export const PRASADAM = [
  { id: "laddu", name: "Laddu", unit: "Pack of 2", price: 50, shelf: "7 days" },
  { id: "panchamirtham", name: "Panchamirtham", unit: "500 g tin", price: 80, shelf: "30 days (sealed)" },
  { id: "vibhuti", name: "Vibhuti & Kumkum", unit: "Packet", price: 20, shelf: "12 months" },
  { id: "adhirasam", name: "Adhirasam", unit: "Pack of 4", price: 60, shelf: "5 days" },
];
export const STARS = ["Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashirsha", "Ardra", "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"];
export const FESTIVALS = [
  { temple: "meenakshi", name: "Chithirai Thiruvizha", when: "April – May", note: "Celestial wedding; bookings limited on main days" },
  { temple: "srirangam", name: "Vaikunta Ekadasi", when: "December – January", note: "Paramapadha Vasal opening; online bookings closed on the day" },
  { temple: "palani", name: "Thai Poosam", when: "January – February", note: "Heavy pilgrim rush; prasadam delivery delays expected" },
  { temple: "kapaleeshwarar", name: "Panguni Peruvizha", when: "March – April", note: "Arupathu Moovar procession" },
  { temple: "thiruchendur", name: "Kanda Sashti", when: "October – November", note: "Soorasamharam on the sixth day" },
  { temple: "rameswaram", name: "Maha Shivaratri", when: "February – March", note: "Online booking not offered by the temple" },
];
