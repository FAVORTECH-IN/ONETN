export type LibItem = { id: string; title: string; kind: "Textbook" | "Reference book" | "Notes" | "Previous paper" | "Video" | "Course"; stage: "School" | "College" | "Competitive exams" | "Skills & careers"; subject: string; lang: "Tamil" | "English" | "Tamil & English"; free: boolean; price?: number; source: string; pages?: number; mins?: number; hue: number; desc: string };
export const LIBRARY: LibItem[] = [
  { id: "l1", title: "Class 10 Science – State Board", kind: "Textbook", stage: "School", subject: "Science", lang: "Tamil & English", free: true, source: "School Education Department (government content)", pages: 312, hue: 2, desc: "Official state board textbook. Free for all students." },
  { id: "l2", title: "Class 12 Mathematics Vol. 1", kind: "Textbook", stage: "School", subject: "Mathematics", lang: "Tamil & English", free: true, source: "School Education Department (government content)", pages: 286, hue: 3, desc: "Matrices, complex numbers, analytical geometry." },
  { id: "l3", title: "Class 12 Physics – Chapter Notes", kind: "Notes", stage: "School", subject: "Physics", lang: "English", free: true, source: "Government teacher contribution (reviewed)", pages: 64, hue: 5, desc: "Concise revision notes for every chapter." },
  { id: "l4", title: "Class 10 Board – Previous Papers (5 years)", kind: "Previous paper", stage: "School", subject: "All subjects", lang: "Tamil & English", free: true, source: "Directorate of Government Examinations (public)", pages: 140, hue: 0, desc: "Question papers with marking scheme." },
  { id: "l5", title: "NEET Biology – Complete Reference", kind: "Reference book", stage: "Competitive exams", subject: "Biology", lang: "English", free: false, price: 299, source: "Licensed publisher partner (demo)", pages: 820, hue: 2, desc: "NCERT-aligned reference with 3,000 practice MCQs." },
  { id: "l6", title: "NEET Physics – Mechanics (Video Series)", kind: "Video", stage: "Competitive exams", subject: "Physics", lang: "Tamil", free: true, source: "State teachers' video lessons", mins: 240, hue: 3, desc: "12 lessons explained in simple Tamil." },
  { id: "l7", title: "GRE Verbal – Word Lists & Practice", kind: "Reference book", stage: "Competitive exams", subject: "Verbal reasoning", lang: "English", free: false, price: 199, source: "Licensed publisher partner (demo)", pages: 260, hue: 5, desc: "High-frequency words with usage." },
  { id: "l8", title: "TNPSC Group 4 – General Studies", kind: "Notes", stage: "Competitive exams", subject: "General studies", lang: "Tamil", free: true, source: "Government content", pages: 180, hue: 4, desc: "History, polity, Tamil Nadu development administration." },
  { id: "l9", title: "TNPSC Group 2 – Previous Papers", kind: "Previous paper", stage: "Competitive exams", subject: "General studies", lang: "Tamil & English", free: true, source: "Public question papers", pages: 96, hue: 0, desc: "Last 4 exams with answer keys." },
  { id: "l10", title: "Engineering Mathematics I", kind: "Reference book", stage: "College", subject: "Mathematics", lang: "English", free: false, price: 149, source: "Licensed publisher partner (demo)", pages: 410, hue: 3, desc: "For first-year B.E./B.Tech." },
  { id: "l11", title: "Spoken English for Interviews", kind: "Course", stage: "Skills & careers", subject: "Communication", lang: "Tamil & English", free: true, source: "Skill development partner (demo)", mins: 180, hue: 1, desc: "Short course linked to job categories." },
  { id: "l12", title: "Basic Electrician Course", kind: "Course", stage: "Skills & careers", subject: "Trades", lang: "Tamil", free: true, source: "Skill development partner (demo)", mins: 360, hue: 4, desc: "Leads to electrician jobs in Home Services." },
  { id: "l13", title: "Class 11 Chemistry – Video Lessons", kind: "Video", stage: "School", subject: "Chemistry", lang: "Tamil", free: true, source: "State teachers' video lessons", mins: 300, hue: 2, desc: "Full-topic lessons with experiments." },
  { id: "l14", title: "B.Com Financial Accounting Notes", kind: "Notes", stage: "College", subject: "Commerce", lang: "English", free: true, source: "Teacher contribution (reviewed)", pages: 120, hue: 1, desc: "Unit-wise summaries and problems." },
];

export type Q = { q: string; opts: string[]; a: number; topic: string; exp: string };
export const EXAMS: Record<string, { name: string; mins: number; desc: string; qs: Q[] }> = {
  neet: {
    name: "NEET – Biology & Physics Mini Mock", mins: 10, desc: "10 questions · NEET pattern · +4 / −1",
    qs: [
      { q: "Which organelle is known as the powerhouse of the cell?", opts: ["Ribosome", "Mitochondria", "Golgi body", "Lysosome"], a: 1, topic: "Cell biology", exp: "Mitochondria produce ATP through cellular respiration." },
      { q: "The SI unit of force is:", opts: ["Joule", "Pascal", "Newton", "Watt"], a: 2, topic: "Mechanics", exp: "1 newton = 1 kg·m/s²." },
      { q: "DNA replication is:", opts: ["Conservative", "Semi-conservative", "Dispersive", "Non-conservative"], a: 1, topic: "Genetics", exp: "Meselson–Stahl showed each new DNA has one old and one new strand." },
      { q: "A body moving with uniform velocity has acceleration:", opts: ["Zero", "Constant non-zero", "Increasing", "Negative"], a: 0, topic: "Mechanics", exp: "Uniform velocity means no change in velocity." },
      { q: "Which blood cells help in clotting?", opts: ["RBC", "WBC", "Platelets", "Plasma"], a: 2, topic: "Human physiology", exp: "Platelets (thrombocytes) initiate clotting." },
      { q: "Ohm's law relates:", opts: ["V and I", "P and V", "F and a", "E and m"], a: 0, topic: "Electricity", exp: "V = IR at constant temperature." },
      { q: "Photosynthesis takes place in the:", opts: ["Mitochondria", "Chloroplast", "Nucleus", "Vacuole"], a: 1, topic: "Plant physiology", exp: "Chlorophyll in chloroplasts captures light energy." },
      { q: "The unit of power is:", opts: ["Watt", "Newton", "Joule", "Volt"], a: 0, topic: "Mechanics", exp: "Power = work / time, measured in watts." },
      { q: "Insulin is secreted by:", opts: ["Liver", "Pancreas (β-cells)", "Thyroid", "Adrenal"], a: 1, topic: "Human physiology", exp: "β-cells of the islets of Langerhans secrete insulin." },
      { q: "Mendel worked on:", opts: ["Drosophila", "Pea plant", "Maize", "E. coli"], a: 1, topic: "Genetics", exp: "Garden pea (Pisum sativum)." },
    ],
  },
  tnpsc: {
    name: "TNPSC Group 4 – General Studies Mini Mock", mins: 8, desc: "8 questions · Tamil Nadu GS",
    qs: [
      { q: "Which river is known as the 'Dakshina Ganga'?", opts: ["Vaigai", "Cauvery", "Thamirabarani", "Palar"], a: 1, topic: "Geography", exp: "The Cauvery is often called the Dakshina Ganga." },
      { q: "Thirukkural was written by:", opts: ["Kambar", "Thiruvalluvar", "Ilango Adigal", "Avvaiyar"], a: 1, topic: "Tamil literature", exp: "Thiruvalluvar authored the Thirukkural." },
      { q: "The capital of the Pallavas was:", opts: ["Madurai", "Thanjavur", "Kanchipuram", "Uraiyur"], a: 2, topic: "History", exp: "Kanchipuram was the Pallava capital." },
      { q: "Article 21 of the Constitution deals with:", opts: ["Right to equality", "Protection of life and personal liberty", "Freedom of religion", "Right to education"], a: 1, topic: "Polity", exp: "Article 21 – protection of life and personal liberty." },
      { q: "Brihadeeswarar Temple was built by:", opts: ["Rajaraja Chola I", "Rajendra Chola", "Narasimhavarman", "Krishnadevaraya"], a: 0, topic: "History", exp: "Built by Rajaraja Chola I." },
      { q: "Number of districts in Tamil Nadu (2024):", opts: ["32", "36", "38", "40"], a: 2, topic: "Geography", exp: "Tamil Nadu has 38 districts." },
      { q: "Silappathikaram is one of the:", opts: ["Five great epics", "Eighteen minor works", "Ten idylls", "Eight anthologies"], a: 0, topic: "Tamil literature", exp: "It is one of the five great epics of Tamil literature." },
      { q: "The Panchayati Raj system was given constitutional status by:", opts: ["42nd Amendment", "73rd Amendment", "86th Amendment", "44th Amendment"], a: 1, topic: "Polity", exp: "73rd Amendment Act, 1992." },
    ],
  },
  class10: {
    name: "Class 10 Science – Practice Test", mins: 6, desc: "6 questions · State board",
    qs: [
      { q: "The pH of pure water is:", opts: ["5", "7", "9", "14"], a: 1, topic: "Chemistry", exp: "Pure water is neutral, pH 7." },
      { q: "Which lens is used to correct myopia?", opts: ["Convex", "Concave", "Cylindrical", "Bifocal"], a: 1, topic: "Optics", exp: "A concave (diverging) lens corrects myopia." },
      { q: "The functional unit of the kidney is:", opts: ["Neuron", "Nephron", "Alveoli", "Villi"], a: 1, topic: "Biology", exp: "Nephrons filter blood." },
      { q: "Rusting of iron needs:", opts: ["Only water", "Only oxygen", "Water and oxygen", "Carbon dioxide"], a: 2, topic: "Chemistry", exp: "Both moisture and oxygen are required." },
      { q: "Unit of electric charge:", opts: ["Ampere", "Coulomb", "Volt", "Ohm"], a: 1, topic: "Electricity", exp: "Charge is measured in coulombs." },
      { q: "Which gas is released during photosynthesis?", opts: ["CO₂", "N₂", "O₂", "H₂"], a: 2, topic: "Biology", exp: "Oxygen is released." },
    ],
  },
};

export const MENTORS = [
  { id: "t1", name: "Dr. S. Anitha", role: "Teacher", subject: "Biology (NEET)", exp: 14, rating: 4.9, fee: 300, mode: ["Online", "In person"], lang: "Tamil, English", place: "Anna Nagar, Chennai" },
  { id: "t2", name: "R. Balamurugan", role: "Teacher", subject: "Mathematics (Class 11–12)", exp: 18, rating: 4.8, fee: 250, mode: ["Online"], lang: "Tamil", place: "Online" },
  { id: "t3", name: "Fathima Begum", role: "Mentor", subject: "TNPSC preparation", exp: 9, rating: 4.7, fee: 200, mode: ["Online", "In person"], lang: "Tamil", place: "Madurai" },
  { id: "c1", name: "Prof. K. Ravichandran", role: "Career counsellor", subject: "Engineering & higher studies", exp: 22, rating: 4.9, fee: 400, mode: ["Online", "In person"], lang: "Tamil, English", place: "Coimbatore" },
  { id: "c2", name: "Nandhini V", role: "Career counsellor", subject: "Arts, commerce & government jobs", exp: 11, rating: 4.8, fee: 350, mode: ["Online"], lang: "Tamil, English", place: "Online" },
  { id: "w1", name: "Dr. Priyadarshini M (M.Phil Clinical Psychology)", role: "Mental-wellbeing counsellor", subject: "Exam stress, anxiety, wellbeing", exp: 12, rating: 4.9, fee: 500, mode: ["Online", "In person"], lang: "Tamil, English", place: "Chennai", reg: "RCI Reg. A-XXXXX (demo)" },
];

export const DOCTORS = [
  { id: "d1", name: "Dr. A. Venkatesan", spec: "General Medicine", qual: "MBBS, MD", reg: "TNMC Reg. 7XXXX (verified – demo)", exp: 20, fee: 400, rating: 4.8, hospital: "Sri Ram Clinic, T. Nagar", mode: ["In person", "Video"], lang: "Tamil, English" },
  { id: "d2", name: "Dr. Shalini Raj", spec: "Paediatrics", qual: "MBBS, DCH, DNB", reg: "TNMC Reg. 8XXXX (verified – demo)", exp: 12, fee: 500, rating: 4.9, hospital: "Little Steps Child Care, Adyar", mode: ["In person", "Video"], lang: "Tamil, English" },
  { id: "d3", name: "Dr. M. Iqbal", spec: "Cardiology", qual: "MBBS, MD, DM", reg: "TNMC Reg. 6XXXX (verified – demo)", exp: 24, fee: 900, rating: 4.8, hospital: "Heart Care Centre, Vadapalani", mode: ["In person"], lang: "Tamil, English, Urdu" },
  { id: "d4", name: "Dr. Kalpana S", spec: "Obstetrics & Gynaecology", qual: "MBBS, MS (OG)", reg: "TNMC Reg. 7XXXX (verified – demo)", exp: 16, fee: 600, rating: 4.9, hospital: "Amma Women's Clinic, Velachery", mode: ["In person", "Video"], lang: "Tamil" },
  { id: "d5", name: "Dr. R. Senthilnathan", spec: "Orthopaedics", qual: "MBBS, MS (Ortho)", reg: "TNMC Reg. 6XXXX (verified – demo)", exp: 19, fee: 700, rating: 4.7, hospital: "Bone & Joint Clinic, Tambaram", mode: ["In person"], lang: "Tamil, English" },
  { id: "d6", name: "Dr. Deepa Krishnan", spec: "Dermatology", qual: "MBBS, MD (DVL)", reg: "TNMC Reg. 9XXXX (verified – demo)", exp: 9, fee: 500, rating: 4.8, hospital: "Skin First, Anna Nagar", mode: ["In person", "Video"], lang: "Tamil, English" },
  { id: "d7", name: "Dr. P. Gowri", spec: "Psychiatry", qual: "MBBS, MD (Psychiatry)", reg: "TNMC Reg. 8XXXX (verified – demo)", exp: 14, fee: 800, rating: 4.9, hospital: "MindWell Clinic, Mylapore", mode: ["In person", "Video"], lang: "Tamil, English" },
];
export const SPECIALITIES = ["General Medicine", "Paediatrics", "Cardiology", "Obstetrics & Gynaecology", "Orthopaedics", "Dermatology", "Psychiatry"];
export const APPT_SLOTS = ["9:00 AM", "9:30 AM", "10:00 AM", "11:00 AM", "12:00 PM", "4:00 PM", "5:00 PM", "6:30 PM"];
