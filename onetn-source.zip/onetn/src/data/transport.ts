// Demo fare structures — placeholders pending Transport Department approval (Annexure E: no figures are fixed).
export const PLACES = [
  { name: "T. Nagar", area: "Chennai", x: 42, y: 58 }, { name: "Guindy", area: "Chennai", x: 48, y: 72 },
  { name: "Chennai Central", area: "Chennai", x: 58, y: 30 }, { name: "Egmore", area: "Chennai", x: 55, y: 36 },
  { name: "Koyambedu (CMBT)", area: "Chennai", x: 28, y: 42 }, { name: "Chennai Airport", area: "Chennai", x: 40, y: 86 },
  { name: "Velachery", area: "Chennai", x: 56, y: 80 }, { name: "Adyar", area: "Chennai", x: 66, y: 66 },
  { name: "Anna Nagar", area: "Chennai", x: 34, y: 32 }, { name: "Mylapore", area: "Chennai", x: 66, y: 52 },
  { name: "Tambaram", area: "Chennai", x: 36, y: 96 }, { name: "Marina Beach", area: "Chennai", x: 72, y: 44 },
  { name: "Porur", area: "Chennai", x: 18, y: 62 }, { name: "Sholinganallur", area: "Chennai", x: 80, y: 90 },
];
export const distanceKm = (a: string, b: string) => {
  const p = PLACES.find((x) => x.name === a), q = PLACES.find((x) => x.name === b);
  if (!p || !q) return 7.5;
  return Math.max(1.5, +(Math.hypot(p.x - q.x, p.y - q.y) * 0.32).toFixed(1));
};

export type VehicleType = { id: string; name: string; seats: number; base: number; baseKm: number; perKm: number; perMinWait: number; eta: number; desc: string; kind: "bike" | "auto" | "cab" };
export const VEHICLES: VehicleType[] = [
  { id: "bike", name: "Bike Taxi", seats: 1, base: 20, baseKm: 2, perKm: 8, perMinWait: 1, eta: 3, desc: "Quick solo ride", kind: "bike" },
  { id: "auto", name: "Auto", seats: 3, base: 30, baseKm: 1.8, perKm: 15, perMinWait: 1.5, eta: 4, desc: "Standard approved fare", kind: "auto" },
  { id: "mini", name: "Cab Mini", seats: 4, base: 60, baseKm: 2, perKm: 16, perMinWait: 2, eta: 6, desc: "Hatchback, AC", kind: "cab" },
  { id: "sedan", name: "Cab Sedan", seats: 4, base: 80, baseKm: 2, perKm: 19, perMinWait: 2, eta: 7, desc: "Extra boot space, AC", kind: "cab" },
  { id: "suv", name: "Cab SUV", seats: 6, base: 110, baseKm: 2, perKm: 24, perMinWait: 2.5, eta: 9, desc: "Families & luggage", kind: "cab" },
  { id: "ev", name: "Cab EV", seats: 4, base: 70, baseKm: 2, perKm: 17, perMinWait: 2, eta: 8, desc: "Electric, zero tailpipe", kind: "cab" },
];
export const PLATFORM_FEE_RIDE = 8;
export function fareFor(v: VehicleType, km: number, night = false) {
  const dist = Math.max(0, km - v.baseKm) * v.perKm;
  const sub = v.base + dist;
  const nightCharge = night ? Math.round(sub * 0.25) : 0;
  const lines = [
    { label: `Base fare (first ${v.baseKm} km)`, amount: v.base },
    { label: `Distance (${Math.max(0, km - v.baseKm).toFixed(1)} km × ₹${v.perKm})`, amount: Math.round(dist) },
    ...(night ? [{ label: "Night charge (25%, 10 PM–5 AM)", amount: nightCharge }] : []),
    { label: "Platform fee", amount: PLATFORM_FEE_RIDE },
  ];
  return { lines, total: Math.round(sub + nightCharge + PLATFORM_FEE_RIDE), minutes: Math.round(km * 3.2 + 4) };
}

export const DRIVERS = [
  { name: "Murugan K", rating: 4.8, trips: 3120, phone: "98XXXXXX21", vehicles: { auto: "TN 09 AB 4521", bike: "TN 07 CK 1180", cab: "TN 10 BX 7733 · Swift Dzire" }, lang: "Tamil, English" },
  { name: "Selvi R", rating: 4.9, trips: 1840, phone: "97XXXXXX08", vehicles: { auto: "TN 22 AF 9042", bike: "TN 22 DL 5531", cab: "TN 22 CB 2210 · WagonR" }, lang: "Tamil" },
  { name: "Arul Prakash", rating: 4.7, trips: 2650, phone: "99XXXXXX45", vehicles: { auto: "TN 05 AY 3378", bike: "TN 05 BZ 7712", cab: "TN 05 DE 6620 · Innova Crysta" }, lang: "Tamil, Hindi" },
];

export const CITIES = ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Thanjavur", "Vellore", "Erode", "Thoothukudi", "Kanniyakumari", "Rameswaram", "Kodaikanal", "Ooty", "Puducherry", "Bengaluru"];
export type BusSvc = { id: string; operator: "SETC" | "TNSTC" | "MTC" | "Private"; type: string; dep: string; arr: string; dur: string; fare: number; seats: number; via: string; amenities: string[]; rating: number };
export function busesFor(from: string, to: string): BusSvc[] {
  const seed = (from + to).length;
  const base = 180 + (seed % 7) * 60;
  return [
    { id: "SETC-" + (101 + seed), operator: "SETC", type: "AC Sleeper", dep: "21:30", arr: "05:45", dur: "8h 15m", fare: base + 420, seats: 9, via: "Villupuram, Trichy", amenities: ["AC", "Charging point", "Blanket", "Live tracking"], rating: 4.4 },
    { id: "SETC-" + (205 + seed), operator: "SETC", type: "Ultra Deluxe (Non-AC Seater)", dep: "22:15", arr: "06:30", dur: "8h 15m", fare: base + 120, seats: 21, via: "Ulundurpet, Perambalur", amenities: ["Push-back seats", "Live tracking"], rating: 4.2 },
    { id: "TNSTC-" + (340 + seed), operator: "TNSTC", type: "Express (Non-AC Seater)", dep: "06:00", arr: "14:40", dur: "8h 40m", fare: base, seats: 30, via: "Tindivanam, Villupuram", amenities: ["Live tracking"], rating: 4.0 },
    { id: "SETC-" + (512 + seed), operator: "SETC", type: "AC Seater", dep: "13:45", arr: "21:50", dur: "8h 05m", fare: base + 260, seats: 14, via: "Trichy bypass", amenities: ["AC", "Charging point"], rating: 4.3 },
    { id: "PVT-" + (77 + seed), operator: "Private", type: "AC Sleeper (Volvo)", dep: "23:00", arr: "06:40", dur: "7h 40m", fare: base + 620, seats: 6, via: "Express", amenities: ["AC", "Water", "Blanket", "Charging point"], rating: 4.5 },
  ];
}
export const BOARDING = ["Koyambedu (CMBT)", "Kilambakkam (KCBT)", "Tambaram", "Perungalathur", "Guindy"];
export const DROPPING = ["Central bus stand", "Bypass junction", "New bus stand", "Railway station"];
export const CONCESSIONS = [
  { id: "none", label: "No concession", pct: 0 },
  { id: "senior", label: "Senior citizen (as per scheme)", pct: 25 },
  { id: "pwd", label: "Person with disability + escort (as per scheme)", pct: 75 },
  { id: "student", label: "Student pass holder (as per scheme)", pct: 50 },
  { id: "women-free", label: "Women – free travel in eligible town buses (as per scheme)", pct: 100 },
];
export const bookedSeats = (busId: string) => {
  const n = busId.length;
  return new Set(Array.from({ length: 14 }, (_, i) => ((i * 7 + n * 3) % 36) + 1));
};

export const METRO_LINES = [
  { id: "blue", name: "Blue Line", color: "#1565C0", stations: ["Wimco Nagar Depot", "Tiruvottiyur", "Washermanpet", "Chennai Central", "Government Estate", "LIC", "Thousand Lights", "AG-DMS", "Teynampet", "Nandanam", "Saidapet", "Little Mount", "Guindy", "Alandur", "Meenambakkam", "Chennai Airport"] },
  { id: "green", name: "Green Line", color: "#2E7D32", stations: ["Chennai Central", "Egmore", "Nehru Park", "Kilpauk", "Pachaiyappa's College", "Shenoy Nagar", "Anna Nagar East", "Anna Nagar Tower", "Thirumangalam", "Koyambedu", "CMBT", "Arumbakkam", "Vadapalani", "Ashok Nagar", "Ekkattuthangal", "Alandur", "St. Thomas Mount"] },
];
export const metroFare = (n: number) => (n <= 2 ? 10 : n <= 5 ? 20 : n <= 9 ? 30 : n <= 13 ? 40 : 50);

export const PARCEL_SIZES = [
  { id: "small", name: "Small", eg: "Documents, medicines, small gifts", maxKg: 5, base: 40, perKm: 8, vehicle: "Bike" },
  { id: "medium", name: "Medium", eg: "Household goods, shop orders", maxKg: 20, base: 90, perKm: 12, vehicle: "Auto / 3-wheeler goods" },
  { id: "large", name: "Large", eg: "Furniture, appliances, business goods", maxKg: 500, base: 350, perKm: 22, vehicle: "Permitted goods vehicle (Tata Ace / pickup)" },
];
export const PARCEL_CATEGORIES = ["Documents", "Food (packed)", "Medicines", "Clothing", "Electronics", "Household items", "Furniture", "Business stock", "Gifts", "Other"];
