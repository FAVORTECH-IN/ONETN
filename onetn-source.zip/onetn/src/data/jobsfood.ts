export type Job = { id: string; title: string; org: string; sector: "Government" | "Private" | "Local" | "Short-term"; location: string; district: string; salary: [number, number]; edu: string; exp: number; type: string; posted: string; lastDate?: string; verified: boolean; skills: string[]; desc: string; official?: string; category: string };
export const JOBS: Job[] = [
  { id: "j1", title: "Group 4 Services (VAO, Junior Assistant, Typist)", org: "Tamil Nadu Public Service Commission", sector: "Government", location: "Across Tamil Nadu", district: "All", salary: [19500, 71900], edu: "10th pass", exp: 0, type: "Permanent", posted: "2 days ago", lastDate: "2026-11-28", verified: true, skills: ["Tamil", "General studies", "Aptitude"], desc: "Recruitment notification for Group 4 posts. Application through the official TNPSC portal.", official: "tnpsc.gov.in", category: "Administration" },
  { id: "j2", title: "Staff Nurse", org: "Medical Recruitment Board (demo listing)", sector: "Government", location: "District hospitals", district: "All", salary: [36000, 115700], edu: "B.Sc Nursing / Diploma", exp: 0, type: "Permanent", posted: "1 week ago", lastDate: "2026-12-10", verified: true, skills: ["Nursing", "Patient care"], desc: "Recruitment for staff nurses in government hospitals. Apply on the official MRB portal.", official: "mrb.tn.gov.in", category: "Healthcare" },
  { id: "j3", title: "Graduate Teacher (BT Assistant)", org: "Teachers Recruitment Board (demo listing)", sector: "Government", location: "Government schools", district: "All", salary: [36400, 115700], edu: "UG + B.Ed", exp: 0, type: "Permanent", posted: "3 days ago", lastDate: "2026-12-05", verified: true, skills: ["Teaching", "Subject knowledge"], desc: "Direct recruitment of graduate teachers.", official: "trb.tn.gov.in", category: "Education" },
  { id: "j4", title: "Customer Support Executive (Tamil)", org: "Kaveri Tech Services Pvt Ltd", sector: "Private", location: "Guindy, Chennai", district: "Chennai", salary: [18000, 24000], edu: "Any degree", exp: 0, type: "Full-time", posted: "Today", verified: true, skills: ["Tamil", "English", "Computer basics"], desc: "Handle customer calls and chats in Tamil and English. Day shift, PF & ESI.", category: "Customer service" },
  { id: "j5", title: "Junior Accountant", org: "Sri Murugan Textiles", sector: "Private", location: "Tiruppur", district: "Tiruppur", salary: [16000, 22000], edu: "B.Com", exp: 1, type: "Full-time", posted: "Yesterday", verified: true, skills: ["Tally", "GST", "Excel"], desc: "Accounts, GST filing support and vendor payments.", category: "Accounts" },
  { id: "j6", title: "Electrician (Industrial)", org: "Coimbatore Pumps & Motors", sector: "Private", location: "Coimbatore", district: "Coimbatore", salary: [15000, 21000], edu: "ITI Electrician", exp: 2, type: "Full-time", posted: "4 days ago", verified: true, skills: ["Wiring", "Motor rewinding", "Safety"], desc: "Maintenance of industrial motors and panels.", category: "Trades" },
  { id: "j7", title: "Shop Assistant", org: "Lakshmi Supermarket", sector: "Local", location: "West Mambalam, Chennai", district: "Chennai", salary: [11000, 13000], edu: "10th pass", exp: 0, type: "Full-time", posted: "Today", verified: true, skills: ["Billing", "Customer handling"], desc: "Billing and shelf management at a neighbourhood supermarket.", category: "Retail" },
  { id: "j8", title: "Festival Season Helper (30 days)", org: "Pothys Silks (demo listing)", sector: "Short-term", location: "T. Nagar, Chennai", district: "Chennai", salary: [600, 700], edu: "Any", exp: 0, type: "Daily wage (₹/day)", posted: "2 days ago", verified: true, skills: ["Customer handling"], desc: "Temporary staff for the festival season. Daily wage paid weekly.", category: "Retail" },
  { id: "j9", title: "Delivery Partner", org: "ONETN Delivery Network", sector: "Local", location: "Your area", district: "All", salary: [15000, 28000], edu: "Any · licence for vehicle", exp: 0, type: "Flexible", posted: "Ongoing", verified: true, skills: ["Two-wheeler", "Smartphone"], desc: "Flexible delivery and ride work. Free registration. Earnings paid daily to Wallet.", category: "Logistics" },
  { id: "j10", title: "Data Entry Operator", org: "Madurai Hospitals Group", sector: "Private", location: "Madurai", district: "Madurai", salary: [12000, 15000], edu: "12th pass", exp: 0, type: "Full-time", posted: "5 days ago", verified: false, skills: ["Typing", "MS Office"], desc: "Patient record entry and billing support.", category: "Administration" },
];
export const EXAM_CALENDAR = [
  { exam: "TNPSC Group 4", notif: "05 Nov 2026", apply: "28 Nov 2026", exam_: "Feb 2027", result: "TBA" },
  { exam: "TRB BT Assistant", notif: "01 Nov 2026", apply: "05 Dec 2026", exam_: "Jan 2027", result: "TBA" },
  { exam: "MRB Staff Nurse", notif: "28 Oct 2026", apply: "10 Dec 2026", exam_: "Jan 2027", result: "TBA" },
  { exam: "TN Police Constable (TNUSRB)", notif: "Expected Dec 2026", apply: "TBA", exam_: "TBA", result: "TBA" },
];

export type Dish = { id: string; name: string; desc: string; price: number; veg: boolean; cat: string; allergens?: string; best?: boolean };
export type Restaurant = { id: string; name: string; cuisine: string[]; area: string; km: number; eta: number; rating: number; ratings: number; cost2: number; hours: string; veg: boolean; hue: number; takeaway: boolean; tables: boolean; offer?: string; fssai: string; menu: Dish[] };
export const CUISINES = ["South Indian", "Chettinad", "Biryani", "Vegetarian", "North Indian", "Chinese", "Bakery & Desserts", "Seafood", "Tiffin"];
export const RESTAURANTS: Restaurant[] = [
  {
    id: "annapoorna", name: "Sri Annapoorna Tiffin Centre", cuisine: ["South Indian", "Tiffin", "Vegetarian"], area: "T. Nagar", km: 0.9, eta: 25, rating: 4.6, ratings: 3200, cost2: 250, hours: "6:30 AM – 10:30 PM", veg: true, hue: 4, takeaway: true, tables: true, offer: "Free delivery above ₹199", fssai: "1241XXXXXXXXX1 (verified – demo)",
    menu: [
      { id: "a1", name: "Ghee Roast Dosa", desc: "Crisp dosa roasted in ghee, sambar & 3 chutneys", price: 120, veg: true, cat: "Dosa", allergens: "Dairy", best: true },
      { id: "a2", name: "Mini Idli Sambar (14 pcs)", desc: "Button idlis soaked in tiffin sambar", price: 95, veg: true, cat: "Idli", best: true },
      { id: "a3", name: "Pongal Vada Combo", desc: "Ven pongal with medu vada", price: 110, veg: true, cat: "Combos", allergens: "Dairy, cashew" },
      { id: "a4", name: "Rava Masala Dosa", desc: "Onion rava dosa with potato masala", price: 130, veg: true, cat: "Dosa", allergens: "Gluten" },
      { id: "a5", name: "South Indian Meals", desc: "Rice, sambar, rasam, 2 poriyal, kootu, curd, appalam, payasam", price: 180, veg: true, cat: "Meals", allergens: "Dairy" },
      { id: "a6", name: "Filter Coffee", desc: "Traditional decoction coffee", price: 40, veg: true, cat: "Beverages", allergens: "Dairy" },
    ],
  },
  {
    id: "chettinad", name: "Karaikudi Chettinad Mess", cuisine: ["Chettinad", "South Indian"], area: "Mylapore", km: 2.4, eta: 35, rating: 4.5, ratings: 2100, cost2: 600, hours: "11:30 AM – 11 PM", veg: false, hue: 0, takeaway: true, tables: true, offer: "₹75 off above ₹499 (restaurant-funded)", fssai: "1241XXXXXXXXX7 (verified – demo)",
    menu: [
      { id: "c1", name: "Chicken Chettinad", desc: "Spicy pepper-based gravy, Karaikudi style", price: 260, veg: false, cat: "Gravies", best: true },
      { id: "c2", name: "Mutton Sukka", desc: "Dry roast with shallots and curry leaves", price: 340, veg: false, cat: "Starters" },
      { id: "c3", name: "Nattu Kozhi Rasam", desc: "Country chicken pepper soup", price: 160, veg: false, cat: "Soups" },
      { id: "c4", name: "Kalaan Pepper Fry", desc: "Mushroom pepper fry", price: 190, veg: true, cat: "Starters" },
      { id: "c5", name: "Parotta (2 pcs)", desc: "Flaky layered parotta", price: 60, veg: true, cat: "Breads", allergens: "Gluten" },
      { id: "c6", name: "Chettinad Veg Meals", desc: "Unlimited rice with kara kuzhambu & poriyal", price: 220, veg: true, cat: "Meals" },
    ],
  },
  {
    id: "ambur", name: "Ambur Star Biryani", cuisine: ["Biryani"], area: "Vadapalani", km: 3.1, eta: 40, rating: 4.4, ratings: 5400, cost2: 500, hours: "11 AM – 11:30 PM", veg: false, hue: 1, takeaway: true, tables: false, fssai: "1241XXXXXXXXX3 (verified – demo)",
    menu: [
      { id: "b1", name: "Ambur Chicken Biryani", desc: "Seeraga samba rice, dum-cooked", price: 240, veg: false, cat: "Biryani", best: true },
      { id: "b2", name: "Mutton Biryani", desc: "Tender mutton, Ambur style", price: 320, veg: false, cat: "Biryani" },
      { id: "b3", name: "Veg Biryani", desc: "Seasonal vegetables, mild spice", price: 180, veg: true, cat: "Biryani" },
      { id: "b4", name: "Brinjal Curry (Ennai Kathirikkai)", desc: "Classic biryani side", price: 60, veg: true, cat: "Sides" },
      { id: "b5", name: "Bread Halwa", desc: "Wedding-style dessert", price: 80, veg: true, cat: "Desserts", allergens: "Gluten, dairy, nuts" },
    ],
  },
  {
    id: "marina", name: "Marina Seafood Kitchen", cuisine: ["Seafood", "Chettinad"], area: "Besant Nagar", km: 5.2, eta: 45, rating: 4.3, ratings: 980, cost2: 800, hours: "12 PM – 11 PM", veg: false, hue: 3, takeaway: false, tables: true, fssai: "1241XXXXXXXXX9 (verified – demo)",
    menu: [
      { id: "s1", name: "Vanjaram Fish Fry", desc: "Seer fish, masala-coated tawa fry", price: 380, veg: false, cat: "Seafood", allergens: "Fish", best: true },
      { id: "s2", name: "Prawn Thokku", desc: "Spicy prawn masala", price: 340, veg: false, cat: "Seafood", allergens: "Shellfish" },
      { id: "s3", name: "Meen Kuzhambu Meals", desc: "Fish curry with rice and sides", price: 260, veg: false, cat: "Meals", allergens: "Fish" },
    ],
  },
  {
    id: "sweets", name: "Grand Sweets & Bakes", cuisine: ["Bakery & Desserts", "Vegetarian"], area: "Adyar", km: 3.8, eta: 30, rating: 4.7, ratings: 4100, cost2: 300, hours: "8 AM – 10 PM", veg: true, hue: 5, takeaway: true, tables: false, offer: "Festive boxes available", fssai: "1241XXXXXXXXX5 (verified – demo)",
    menu: [
      { id: "w1", name: "Mysore Pak (250 g)", desc: "Soft ghee Mysore pak", price: 210, veg: true, cat: "Sweets", allergens: "Dairy", best: true },
      { id: "w2", name: "Murukku (200 g)", desc: "Crunchy rice-flour murukku", price: 90, veg: true, cat: "Savouries" },
      { id: "w3", name: "Badam Milk", desc: "Chilled almond milk", price: 70, veg: true, cat: "Beverages", allergens: "Dairy, nuts" },
      { id: "w4", name: "Plum Cake (500 g)", desc: "Eggless fruit cake", price: 260, veg: true, cat: "Cakes", allergens: "Gluten, dairy, nuts" },
    ],
  },
];
