"use client";
import Link from "next/link";
import { ShoppingBasket } from "lucide-react";
import { useApp } from "@/lib/store";
import { Qty, Thumb } from "@/components/ui";
import { inr } from "@/lib/utils";

export type PItem = { id: string; name: string; price: number; mrp?: number; unit: string; hue: number; sub?: string };
export function ProductGrid({ items, cartKey, store, hrefFor, icon = ShoppingBasket }: { items: PItem[]; cartKey: string; store: string; hrefFor?: (id: string) => string; icon?: React.ComponentType<{ size?: number; className?: string }> }) {
  const { cart, setQty } = useApp();
  const c = cart(cartKey);
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {items.map((p) => {
        const q = c.find((x) => x.id === p.id)?.qty ?? 0;
        const body = (<><Thumb hue={p.hue} icon={icon} className="h-28 w-full" size={110} /><p className="mt-2 line-clamp-2 min-h-10 text-sm font-semibold">{p.name}</p><p className="text-xs text-muted">{p.unit}{p.sub ? ` · ${p.sub}` : ""}</p></>);
        return (
          <div key={p.id} className="card flex flex-col p-3">
            {hrefFor ? <Link href={hrefFor(p.id)}>{body}</Link> : body}
            <div className="mt-auto flex items-center justify-between gap-2 pt-2">
              <span><span className="font-bold">{inr(p.price)}</span>{p.mrp && p.mrp > p.price && <span className="ml-1 text-xs text-muted line-through">{inr(p.mrp)}</span>}</span>
              <Qty value={q} onChange={(v) => setQty(cartKey, { id: p.id, name: p.name, price: p.price, unit: p.unit, store }, v)} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
