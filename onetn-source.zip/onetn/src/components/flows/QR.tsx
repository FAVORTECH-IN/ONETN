export function QR({ value, size = 160 }: { value: string; size?: number }) {
  let h = 2166136261;
  for (const c of value) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  const n = 25, cells: boolean[] = [];
  for (let i = 0; i < n * n; i++) { h = Math.imul(h ^ (h >>> 13), 1274126177); cells.push(((h >>> 7) & 1) === 1); }
  const finder = (x: number, y: number) => (
    <g key={`${x}-${y}`}><rect x={x} y={y} width="7" height="7" fill="#242424" /><rect x={x + 1} y={y + 1} width="5" height="5" fill="#fff" /><rect x={x + 2} y={y + 2} width="3" height="3" fill="#242424" /></g>
  );
  const inFinder = (x: number, y: number) => (x < 8 && y < 8) || (x > n - 9 && y < 8) || (x < 8 && y > n - 9);
  return (
    <svg width={size} height={size} viewBox={`-1 -1 ${n + 2} ${n + 2}`} role="img" aria-label={`QR code for ${value}`} className="rounded-lg bg-white">
      <rect x="-1" y="-1" width={n + 2} height={n + 2} fill="#fff" />
      {cells.map((on, i) => { const x = i % n, y = Math.floor(i / n); return on && !inFinder(x, y) ? <rect key={i} x={x} y={y} width="1" height="1" fill="#242424" /> : null; })}
      {finder(0, 0)}{finder(n - 7, 0)}{finder(0, n - 7)}
    </svg>
  );
}
