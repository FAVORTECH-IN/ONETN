"use client";
import { useMemo, useState } from "react";
import { LocateFixed, MapPin, Navigation, Clock, Users, Info, ShieldCheck, CalendarClock } from "lucide-react";
import { useApp } from "@/lib/store";
import { PLACES, VEHICLES, DRIVERS, distanceKm, fareFor } from "@/data/transport";
import { Avatar, Button, Card, Chip, Input, Notice, PageHeader, Rating, Select, Sheet, SimTag } from "@/components/ui";
import { MapView } from "./MapView";
import { CheckoutButton, FeeTable } from "./Payment";
import { cn, inr } from "@/lib/utils";

export function RideBooking({ mode, initialType }: { mode: "auto" | "cab"; initialType?: string }) {
  const { t, s } = useApp();
  const [pickup, setPickup] = useState("T. Nagar");
  const [drop, setDrop] = useState("");
  const [vid, setVid] = useState(initialType ?? (mode === "auto" ? "auto" : "mini"));
  const [when, setWhen] = useState<"now" | "later">("now");
  const [at, setAt] = useState("");
  const [fareOpen, setFareOpen] = useState(false);
  const types = VEHICLES.filter((v) => (mode === "auto" ? v.kind === "auto" || v.kind === "bike" : true));
  const km = drop ? distanceKm(pickup, drop) : 0;
  const hour = when === "later" && at ? new Date(at).getHours() : new Date().getHours();
  const night = hour >= 22 || hour < 5;
  const v = VEHICLES.find((x) => x.id === vid)!;
  const fare = useMemo(() => (drop ? fareFor(v, km, night) : null), [v, km, night, drop]);
  const driver = DRIVERS[(pickup.length + (drop?.length ?? 0)) % DRIVERS.length];
  const plate = driver.vehicles[v.kind as "auto" | "bike" | "cab"];
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title={mode === "auto" ? "Auto Booking" : "Rapido / Cab"} sub="Approved, published fares · no surge" />
      <div className="grid gap-4 lg:grid-cols-[1fr_400px]">
        <MapView from={pickup} to={drop || undefined} className="h-56 sm:h-80 lg:h-full lg:min-h-[520px]" />
        <div className="space-y-4">
          <Card className="space-y-3">
            <div className="flex items-center gap-3"><span className="h-3 w-3 rounded-full bg-success" />
              <Select aria-label={t("pickup")} value={pickup} onChange={(e) => setPickup(e.target.value)} options={PLACES.map((p) => p.name)} /></div>
            <div className="flex items-center gap-3"><span className="h-3 w-3 rounded-sm bg-primary" />
              <Select aria-label={t("drop")} value={drop} onChange={(e) => setDrop(e.target.value)} placeholder="Where to?" options={PLACES.filter((p) => p.name !== pickup).map((p) => p.name)} /></div>
            <div className="flex flex-wrap gap-2">
              <Chip onClick={() => setPickup("T. Nagar")}><LocateFixed size={14} className="mr-1 inline" />Current location</Chip>
              {["Chennai Central", "Chennai Airport", "Koyambedu (CMBT)"].map((p) => <Chip key={p} active={drop === p} onClick={() => setDrop(p)}>{p}</Chip>)}
            </div>
            {mode === "cab" && (
              <div className="flex flex-wrap items-center gap-2">
                <Chip active={when === "now"} onClick={() => setWhen("now")}>Ride now</Chip>
                <Chip active={when === "later"} onClick={() => setWhen("later")}><CalendarClock size={14} className="mr-1 inline" />Schedule</Chip>
                {when === "later" && <Input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} className="h-10 flex-1" min={new Date().toISOString().slice(0, 16)} />}
              </div>
            )}
          </Card>
          {drop ? (
            <>
              <div className="flex items-center justify-between text-sm"><span className="flex items-center gap-1 text-muted"><Navigation size={14} />{km} km · ~{fare!.minutes} min</span><SimTag label="Demo fare structure" /></div>
              <div className="space-y-2">
                {types.map((x) => { const f = fareFor(x, km, night); return (
                  <button key={x.id} onClick={() => setVid(x.id)} className={cn("card flex w-full items-center gap-3 p-3 text-left", vid === x.id && "border-primary ring-4 ring-primary/10")}>
                    <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gold-soft text-xl">{x.kind === "bike" ? "🛵" : x.kind === "auto" ? "🛺" : "🚗"}</span>
                    <span className="flex-1"><span className="block font-semibold">{x.name}</span><span className="flex items-center gap-2 text-xs text-muted"><Users size={12} />{x.seats} · <Clock size={12} />{x.eta} min away · {x.desc}</span></span>
                    <span className="text-right font-bold">{inr(f.total)}</span>
                  </button>
                ); })}
              </div>
              <button onClick={() => setFareOpen(true)} className="flex items-center gap-1 text-sm font-semibold text-primary"><Info size={15} />Fare breakdown & rules</button>
              <Card className="flex items-center gap-3">
                <Avatar name={driver.name} />
                <div className="flex-1"><p className="text-sm font-semibold">{driver.name} <ShieldCheck size={14} className="inline text-success" /></p><p className="text-xs text-muted">{plate} · {driver.trips} trips · {driver.lang}</p></div>
                <Rating value={driver.rating} />
              </Card>
              <p className="text-xs text-muted">Nearest verified driver shown. Final assignment happens on confirmation.</p>
              <CheckoutButton label={`${when === "later" ? "Schedule" : "Book"} ${v.name} · ${inr(fare!.total)}`} category="Rides" allowCash
                validate={() => (when === "later" && !at ? "Pick a date and time for the scheduled ride" : null)}
                build={() => ({
                  module: mode, kind: "booking", title: `${v.name} ride`, subtitle: `${pickup} → ${drop}`, status: "active", stageIdx: when === "later" ? 0 : 1,
                  stages: when === "later" ? ["Scheduled", "Driver assigned", "Driver arriving", "Trip started", "Trip completed"] : ["Booked", "Driver assigned", "Driver arriving", "Trip started", "Trip completed"],
                  when: when === "later" ? new Date(at).toLocaleString("en-IN") : undefined,
                  fees: fare!.lines, details: { Pickup: pickup, Drop: drop, Vehicle: v.name, Distance: `${km} km`, "Est. time": `${fare!.minutes} min`, ...(night ? { "Night charge": "Applied" } : {}) },
                  provider: { name: driver.name, rating: driver.rating, vehicle: plate },
                })} />
            </>
          ) : <Notice tone="info">Choose a drop location to see fares for every vehicle type before you book.</Notice>}
          <Notice tone="gold">Fares follow a structure to be approved by the Transport Department. Cancellation rules apply equally to passengers and drivers. {s.lang === "ta" ? "" : ""}</Notice>
        </div>
      </div>
      <Sheet open={fareOpen} onClose={() => setFareOpen(false)} title={`${v.name} – fare breakdown`}>
        {fare && <FeeTable fees={fare.lines} />}
        <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-muted">
          <li>Base fare covers the first {v.baseKm} km, then ₹{v.perKm}/km.</li><li>Waiting: ₹{v.perMinWait}/min after 3 free minutes.</li>
          <li>Night charge 25% between 10 PM and 5 AM.</li><li>No surge pricing at busy times.</li><li>Free cancellation before the driver arrives.</li>
        </ul>
        <MapPin className="hidden" />
      </Sheet>
    </div>
  );
}
