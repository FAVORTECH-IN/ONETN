"use client";
import { PLACES } from "@/data/transport";
import { cn } from "@/lib/utils";

export function MapView({ from, to, progress = 0, className, vehicle = "car", label }: { from?: string; to?: string; progress?: number; className?: string; vehicle?: "car" | "bike" | "bus" | "box"; label?: string }) {
  const a = PLACES.find((p) => p.name === from) ?? { x: 22, y: 70 };
  const b = PLACES.find((p) => p.name === to) ?? { x: 78, y: 28 };
  const mx = (a.x + b.x) / 2 + 8, my = (a.y + b.y) / 2 - 10;
  const t = Math.min(1, Math.max(0, progress));
  const px = (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * mx + t * t * b.x;
  const py = (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * my + t * t * b.y;
  return (
    <div className={cn("relative overflow-hidden rounded-[20px] border border-line bg-[#EFE8DC]", className)} role="img" aria-label={`Map from ${from ?? "pickup"} to ${to ?? "drop"}`}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" className="h-full w-full">
        <rect width="100" height="100" fill="#EFE8DC" />
        <path d="M70 0 C 76 30, 88 50, 100 58 L100 0Z" fill="#CFE3EE" />
        <path d="M0 40 C 20 44, 30 38, 50 46 S 80 60, 100 70" stroke="#CFE3EE" strokeWidth="3" fill="none" />
        <rect x="8" y="10" width="14" height="10" rx="2" fill="#DCE8CF" /><rect x="58" y="74" width="16" height="12" rx="2" fill="#DCE8CF" />
        {[15, 30, 45, 60, 75, 90].map((v) => <g key={v}><line x1={v} y1="0" x2={v} y2="100" stroke="#fff" strokeWidth="1.2" /><line x1="0" y1={v} x2="100" y2={v} stroke="#fff" strokeWidth="1.2" /></g>)}
        <line x1="0" y1="100" x2="100" y2="0" stroke="#fff" strokeWidth="2.4" />
        <path d={`M${a.x} ${a.y} Q ${mx} ${my} ${b.x} ${b.y}`} stroke="#8B0000" strokeWidth="1.6" fill="none" strokeDasharray="0" opacity=".9" />
        <path d={`M${a.x} ${a.y} Q ${mx} ${my} ${b.x} ${b.y}`} stroke="#D4AF37" strokeWidth=".6" fill="none" strokeDasharray="1.5 1.5" />
        <circle cx={a.x} cy={a.y} r="2.4" fill="#218653" stroke="#fff" strokeWidth=".8" />
        <g transform={`translate(${b.x} ${b.y})`}><path d="M0 0 C -3 -4, -3 -7, 0 -7 C 3 -7, 3 -4, 0 0Z" fill="#8B0000" transform="scale(1.1)" /><circle cy="-4.8" r="1.1" fill="#fff" /></g>
        {progress > 0 && (
          <g transform={`translate(${px} ${py})`}>
            <circle r="4.2" fill="#8B0000" opacity=".15" className="pulse-dot" />
            <circle r="2.6" fill="#242424" stroke="#D4AF37" strokeWidth=".8" />
            <text y=".9" fontSize="2.6" textAnchor="middle" fill="#fff">{vehicle === "bike" ? "🛵" : vehicle === "bus" ? "🚌" : vehicle === "box" ? "📦" : "🚗"}</text>
          </g>
        )}
      </svg>
      <div className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[11px] font-semibold text-muted shadow">Map preview · simulated{label ? ` · ${label}` : ""}</div>
    </div>
  );
}
