import { PageHeader, Card, Notice } from "@/components/ui";
export function Policy({ title, sections }: { title: string; sections: [string, string[]][] }) {
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={title} />
      <Notice tone="gold">Draft summary for the demo. Final legal text to be approved before launch.</Notice>
      {sections.map(([h, items]) => <Card key={h}><p className="mb-2 font-bold">{h}</p><ul className="list-disc space-y-1 pl-5 text-sm text-muted">{items.map((x) => <li key={x}>{x}</li>)}</ul></Card>)}
    </div>
  );
}
