"use client";
import Link from "next/link";
import { useState } from "react";
import { Car, Bus, Package, ShoppingBasket, Wheat, Milk, Pill, Sprout, ShoppingCart, Wrench, Landmark, Flame, GraduationCap, HandHeart, Stethoscope, Briefcase, UtensilsCrossed, TrainFront, Wallet } from "lucide-react";
import { useApp, type Booking, type ModuleKey } from "@/lib/store";
import { Badge, Empty, PageHeader, Tabs, statusTone, Button } from "@/components/ui";
import { fmtDate, inr } from "@/lib/utils";

export const MOD_ICON: Record<ModuleKey, React.ComponentType<{ size?: number; className?: string }>> = {
  auto: Car, cab: Car, bus: Bus, metro: TrainFront, parcel: Package, grocery: ShoppingBasket, ration: Wheat, milk: Milk, medicine: Pill,
  uzhavar: Sprout, coop: ShoppingCart, home: Wrench, government: Landmark, temple: Flame, prasadam: Flame, education: GraduationCap,
  counselling: HandHeart, healthcare: Stethoscope, jobs: Briefcase, food: UtensilsCrossed, takeaway: UtensilsCrossed, table: UtensilsCrossed, wallet: Wallet,
};

export function BookingRow({ b }: { b: Booking }) {
  const I = MOD_ICON[b.module] ?? Package;
  return (
    <Link href={`/bookings/detail?id=${b.id}`} className="card flex items-center gap-3 p-3.5 hover:shadow-[var(--shadow-lift)]">
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary"><I size={22} /></span>
      <div className="min-w-0 flex-1">
        <p className="truncate font-semibold">{b.title}</p>
        <p className="truncate text-sm text-muted">{b.subtitle}</p>
        <p className="text-xs text-muted">{b.id} · {fmtDate(b.createdAt, true)}</p>
      </div>
      <div className="text-right">
        <p className="font-bold">{b.amount ? inr(b.amount) : "Free"}</p>
        <Badge tone={statusTone(b.status === "active" ? b.stages[b.stageIdx] : b.status)}>{b.status === "active" ? b.stages[b.stageIdx] : b.status}</Badge>
      </div>
    </Link>
  );
}

export function BookingList({ kind }: { kind: "bookings" | "orders" }) {
  const { s, t } = useApp();
  const [tab, setTab] = useState<"all" | "active" | "completed" | "cancelled">("all");
  const base = s.bookings.filter((b) => (kind === "orders" ? b.kind === "order" : b.kind !== "order"));
  const list = base.filter((b) => tab === "all" || (tab === "active" ? b.status === "active" || b.status === "paused" : b.status === tab));
  return (
    <div>
      <PageHeader title={kind === "orders" ? t("orders") : t("bookings")} sub={kind === "orders" ? "Groceries, essentials, food and prasadam" : "Rides, tickets, services, appointments and applications"} back={false}
        right={<Button size="sm" variant="outline" href={kind === "orders" ? "/bookings" : "/orders"}>{kind === "orders" ? t("bookings") : t("orders")}</Button>} />
      <Tabs className="mb-4" value={tab} onChange={setTab} tabs={[
        { value: "all", label: t("all"), count: base.length }, { value: "active", label: t("active"), count: base.filter((b) => b.status === "active" || b.status === "paused").length },
        { value: "completed", label: t("completed") }, { value: "cancelled", label: t("cancelled") }]} />
      {list.length === 0 ? <Empty title={t("noItems")} body="Book a ride, order essentials or apply for a service to see it here." action={<Button href="/services">Explore services</Button>} />
        : <div className="grid gap-3 lg:grid-cols-2">{list.map((b) => <BookingRow key={b.id} b={b} />)}</div>}
    </div>
  );
}
