"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Wallet, Smartphone, CreditCard, Landmark, CheckCircle2, XCircle, Lock, Banknote } from "lucide-react";
import { Button, Sheet, Notice, SimTag, Input, KV } from "@/components/ui";
import { useApp, type Booking, type Fee } from "@/lib/store";
import { cn, inr, sum } from "@/lib/utils";

export type Draft = Omit<Booking, "id" | "createdAt" | "otp" | "amount" | "payment"> & { amount?: number };

const METHODS = [
  { id: "Wallet", label: "ONETN Wallet", icon: Wallet },
  { id: "UPI", label: "UPI", icon: Smartphone },
  { id: "Card", label: "Debit / Credit card", icon: CreditCard },
  { id: "Net banking", label: "Net banking", icon: Landmark },
  { id: "Cash", label: "Cash on delivery / at venue", icon: Banknote },
];

export function FeeTable({ fees, total }: { fees: Fee[]; total?: number }) {
  const tot = total ?? sum(fees.map((f) => f.amount));
  return (
    <div>
      <KV rows={fees.map((f) => [<span key="l">{f.label}{f.payee && <span className="block text-[11px] text-muted">→ {f.payee}</span>}{f.note && <span className="block text-[11px] text-muted">{f.note}</span>}</span>, f.amount < 0 ? <span className="text-success">{inr(f.amount)}</span> : f.amount === 0 ? "Free" : inr(f.amount)])} />
      <div className="mt-1 flex items-center justify-between border-t-2 border-dashed border-line pt-3 text-base font-bold"><span>Total payable</span><span>{inr(tot)}</span></div>
    </div>
  );
}

export function PaymentSheet({ open, onClose, title, fees, onPaid, allowCash, category }: {
  open: boolean; onClose: () => void; title: string; fees: Fee[]; category: string; allowCash?: boolean;
  onPaid: (method: string, txnId: string) => void;
}) {
  const { s, pay, toast } = useApp();
  const total = Math.max(0, sum(fees.map((f) => f.amount)));
  const [method, setMethod] = useState("Wallet");
  const [stage, setStage] = useState<"choose" | "pin" | "processing" | "ok" | "fail">("choose");
  const [pin, setPin] = useState("");
  const [upi, setUpi] = useState("priya@okbank");
  const [simFail, setSimFail] = useState(false);
  const [err, setErr] = useState("");
  const [txn, setTxn] = useState("");
  const reset = () => { setStage("choose"); setPin(""); setErr(""); };
  const close = () => { reset(); onClose(); };

  const proceed = () => {
    if (method === "UPI" && !/^[\w.-]{2,}@[a-z]{2,}$/i.test(upi)) return setErr("Enter a valid UPI ID, e.g. name@bank");
    if (method === "Wallet" && s.wallet.balance < total) return setErr("Insufficient Wallet balance – add money or choose another method.");
    setErr(""); setStage("pin");
  };
  const authorise = () => {
    if (method !== "Cash" && pin !== "1234") return setErr("Incorrect PIN / OTP. Demo PIN is 1234.");
    setErr(""); setStage("processing");
    setTimeout(() => {
      if (method === "Cash") { setTxn("CASH"); setStage("ok"); return; }
      const r = pay({ amount: total, title, category, method, fail: simFail });
      setTxn(r.txnId);
      if (r.ok) setStage("ok"); else { setErr(r.reason ?? "Payment failed"); setStage("fail"); toast("Payment failed", "error"); }
    }, 1100);
  };
  const methods = METHODS.filter((m) => allowCash || m.id !== "Cash");
  return (
    <Sheet open={open} onClose={close} title={stage === "ok" ? "Payment successful" : stage === "fail" ? "Payment failed" : "Review & pay"}
      footer={
        stage === "choose" ? <Button full size="lg" onClick={proceed}>Pay {inr(total)}</Button>
          : stage === "pin" ? <Button full size="lg" onClick={authorise}>{method === "Cash" ? "Confirm booking" : "Authorise payment"}</Button>
          : stage === "ok" ? <Button full size="lg" onClick={() => { const m = method, t = txn; reset(); onPaid(m, t); }}>Continue</Button>
          : stage === "fail" ? <div className="flex gap-2"><Button variant="outline" full onClick={close}>Cancel</Button><Button full onClick={reset}>Retry</Button></div>
          : null
      }>
      {stage === "choose" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between"><p className="font-semibold">{title}</p><SimTag label="Simulated payment" /></div>
          <div className="card"><FeeTable fees={fees} /></div>
          <p className="text-xs text-muted">Every fee is shown before you pay. Demo fee levels are placeholders pending Government approval.</p>
          <div>
            <p className="mb-2 text-sm font-semibold">Payment method</p>
            <div className="space-y-2">
              {methods.map((m) => (
                <button key={m.id} onClick={() => setMethod(m.id)} className={cn("flex w-full items-center gap-3 rounded-2xl border bg-white p-3 text-left", method === m.id ? "border-primary ring-4 ring-primary/10" : "border-line")}>
                  <m.icon size={20} className="text-primary" />
                  <span className="flex-1 font-medium">{m.label}{m.id === "Wallet" && <span className="block text-xs text-muted">Balance {inr(s.wallet.balance)}{s.wallet.frozen && " · Frozen"}</span>}</span>
                  <span className={cn("h-5 w-5 rounded-full border-2", method === m.id ? "border-[6px] border-primary" : "border-line")} />
                </button>
              ))}
            </div>
            {method === "UPI" && <Input className="mt-2" value={upi} onChange={(e) => setUpi(e.target.value)} placeholder="yourname@bank" aria-label="UPI ID" />}
          </div>
          <label className="flex items-center gap-2 text-sm text-muted"><input type="checkbox" checked={simFail} onChange={(e) => setSimFail(e.target.checked)} className="accent-[#8B0000]" />Simulate a payment failure (for testing)</label>
          {err && <Notice tone="error">{err}</Notice>}
        </div>
      )}
      {stage === "pin" && (
        <div className="space-y-4 py-2 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary-soft text-primary"><Lock /></span>
          {method === "Cash" ? <p>Pay <b>{inr(total)}</b> in cash at delivery / venue. Confirm to place the booking.</p> : (
            <>
              <p className="font-semibold">{method === "Wallet" ? "Enter Wallet transaction PIN" : method === "Card" ? "Enter the OTP sent by your bank" : `Approve on your ${method} app – enter PIN`}</p>
              <Input type="password" inputMode="numeric" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} className="mx-auto max-w-40 text-center text-2xl tracking-[.5em]" aria-label="PIN" autoFocus />
              <p className="text-xs text-muted">Demo PIN / OTP: 1234</p>
            </>
          )}
          {err && <Notice tone="error">{err}</Notice>}
        </div>
      )}
      {stage === "processing" && (
        <div className="flex flex-col items-center py-10"><span className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" /><p className="mt-4 font-semibold">Processing {inr(total)}…</p><p className="text-sm text-muted">Do not close this window</p></div>
      )}
      {stage === "ok" && (
        <div className="flex flex-col items-center py-6 text-center">
          <CheckCircle2 size={64} className="text-success" />
          <p className="mt-3 text-2xl font-extrabold">{inr(total)}</p>
          <p className="text-muted">{method === "Cash" ? "To be paid in cash" : `Paid via ${method}`}</p>
          <p className="mt-2 text-xs text-muted">Transaction ID {txn} · simulated</p>
        </div>
      )}
      {stage === "fail" && (
        <div className="flex flex-col items-center py-6 text-center">
          <XCircle size={64} className="text-error" />
          <p className="mt-3 font-bold">{err}</p>
          <p className="mt-1 text-sm text-muted">No money was deducted. Transaction {txn} recorded as failed.</p>
        </div>
      )}
    </Sheet>
  );
}

/** One-tap checkout: validates, opens payment, creates booking/order, notifies and routes to tracking. */
export function CheckoutButton({ label, build, validate, category, allowCash, disabled, full = true, size = "lg", onDone }: {
  label: string; build: () => Draft; validate?: () => string | null; category: string; allowCash?: boolean; disabled?: boolean; full?: boolean; size?: "md" | "lg"; onDone?: (b: Booking) => void;
}) {
  const { addBooking, notify, toast } = useApp();
  const r = useRouter();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(null);
  return (
    <>
      <Button full={full} size={size} disabled={disabled} onClick={() => {
        const e = validate?.(); if (e) { toast(e, "error"); return; }
        const d = build();
        if (sum(d.fees.map((f) => f.amount)) <= 0) {
          const b = addBooking({ ...d, amount: 0, payment: "No charge" } as Booking);
          notify(`${d.title} confirmed`, b.id, `/bookings/detail?id=${b.id}`); toast(`Confirmed · ${b.id}`);
          if (onDone) onDone(b); else r.push(`/bookings/detail?id=${b.id}`);
          return;
        }
        setDraft(d); setOpen(true);
      }}>{label}</Button>
      {draft && (
        <PaymentSheet open={open} onClose={() => setOpen(false)} title={draft.title} fees={draft.fees} category={category} allowCash={allowCash}
          onPaid={(method) => {
            const b = addBooking({ ...draft, amount: Math.max(0, sum(draft.fees.map((f) => f.amount))), payment: method } as Booking);
            notify(`${draft.title} confirmed`, `${b.id} · ${draft.subtitle ?? ""}`.trim(), `/bookings/detail?id=${b.id}`);
            setOpen(false); toast(`${draft.kind === "order" ? "Order placed" : "Booking confirmed"} · ${b.id}`);
            if (onDone) onDone(b); else r.push(`/bookings/detail?id=${b.id}`);
          }} />
      )}
    </>
  );
}
