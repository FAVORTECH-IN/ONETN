"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ShoppingBag, Tag, MapPin, Clock } from "lucide-react";
import { useApp, type ModuleKey, type Fee } from "@/lib/store";
import { Button, Card, Chip, Empty, Input, Notice, Qty, Select, Sheet, Textarea } from "@/components/ui";
import { CheckoutButton, FeeTable } from "./Payment";
import { SLOTS, COUPONS } from "@/data/delivery";
import { cn, dayLabel, inr, nextDays, sum } from "@/lib/utils";

export type CartConfig = {
  cartKey: string; module: ModuleKey; title: string; store: string; category: string; deliveryFee: number; platformFee: number;
  stages?: string[]; repeatHref: string; coupons?: boolean; substitution?: boolean; instructions?: boolean; allowTakeaway?: boolean;
  extraFees?: Fee[]; notice?: React.ReactNode; validate?: () => string | null; extraDetails?: Record<string, string>; freeDeliveryAbove?: number; kind?: "order" | "booking";
};

export function CartBar({ cartKey, onOpen }: { cartKey: string; onOpen: () => void }) {
  const { cart } = useApp();
  const items = cart(cartKey);
  const count = sum(items.map((i) => i.qty));
  if (!count) return null;
  return (
    <div className="fixed inset-x-0 bottom-[76px] z-30 px-4 lg:bottom-6 lg:left-64">
      <button onClick={onOpen} className="mx-auto flex w-full max-w-lg items-center justify-between rounded-2xl bg-primary px-5 py-3.5 text-white shadow-[var(--shadow-lift)]">
        <span className="flex items-center gap-2 font-semibold"><ShoppingBag size={19} />{count} item{count > 1 ? "s" : ""} · {inr(sum(items.map((i) => i.price * i.qty)))}</span>
        <span className="font-bold">View cart →</span>
      </button>
    </div>
  );
}

export function CartSheet({ open, onClose, cfg }: { open: boolean; onClose: () => void; cfg: CartConfig }) {
  const { s, cart, setQty, clearCart } = useApp();
  const router = useRouter();
  const items = cart(cfg.cartKey);
  const [addr, setAddr] = useState(s.addresses[0]?.id ?? "");
  const [day, setDay] = useState(0);
  const [slot, setSlot] = useState("");
  const [sub, setSub] = useState("Call me");
  const [notes, setNotes] = useState("");
  const [code, setCode] = useState("");
  const [applied, setApplied] = useState<(typeof COUPONS)[number] | null>(null);
  const [mode, setMode] = useState<"Delivery" | "Takeaway">("Delivery");
  const [err, setErr] = useState("");
  const subtotal = sum(items.map((i) => i.price * i.qty));
  const delivery = mode === "Takeaway" ? 0 : cfg.freeDeliveryAbove && subtotal >= cfg.freeDeliveryAbove ? 0 : cfg.deliveryFee;
  const discount = applied && subtotal >= applied.min ? applied.off : 0;
  const fees: Fee[] = [
    { label: `Items (${sum(items.map((i) => i.qty))})`, amount: subtotal },
    ...(mode === "Delivery" ? [{ label: "Delivery fee", amount: delivery, note: cfg.freeDeliveryAbove ? `Free above ${inr(cfg.freeDeliveryAbove)}` : undefined }] : []),
    ...(cfg.platformFee ? [{ label: "Platform fee", amount: cfg.platformFee }] : []),
    ...(cfg.extraFees ?? []),
    ...(discount ? [{ label: `Coupon ${applied!.code}`, amount: -discount }] : []),
  ];
  const days = nextDays(3);
  const address = s.addresses.find((a) => a.id === addr);
  const stages = cfg.stages ?? (mode === "Takeaway" ? ["Order placed", "Accepted", "Preparing", "Ready for pickup", "Picked up"] : ["Order placed", "Store preparing", "Rider assigned", "Out for delivery", "Delivered"]);
  return (
    <Sheet open={open} onClose={onClose} title={`Cart · ${cfg.store}`} wide
      footer={items.length ? (
        <CheckoutButton label={`Proceed to pay ${inr(Math.max(0, sum(fees.map((f) => f.amount))))}`} category={cfg.category}
          validate={() => { if (mode === "Delivery" && !address) return "Select a delivery address"; if (!slot) return "Choose a delivery / pickup slot"; return cfg.validate?.() ?? null; }}
          build={() => ({
            module: mode === "Takeaway" && cfg.module === "food" ? "takeaway" : cfg.module, kind: cfg.kind ?? "order", title: mode === "Takeaway" ? `${cfg.title} (takeaway)` : cfg.title,
            subtitle: `${cfg.store} · ${sum(items.map((i) => i.qty))} items`, stages, stageIdx: 0, status: "active", fees,
            items: items.map((i) => ({ name: i.name, qty: i.qty, price: i.price })),
            details: { Store: cfg.store, Mode: mode, ...(mode === "Delivery" ? { "Deliver to": address?.line ?? "" } : {}), Slot: `${dayLabel(days[day])}, ${slot}`, ...(cfg.substitution ? { "If unavailable": sub } : {}), ...(notes ? { Instructions: notes } : {}), ...(cfg.extraDetails ?? {}), _cart: cfg.cartKey, _repeat: cfg.repeatHref },
            provider: mode === "Delivery" ? { name: "Rider: Dinesh Kumar", rating: 4.8, vehicle: "TN 09 EV 2231 · e-scooter" } : undefined,
          })}
          onDone={(b) => { clearCart(cfg.cartKey); onClose(); router.push(`/bookings/detail?id=${b.id}`); }}
        />
      ) : undefined}>
      {items.length === 0 ? <Empty title="Your cart is empty" body="Add items to continue." /> : (
        <div className="space-y-4">
          {cfg.notice}
          <Card className="divide-y divide-line p-0">
            {items.map((i) => (
              <div key={i.id} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{i.name}</p><p className="text-xs text-muted">{i.unit} · {inr(i.price)}</p></div>
                <Qty value={i.qty} onChange={(v) => setQty(cfg.cartKey, i, v)} />
                <p className="w-16 text-right text-sm font-bold">{inr(i.price * i.qty)}</p>
              </div>
            ))}
          </Card>
          {cfg.allowTakeaway && <div className="flex gap-2">{(["Delivery", "Takeaway"] as const).map((m) => <Chip key={m} active={mode === m} onClick={() => setMode(m)}>{m}</Chip>)}</div>}
          {mode === "Delivery" && (
            <div>
              <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><MapPin size={16} />Delivery address</p>
              <Select value={addr} onChange={(e) => setAddr(e.target.value)} options={s.addresses.map((a) => ({ value: a.id, label: `${a.label} – ${a.line}` }))} placeholder="Select address" />
            </div>
          )}
          <div>
            <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><Clock size={16} />{mode === "Takeaway" ? "Pickup time" : "Delivery slot"}</p>
            <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">{days.map((d, i) => <Chip key={i} active={day === i} onClick={() => setDay(i)}>{i === 0 ? "Today" : dayLabel(d)}</Chip>)}</div>
            <div className="flex flex-wrap gap-2">{(day === 0 ? ["ASAP (~25 min)", ...SLOTS.slice(4)] : SLOTS).map((x) => <Chip key={x} active={slot === x} onClick={() => setSlot(x)}>{x}</Chip>)}</div>
          </div>
          {cfg.substitution && (
            <div><p className="mb-2 text-sm font-semibold">If an item is unavailable</p>
              <div className="flex flex-wrap gap-2">{["Call me", "Replace with similar", "Remove item & refund"].map((x) => <Chip key={x} active={sub === x} onClick={() => setSub(x)}>{x}</Chip>)}</div></div>
          )}
          {cfg.instructions && <Textarea placeholder="Special instructions (e.g. less spicy, ring the bell)" value={notes} onChange={(e) => setNotes(e.target.value)} />}
          {cfg.coupons && (
            <div>
              <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><Tag size={16} />Coupon</p>
              <div className="flex gap-2"><Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Enter code" />
                <Button variant="outline" onClick={() => { const c = COUPONS.find((x) => x.code === code); if (!c) return setErr("Invalid coupon"); if (subtotal < c.min) return setErr(`Add ${inr(c.min - subtotal)} more to use ${c.code}`); setErr(""); setApplied(c); }}>Apply</Button></div>
              <div className="mt-2 space-y-1">{COUPONS.map((c) => <button key={c.code} onClick={() => setCode(c.code)} className={cn("block text-left text-xs", applied?.code === c.code ? "text-success" : "text-muted")}><b>{c.code}</b> – {c.desc}</button>)}</div>
              {err && <p className="mt-1 text-xs text-error">{err}</p>}
            </div>
          )}
          <Card><p className="mb-2 font-bold">Price breakdown</p><FeeTable fees={fees} /></Card>
          <Notice tone="info">No hidden charges. Wrong, damaged or missing items are refunded to your Wallet.</Notice>
        </div>
      )}
    </Sheet>
  );
}
