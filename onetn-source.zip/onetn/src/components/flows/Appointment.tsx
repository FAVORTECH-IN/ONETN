"use client";
import { useState } from "react";
import { Lock } from "lucide-react";
import { useApp, type ModuleKey } from "@/lib/store";
import { APPT_SLOTS } from "@/data/learning";
import { Chip, Field, Notice, Sheet, Textarea, Select } from "@/components/ui";
import { CheckoutButton } from "./Payment";
import { dayLabel, inr, nextDays } from "@/lib/utils";

export function AppointmentSheet({ open, onClose, who, role, fee, modes, module, place, privateNote }: { open: boolean; onClose: () => void; who: string; role: string; fee: number; modes: string[]; module: ModuleKey; place: string; privateNote?: boolean }) {
  const { s } = useApp();
  const [mode, setMode] = useState(modes[0]);
  const [day, setDay] = useState(1);
  const [slot, setSlot] = useState("");
  const [reason, setReason] = useState("");
  const [forWhom, setFor] = useState("Self");
  const days = nextDays(8);
  const taken = (i: number) => (i + day) % 4 === 0;
  return (
    <Sheet open={open} onClose={onClose} title={`Book ${who}`}
      footer={<CheckoutButton label={`Pay ${inr(fee + 10)} & confirm`} category={module === "healthcare" ? "Healthcare" : "Education"}
        validate={() => (!slot ? "Choose a time slot" : null)}
        build={() => ({ module, kind: "appointment", title: `${role}: ${who}`, subtitle: `${mode} · ${dayLabel(days[day])}, ${slot}`, when: `${dayLabel(days[day])}, ${slot}`, status: "active", stageIdx: 0,
          stages: ["Appointment confirmed", "Reminder sent", "Session in progress", "Completed"],
          fees: [{ label: `${role} fee`, amount: fee, payee: who }, { label: "Booking fee", amount: 10 }],
          details: { With: who, Mode: mode, Date: dayLabel(days[day]), Time: slot, Place: mode === "In person" ? place : "In-app video", For: forWhom, ...(reason ? { Reason: privateNote ? "Shared privately with professional" : reason } : {}) },
          provider: { name: who, extra: role } })} />}>
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">{modes.map((m) => <Chip key={m} active={mode === m} onClick={() => setMode(m)}>{m === "Online" || m === "Video" ? `${m} (in-app video)` : m}</Chip>)}</div>
        <Field label="Appointment for"><Select value={forWhom} onChange={(e) => setFor(e.target.value)} options={["Self", ...s.family.map((f) => `${f.name} (${f.relation})`)]} /></Field>
        <div><p className="mb-2 text-sm font-semibold">Date</p><div className="no-scrollbar flex gap-2 overflow-x-auto">{days.slice(1).map((d, i) => <Chip key={i} active={day === i + 1} onClick={() => { setDay(i + 1); setSlot(""); }}>{dayLabel(d)}</Chip>)}</div></div>
        <div><p className="mb-2 text-sm font-semibold">Available slots</p><div className="flex flex-wrap gap-2">{APPT_SLOTS.map((x, i) => <Chip key={x} active={slot === x} onClick={() => !taken(i) && setSlot(x)} className={taken(i) ? "pointer-events-none line-through opacity-40" : ""}>{x}</Chip>)}</div></div>
        <Field label="Reason / topic (optional)"><Textarea value={reason} onChange={(e) => setReason(e.target.value)} className="min-h-16" /></Field>
        {privateNote && <Notice tone="info"><Lock size={14} className="mr-1 inline" />Private: notes are visible only to you and the professional, and never shared without your consent. If you are in crisis, call 14416 (Tele-MANAS) or 112.</Notice>}
        {mode === "In person" && <p className="text-sm text-muted">Venue: {place}</p>}
      </div>
    </Sheet>
  );
}
