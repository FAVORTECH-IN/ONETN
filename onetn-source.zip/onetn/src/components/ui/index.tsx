"use client";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, ChevronRight, Info, Minus, Plus, Star, X, AlertTriangle, CheckCircle2, Inbox, FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/lib/store";

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "gold" | "outline" | "ghost" | "soft" | "danger" | "success";
  size?: "sm" | "md" | "lg"; full?: boolean; loading?: boolean; href?: string;
};
export function Button({ variant = "primary", size = "md", full, loading, className, children, href, disabled, ...rest }: BtnProps) {
  const cls = cn(
    "inline-flex items-center justify-center gap-2 font-semibold transition-all active:scale-[.98] disabled:opacity-50 disabled:pointer-events-none select-none",
    size === "sm" && "h-9 px-3.5 text-sm rounded-xl",
    size === "md" && "h-11 px-5 text-[15px] rounded-2xl",
    size === "lg" && "h-13 px-6 text-base rounded-2xl py-3.5",
    variant === "primary" && "bg-primary text-white hover:bg-primary-dark shadow-[0_6px_16px_rgba(139,0,0,.22)]",
    variant === "gold" && "bg-gold text-ink hover:brightness-95",
    variant === "outline" && "border border-line bg-white text-ink hover:border-primary/40",
    variant === "ghost" && "text-primary hover:bg-primary-soft",
    variant === "soft" && "bg-primary-soft text-primary hover:bg-primary/15",
    variant === "danger" && "bg-error text-white hover:brightness-95",
    variant === "success" && "bg-success text-white hover:brightness-95",
    full && "w-full",
    className
  );
  const content = loading ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" /> : children;
  if (href && !disabled) return <Link href={href} className={cls}>{content}</Link>;
  return <button className={cls} disabled={disabled || loading} {...rest}>{content}</button>;
}

export function Card({ className, children, onClick, as }: { className?: string; children: React.ReactNode; onClick?: () => void; as?: "button" | "div" }) {
  const El = (as ?? (onClick ? "button" : "div")) as "div";
  return <El onClick={onClick} className={cn("card p-4 text-left", onClick && "w-full transition hover:shadow-[var(--shadow-lift)] hover:-translate-y-px", className)}>{children}</El>;
}

export function Label({ children, required }: { children: React.ReactNode; required?: boolean }) {
  return <span className="mb-1.5 block text-[13px] font-semibold text-ink">{children}{required && <span className="text-error"> *</span>}</span>;
}
export function Field({ label, required, error, hint, children }: { label?: string; required?: boolean; error?: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      {label && <Label required={required}>{label}</Label>}
      {children}
      {error ? <span className="mt-1 block text-xs text-error">{error}</span> : hint ? <span className="mt-1 block text-xs text-muted">{hint}</span> : null}
    </label>
  );
}
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }>(
  function Input({ className, invalid, ...p }, ref) {
    return <input ref={ref} className={cn("h-12 w-full rounded-2xl border bg-white px-4 text-[15px] outline-none transition placeholder:text-muted/70 focus:border-primary focus:ring-4 focus:ring-primary/10", invalid ? "border-error" : "border-line", className)} {...p} />;
  });
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }>(
  function Textarea({ className, invalid, ...p }, ref) {
    return <textarea ref={ref} className={cn("min-h-24 w-full rounded-2xl border bg-white px-4 py-3 text-[15px] outline-none focus:border-primary focus:ring-4 focus:ring-primary/10", invalid ? "border-error" : "border-line", className)} {...p} />;
  });
export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean; options: (string | { value: string; label: string })[]; placeholder?: string }>(
  function Select({ className, invalid, options, placeholder, ...p }, ref) {
    return (
      <select ref={ref} className={cn("h-12 w-full rounded-2xl border bg-white px-4 text-[15px] outline-none focus:border-primary focus:ring-4 focus:ring-primary/10", invalid ? "border-error" : "border-line", className)} {...p}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => typeof o === "string" ? <option key={o} value={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    );
  });

export function Badge({ tone = "neutral", children, className }: { tone?: "neutral" | "primary" | "gold" | "success" | "warning" | "error" | "info"; children: React.ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold whitespace-nowrap",
      tone === "neutral" && "bg-cream text-muted border border-line",
      tone === "primary" && "bg-primary-soft text-primary",
      tone === "gold" && "bg-gold-soft text-[#7A5C00]",
      tone === "success" && "bg-success-soft text-success",
      tone === "warning" && "bg-warning-soft text-[#8A5500]",
      tone === "error" && "bg-error-soft text-error",
      tone === "info" && "bg-[#E6EEF8] text-[#1D4E89]", className)}>{children}</span>
  );
}
export function statusTone(s: string): "success" | "warning" | "error" | "info" | "neutral" | "primary" {
  const x = s.toLowerCase();
  if (/(complet|deliver|approv|resolv|success|paid|confirm|active|verified|closed|hired|issued|online)/.test(x)) return "success";
  if (/(reject|fail|cancel|suspend|declin|frozen|escalat)/.test(x)) return "error";
  if (/(pending|await|review|progress|prepar|paus|draft|shortlist|scheduled|assigned)/.test(x)) return "warning";
  return "info";
}

export function Chip({ active, onClick, children, className }: { active?: boolean; onClick?: () => void; children: React.ReactNode; className?: string }) {
  return (
    <button type="button" onClick={onClick} className={cn("h-9 shrink-0 rounded-full border px-4 text-sm font-medium transition whitespace-nowrap",
      active ? "border-primary bg-primary text-white" : "border-line bg-white text-ink hover:border-primary/40", className)}>{children}</button>
  );
}

export function Tabs<T extends string>({ tabs, value, onChange, className }: { tabs: { value: T; label: string; count?: number }[]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div className={cn("no-scrollbar flex gap-1 overflow-x-auto rounded-2xl border border-line bg-white p-1", className)}>
      {tabs.map((t) => (
        <button key={t.value} type="button" onClick={() => onChange(t.value)}
          className={cn("h-9 flex-1 shrink-0 whitespace-nowrap rounded-xl px-3 text-sm font-semibold transition", value === t.value ? "bg-primary text-white" : "text-muted hover:text-ink")}>
          {t.label}{t.count !== undefined && <span className="ml-1 opacity-80">({t.count})</span>}
        </button>
      ))}
    </div>
  );
}

export function Sheet({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title?: string; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={cn("fade-in relative flex max-h-[92vh] w-full flex-col rounded-t-[26px] bg-cream sm:rounded-[22px]", wide ? "sm:max-w-2xl" : "sm:max-w-md")}>
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
          <h3 className="text-base font-bold">{title}</h3>
          <button onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full bg-white border border-line"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="border-t border-line bg-white px-5 py-3 safe-bottom">{footer}</div>}
      </div>
    </div>
  );
}

export function Stepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="flex items-center gap-1.5" aria-label={`Step ${current + 1} of ${steps.length}`}>
      {steps.map((s, i) => (
        <div key={s} className="flex flex-1 flex-col gap-1">
          <div className={cn("h-1.5 rounded-full", i <= current ? "bg-primary" : "bg-line")} />
          <span className={cn("hidden truncate text-[11px] sm:block", i === current ? "font-semibold text-primary" : "text-muted")}>{s}</span>
        </div>
      ))}
    </div>
  );
}

export function Timeline({ stages, current, times }: { stages: string[]; current: number; times?: (string | undefined)[] }) {
  return (
    <ol className="relative space-y-4">
      {stages.map((s, i) => {
        const done = i < current, now = i === current;
        return (
          <li key={s + i} className="flex gap-3">
            <div className="flex flex-col items-center">
              <span className={cn("grid h-7 w-7 place-items-center rounded-full border-2 text-xs font-bold",
                done && "border-success bg-success text-white", now && "border-primary bg-primary text-white", !done && !now && "border-line bg-white text-muted")}>
                {done ? <Check size={14} /> : i + 1}
              </span>
              {i < stages.length - 1 && <span className={cn("mt-1 w-0.5 flex-1 min-h-4", done ? "bg-success" : "bg-line")} />}
            </div>
            <div className="pb-1">
              <p className={cn("text-sm font-semibold", !done && !now && "text-muted")}>{s}</p>
              {now && <p className="text-xs text-primary pulse-dot">In progress</p>}
              {times?.[i] && <p className="text-xs text-muted">{times[i]}</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export function Empty({ title, body, action }: { title: string; body?: string; action?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-10 text-center">
      <span className="mb-3 grid h-14 w-14 place-items-center rounded-full bg-gold-soft text-[#7A5C00]"><Inbox /></span>
      <p className="font-semibold">{title}</p>
      {body && <p className="mt-1 max-w-xs text-sm text-muted">{body}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function SectionHeader({ title, href, action, sub }: { title: string; href?: string; action?: string; sub?: string }) {
  const { t } = useApp();
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        <h2 className="text-[17px] font-bold text-ink">{title}</h2>
        {sub && <p className="text-xs text-muted">{sub}</p>}
      </div>
      {href && <Link href={href} className="flex items-center text-sm font-semibold text-primary">{action ?? t("seeAll")}<ChevronRight size={16} /></Link>}
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)}
      className={cn("relative h-7 w-12 shrink-0 rounded-full transition", checked ? "bg-success" : "bg-line")}>
      <span className={cn("absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
    </button>
  );
}

export function Stars({ value, onChange, size = 22 }: { value: number; onChange?: (v: number) => void; size?: number }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={!onChange} onClick={() => onChange?.(n)} aria-label={`${n} star`}>
          <Star size={size} className={n <= value ? "fill-gold text-gold" : "text-line"} />
        </button>
      ))}
    </div>
  );
}

export function Rating({ value, count }: { value: number; count?: number }) {
  return <span className="inline-flex items-center gap-1 text-xs font-semibold"><Star size={13} className="fill-gold text-gold" />{value.toFixed(1)}{count !== undefined && <span className="font-normal text-muted">({count})</span>}</span>;
}

export function Qty({ value, onChange, min = 0, max = 99 }: { value: number; onChange: (v: number) => void; min?: number; max?: number }) {
  if (value <= 0 && min === 0)
    return <button onClick={() => onChange(1)} className="h-9 rounded-xl border border-primary bg-white px-4 text-sm font-bold text-primary hover:bg-primary-soft">ADD</button>;
  return (
    <div className="flex h-9 items-center rounded-xl bg-primary text-white">
      <button aria-label="Decrease" onClick={() => onChange(Math.max(min, value - 1))} className="grid h-9 w-9 place-items-center"><Minus size={16} /></button>
      <span className="w-6 text-center text-sm font-bold">{value}</span>
      <button aria-label="Increase" onClick={() => onChange(Math.min(max, value + 1))} className="grid h-9 w-9 place-items-center"><Plus size={16} /></button>
    </div>
  );
}

export function Avatar({ name, size = 44, tone = "primary" }: { name: string; size?: number; tone?: "primary" | "gold" }) {
  const ini = name.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase();
  return <span style={{ width: size, height: size, fontSize: size * 0.36 }} className={cn("grid shrink-0 place-items-center rounded-full font-bold", tone === "primary" ? "bg-primary-soft text-primary" : "bg-gold-soft text-[#7A5C00]")}>{ini}</span>;
}

export function Notice({ tone = "info", title, children, className }: { tone?: "info" | "warning" | "success" | "error" | "gold"; title?: string; children?: React.ReactNode; className?: string }) {
  const Icon = tone === "warning" || tone === "error" ? AlertTriangle : tone === "success" ? CheckCircle2 : Info;
  return (
    <div className={cn("flex gap-3 rounded-2xl border p-3.5 text-sm",
      tone === "info" && "border-[#CFDDF0] bg-[#F0F5FB] text-[#1D4E89]",
      tone === "warning" && "border-[#F1DBB4] bg-warning-soft text-[#7A4B00]",
      tone === "success" && "border-[#C2E3D0] bg-success-soft text-success",
      tone === "error" && "border-[#F2C6C6] bg-error-soft text-error",
      tone === "gold" && "border-[#EBD9A0] bg-gold-soft text-[#5E4700]", className)}>
      <Icon size={18} className="mt-0.5 shrink-0" />
      <div>{title && <p className="font-semibold">{title}</p>}{children && <div className="opacity-90">{children}</div>}</div>
    </div>
  );
}

export function SimTag({ label = "Simulated" }: { label?: string }) {
  return <span className="inline-flex items-center gap-1 rounded-full border border-dashed border-warning bg-warning-soft px-2 py-0.5 text-[11px] font-semibold text-[#8A5500]"><FlaskConical size={12} />{label}</span>;
}

export function KV({ rows }: { rows: [React.ReactNode, React.ReactNode][] }) {
  return (
    <dl className="divide-y divide-line">
      {rows.map(([k, v], i) => (
        <div key={i} className="flex items-start justify-between gap-4 py-2.5 text-sm">
          <dt className="text-muted">{k}</dt><dd className="text-right font-medium">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function PageHeader({ title, sub, back = true, right, backHref }: { title: string; sub?: string; back?: boolean; right?: React.ReactNode; backHref?: string }) {
  const r = useRouter();
  return (
    <div className="mb-4 flex items-center gap-3">
      {back && (
        <button aria-label="Back" onClick={() => (backHref ? r.push(backHref) : window.history.length > 1 ? r.back() : r.push("/home"))}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-line bg-white"><ArrowLeft size={19} /></button>
      )}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-xl font-bold">{title}</h1>
        {sub && <p className="truncate text-sm text-muted">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function IconTile({ icon: Icon, tone = "primary", size = 48 }: { icon: React.ComponentType<{ size?: number; className?: string }>; tone?: "primary" | "gold" | "success" | "info" | "warning"; size?: number }) {
  return (
    <span style={{ width: size, height: size }} className={cn("grid shrink-0 place-items-center rounded-2xl",
      tone === "primary" && "bg-primary-soft text-primary", tone === "gold" && "bg-gold-soft text-[#8A6A00]",
      tone === "success" && "bg-success-soft text-success", tone === "info" && "bg-[#E6EEF8] text-[#1D4E89]", tone === "warning" && "bg-warning-soft text-warning")}>
      <Icon size={Math.round(size * 0.5)} />
    </span>
  );
}

export function Toaster() {
  const { toasts } = useApp();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[80] flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => (
        <div key={t.id} className={cn("fade-in pointer-events-auto flex max-w-sm items-center gap-2 rounded-2xl px-4 py-3 text-sm font-medium text-white shadow-lg",
          t.tone === "error" ? "bg-error" : t.tone === "info" ? "bg-ink" : "bg-success")}>
          {t.tone === "error" ? <AlertTriangle size={16} /> : <CheckCircle2 size={16} />}{t.msg}
        </div>
      ))}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-xl bg-line/60", className)} />;
}

export function useLoading(ms = 450) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), ms); return () => clearTimeout(t); }, [ms]);
  return loading;
}

export function ListSkeleton({ n = 4 }: { n?: number }) {
  return <div className="space-y-3">{Array.from({ length: n }).map((_, i) => <Skeleton key={i} className="h-20" />)}</div>;
}

export function Thumb({ hue = 0, icon: Icon, label, className, size = 64 }: { hue?: number; icon?: React.ComponentType<{ size?: number; className?: string }>; label?: string; className?: string; size?: number }) {
  const bgs = ["#F6E3E0", "#F7EDCB", "#E3F3EA", "#E6EEF8", "#FBF0DD", "#EFE6F6", "#E4F1F1"];
  const fgs = ["#8B0000", "#8A6A00", "#218653", "#1D4E89", "#B5700D", "#5B3A86", "#1F6F6F"];
  const i = Math.abs(hue) % bgs.length;
  return (
    <div className={cn("relative grid shrink-0 place-items-center overflow-hidden rounded-2xl", className)} style={{ background: bgs[i], color: fgs[i], width: className?.includes("w-") ? undefined : size, height: className?.includes("h-") ? undefined : size }}>
      <svg className="absolute inset-0 h-full w-full opacity-[.18]" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden><circle cx="85" cy="15" r="30" fill="currentColor" /><circle cx="10" cy="95" r="22" fill="currentColor" /></svg>
      {Icon && <Icon size={Math.max(20, Math.round(size * 0.42))} className="relative" />}
      {label && <span className="relative mt-1 text-[10px] font-bold uppercase tracking-wide">{label}</span>}
    </div>
  );
}

export function ListRow({ icon, title, sub, right, href, onClick }: { icon?: React.ReactNode; title: React.ReactNode; sub?: React.ReactNode; right?: React.ReactNode; href?: string; onClick?: () => void }) {
  const inner = (
    <>
      {icon}
      <div className="min-w-0 flex-1"><p className="truncate font-semibold">{title}</p>{sub && <div className="truncate text-sm text-muted">{sub}</div>}</div>
      {right ?? ((href || onClick) && <ChevronRight size={18} className="text-muted" />)}
    </>
  );
  const cls = "flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-cream/60";
  if (href) return <Link href={href} className={cls}>{inner}</Link>;
  if (onClick) return <button onClick={onClick} className={cls}>{inner}</button>;
  return <div className={cls}>{inner}</div>;
}
