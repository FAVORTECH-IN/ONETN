"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { Home, LayoutGrid, CalendarCheck, Wallet, UserRound, Bell, MapPin, FileText, Package, LifeBuoy, LogOut, ArrowLeftRight } from "lucide-react";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Logo } from "./Logo";
import { LangToggle } from "./AuthFrame";
import { Avatar } from "@/components/ui";

export function CitizenShell({ children }: { children: React.ReactNode }) {
  const { s, ready, t, logout } = useApp();
  const path = usePathname();
  const r = useRouter();
  useEffect(() => { if (ready && !s.user) r.replace("/login"); }, [ready, s.user, r]);
  const nav = [
    { href: "/home", label: t("home"), icon: Home },
    { href: "/services", label: t("services"), icon: LayoutGrid },
    { href: "/bookings", label: t("bookings"), icon: CalendarCheck },
    { href: "/wallet", label: t("wallet"), icon: Wallet },
    { href: "/profile", label: t("profile"), icon: UserRound },
  ];
  const extra = [
    { href: "/orders", label: t("orders"), icon: Package },
    { href: "/grievance", label: t("grievance"), icon: FileText },
    { href: "/notifications", label: t("notifications"), icon: Bell },
    { href: "/support", label: t("support"), icon: LifeBuoy },
  ];
  const active = (h: string) => path === h || path.startsWith(h + "/") || (h === "/services" && path.startsWith("/services"));
  const unread = s.notifications.filter((n) => !n.read).length;
  if (!ready || !s.user) return <div className="grid min-h-dvh place-items-center"><span className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" /></div>;
  return (
    <div className="min-h-dvh lg:flex">
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-line bg-white px-4 py-5 lg:flex">
        <Link href="/home" className="px-2"><Logo size={36} tagline /></Link>
        <nav className="mt-8 space-y-1">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className={cn("flex items-center gap-3 rounded-2xl px-3 py-2.5 font-semibold", active(n.href) ? "bg-primary text-white" : "text-muted hover:bg-cream hover:text-ink")}>
              <n.icon size={19} />{n.label}
            </Link>
          ))}
          <div className="my-3 border-t border-line" />
          {extra.map((n) => (
            <Link key={n.href} href={n.href} className={cn("flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold", active(n.href) ? "bg-primary-soft text-primary" : "text-muted hover:bg-cream hover:text-ink")}>
              <n.icon size={18} />{n.label}{n.href === "/notifications" && unread > 0 && <span className="ml-auto rounded-full bg-primary px-2 text-xs text-white">{unread}</span>}
            </Link>
          ))}
        </nav>
        <div className="mt-auto space-y-2">
          <Link href="/select-role" className="flex items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold text-muted hover:bg-cream"><ArrowLeftRight size={16} />Switch role / portal</Link>
          <button onClick={() => { logout(); r.replace("/login"); }} className="flex w-full items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold text-muted hover:bg-cream"><LogOut size={16} />{t("logout")}</button>
        </div>
      </aside>
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 hidden items-center gap-4 border-b border-line bg-cream/90 px-8 py-3 backdrop-blur lg:flex">
          <Link href="/profile/addresses" className="flex items-center gap-2 text-sm"><MapPin size={17} className="text-primary" /><span className="font-semibold">{s.location}</span></Link>
          <div className="ml-auto flex items-center gap-3">
            <LangToggle />
            <Link href="/notifications" aria-label="Notifications" className="relative grid h-10 w-10 place-items-center rounded-full border border-line bg-white"><Bell size={18} />{unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-white">{unread}</span>}</Link>
            <Link href="/profile" className="flex items-center gap-2">{s.user.photo ? <img src={s.user.photo} alt="" className="h-10 w-10 rounded-full object-cover" /> : <Avatar name={s.user.name} size={40} />}<span className="text-sm font-semibold">{s.user.name}</span></Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-4 sm:px-6 lg:px-8 lg:pb-12 lg:pt-6">{children}</main>
      </div>
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/95 backdrop-blur lg:hidden" aria-label="Primary">
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className={cn("flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold", active(n.href) ? "text-primary" : "text-muted")}>
              <span className={cn("grid h-8 w-12 place-items-center rounded-full transition", active(n.href) && "bg-primary-soft")}><n.icon size={21} /></span>{n.label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
