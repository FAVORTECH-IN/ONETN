"use client";
import { Bus, Landmark, ShoppingBasket, Flame, GraduationCap, Briefcase, Languages } from "lucide-react";
import { useApp } from "@/lib/store";
import { Logo } from "./Logo";
import { cn } from "@/lib/utils";

export function LangToggle({ className }: { className?: string }) {
  const { s, set } = useApp();
  return (
    <div className={cn("flex items-center gap-1 rounded-full border border-line bg-white p-1 text-sm", className)} role="group" aria-label="Language">
      <Languages size={15} className="ml-1.5 text-muted" />
      {(["ta", "en"] as const).map((l) => (
        <button key={l} onClick={() => set((p) => ({ ...p, lang: l }))}
          className={cn("rounded-full px-3 py-1 font-semibold", s.lang === l ? "bg-primary text-white" : "text-muted")}>{l === "ta" ? "தமிழ்" : "English"}</button>
      ))}
    </div>
  );
}

export function AuthFrame({ children, wide }: { children: React.ReactNode; wide?: boolean }) {
  const { tx } = useApp();
  const tiles = [
    { i: Bus, l: { en: "Travel", ta: "பயணம்" } }, { i: ShoppingBasket, l: { en: "Essentials", ta: "அத்தியாவசியம்" } },
    { i: Landmark, l: { en: "Government", ta: "அரசு" } }, { i: Flame, l: { en: "Temples", ta: "கோயில்கள்" } },
    { i: GraduationCap, l: { en: "Learning", ta: "கல்வி" } }, { i: Briefcase, l: { en: "Jobs", ta: "வேலைகள்" } },
  ];
  return (
    <div className="flex min-h-dvh">
      <aside className="relative hidden w-[44%] max-w-[620px] flex-col justify-between overflow-hidden bg-primary p-10 text-white lg:flex">
        <svg className="absolute -right-24 -top-24 h-96 w-96 opacity-20" viewBox="0 0 200 200" aria-hidden><circle cx="100" cy="100" r="90" fill="none" stroke="#D4AF37" strokeWidth="14" /><circle cx="100" cy="100" r="50" fill="none" stroke="#D4AF37" strokeWidth="6" /></svg>
        <Logo size={44} light tagline />
        <div className="relative">
          <h2 className="text-4xl font-extrabold leading-tight">One app for every<br />everyday service in<br /><span className="text-gold">Tamil Nadu.</span></h2>
          <p className="mt-4 max-w-md text-white/80">Fair-fare rides, ration and milk at your door, verified home services, certificates and schemes, temple sevas, learning, jobs and food — in Tamil and English.</p>
          <div className="mt-8 grid max-w-md grid-cols-3 gap-3">
            {tiles.map(({ i: I, l }) => (
              <div key={l.en} className="rounded-2xl bg-white/10 p-4 backdrop-blur"><I className="text-gold" /><p className="mt-2 text-sm font-semibold">{tx(l)}</p></div>
            ))}
          </div>
        </div>
        <p className="relative text-xs text-white/60">Demo build · simulated authentication and payments</p>
      </aside>
      <main className="flex flex-1 flex-col">
        <div className="flex items-center justify-between px-5 pt-5 lg:justify-end">
          <span className="lg:hidden"><Logo size={34} /></span>
          <LangToggle />
        </div>
        <div className={cn("mx-auto flex w-full flex-1 flex-col px-5 py-6", wide ? "max-w-xl" : "max-w-md")}>{children}</div>
      </main>
    </div>
  );
}
