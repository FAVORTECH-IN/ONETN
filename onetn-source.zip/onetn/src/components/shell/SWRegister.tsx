"use client";
import { useEffect } from "react";
export function SWRegister() {
  useEffect(() => {
    if ("serviceWorker" in navigator && location.protocol === "https:") {
      navigator.serviceWorker.register(new URL("sw.js", document.baseURI).pathname).catch(() => {});
    }
  }, []);
  return null;
}
