import { cn } from "@/lib/utils";
export function LogoMark({ size = 40, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-hidden>
      <rect width="64" height="64" rx="18" fill="#8B0000" />
      <circle cx="32" cy="32" r="17" fill="none" stroke="#D4AF37" strokeWidth="4.5" />
      <path d="M32 19v26M19 32h26" stroke="#D4AF37" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="32" cy="32" r="4.5" fill="#fff" />
    </svg>
  );
}
export function Logo({ size = 36, light, className, tagline }: { size?: number; light?: boolean; className?: string; tagline?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark size={size} />
      <span className="leading-none">
        <span className={cn("block font-extrabold tracking-tight", light ? "text-white" : "text-primary")} style={{ fontSize: size * 0.6 }}>ONE<span className="text-gold">TN</span></span>
        {tagline && <span className={cn("mt-1 block text-[11px] font-medium", light ? "text-white/80" : "text-muted")}>One Platform. Every Service.</span>}
      </span>
    </span>
  );
}
