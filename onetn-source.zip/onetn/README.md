# ONETN — One Platform. Every Service.

Frontend for a Tamil Nadu multi-service super app (citizen app + 10 partner/government portals).
Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · Lucide · React Hook Form + Zod · Recharts.
Static export (`output: "export"`), PWA manifest + service worker.

## Run
    npm install
    npm run dev          # http://localhost:3000
    npm run build        # static site in ./out (deploy to any static host / Vercel)

## Demo credentials
- Mobile `9876543210` (existing account) or any valid number (new registration)
- OTP `123456` · Wallet / payment PIN & OTP `1234`
- Partner portals: /select-role, or open a portal URL and use "Sign in with demo account"

## Structure
- `src/app/(auth)` – login, OTP, registration (7 steps), onboarding + language, recovery, role selection
- `src/app/(citizen)` – home, services directory, transport/bus/metro/parcels, quick delivery, essentials
  (ration, milk, medicine, Uzhavar Sandhai, co-op), home services, government, grievance, temples,
  education (library, AI guide, mock tests, counselling), healthcare, jobs, food, wallet, bookings/orders, profile, support
- `src/components/flows` – shared checkout/payment, cart, tracking map, QR, appointment, booking tracker
- `src/portals` – config-driven portal engine (tables w/ actions, charts, forms, onboarding wizards)
  and configs for driver, professional, merchant, restaurant, temple-admin, education-partner,
  healthcare-partner, employer, department, admin
- `src/data` – mock data · `src/lib/store.tsx` – app state (localStorage), payments, bookings · `src/lib/i18n.ts` – Tamil/English

## Simulated, not integrated
OTP, payments/Wallet (needs licensed RBI partner), maps/geolocation, DigiLocker, Chennai One, department portals,
video consultation, AI study guide, notifications. All fee/fare/commission figures are placeholders pending
Government approval (Annexure E). Every simulated function is labelled in the UI.
